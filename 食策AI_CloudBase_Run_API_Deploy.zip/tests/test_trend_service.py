from __future__ import annotations

import sys
from pathlib import Path

from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


def migrated_db(tmp_path: Path) -> Path:
    from db import migrate_database

    db = tmp_path / "trend.db"
    create_v04_db(db)
    migrate_database(db)
    return db


def seed_total(db, day: str, sales: str, orders: int | None = None):
    from repositories.mini_sales_repository import MiniSalesRepository

    MiniSalesRepository(db).upsert_store_total(1, day, sales, "TEST", f"trend:{day}", order_count=orders)


def test_trend_does_not_invent_zero_for_missing_day(tmp_path):
    from services.trend_service import TrendService

    db = migrated_db(tmp_path)
    seed_total(db, "2026-09-01", "1000", 20)
    seed_total(db, "2026-09-02", "1200", 20)

    trend = TrendService(db).get(1, "2026-09-02", 7)

    assert trend.observed_days == 2
    assert trend.missing_days == 5
    assert len(trend.daily_sales) == 2
    assert {x["date"] for x in trend.daily_sales} == {"2026-09-01", "2026-09-02"}


def test_trend_percentage_is_none_when_previous_denominator_is_zero(tmp_path):
    from services.trend_service import TrendService

    db = migrated_db(tmp_path)
    seed_total(db, "2026-09-01", "0", 10)
    seed_total(db, "2026-09-02", "100", 10)

    trend = TrendService(db).get(1, "2026-09-02", 7)

    assert trend.sales_change_percent is None


def test_trend_aov_uses_only_days_with_order_count(tmp_path):
    from services.trend_service import TrendService

    db = migrated_db(tmp_path)
    seed_total(db, "2026-08-31", "900", None)
    seed_total(db, "2026-09-01", "1000", 20)
    seed_total(db, "2026-09-02", "1200", 20)

    trend = TrendService(db).get(1, "2026-09-02", 7)

    assert trend.latest_aov == "60.00"
    assert trend.aov_change_percent == "20.00"


def test_trend_rejects_unsupported_window(tmp_path):
    from services.trend_service import TrendService

    db = migrated_db(tmp_path)
    try:
        TrendService(db).get(1, "2026-09-02", 90)
    except ValueError as exc:
        assert "days" in str(exc)
    else:
        raise AssertionError("expected unsupported trend window to fail")


def test_trend_api_returns_observed_and_missing_days(tmp_path, monkeypatch):
    import app as app_module
    import mini.auth as auth_module
    from mini.auth import WechatIdentity
    from repositories.mini_sales_repository import MiniSalesRepository

    class FakeProvider:
        def exchange_code(self, code: str):
            return WechatIdentity(openid=f"test:{code}", unionid=None)

    db = tmp_path / "api.db"
    create_v04_db(db)
    monkeypatch.setattr(app_module, "DB_PATH", db)
    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeProvider())
    client = TestClient(app_module.app)
    with client:
        login = client.post("/api/mini/v1/auth/wechat", json={"code": "owner-t"}).json()
        headers = {"Authorization": f"Bearer {login['token']}"}
        store = client.post(
            "/api/mini/v1/store",
            headers=headers,
            json={"name": "测试店", "category_code": "MILK_TEA"},
        ).json()["store"]
        repo = MiniSalesRepository(db)
        repo.upsert_store_total(int(store["id"]), "2026-09-02", "1000", "TEST", "api", order_count=20)

        r = client.get("/api/mini/v1/trends?days=7&end_date=2026-09-02", headers=headers)

    assert r.status_code == 200
    assert r.json()["trend"]["observed_days"] == 1
    assert r.json()["trend"]["missing_days"] == 6
