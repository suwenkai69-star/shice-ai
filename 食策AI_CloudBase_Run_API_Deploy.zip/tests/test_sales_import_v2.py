from __future__ import annotations

import json
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


def migrated_db(tmp_path: Path) -> Path:
    from db_v2 import migrate_database
    db = tmp_path / "sales.db"
    create_v04_db(db)
    migrate_database(db)
    return db


def sample_csv(gross="10000.00", extra_header="备注", extra_value="首次导入") -> bytes:
    return (
        f"营业日期,渠道代码,销售额,顾客实付,订单数,退款金额,退款笔数,商家优惠,平台补贴,{extra_header}\n"
        f"2026-08-27,MEITUAN_DELIVERY,{gross},9000.00,180,100.00,2,500.00,300.00,{extra_value}\n"
    ).encode("utf-8")


def test_sales_import_creates_file_batch_raw_and_normalized_traceability(tmp_path):
    from data_foundation import get_sales_trace, import_daily_sales, list_daily_sales

    db = migrated_db(tmp_path)
    result = import_daily_sales(
        db, store_id=1, filename="meituan_2026_08_27.csv", data=sample_csv(), source_type="MEITUAN_EXPORT"
    )

    assert result.row_count == 1
    assert result.accepted_rows == 1
    assert result.rejected_rows == 0
    assert result.duplicate_rows == 0
    assert result.updated_rows == 0
    assert result.status == "COMPLETED"
    assert result.import_batch_id > 0
    assert "备注" in result.unknown_fields

    rows = list_daily_sales(db, store_id=1)
    assert len(rows) == 1
    sale = rows[0]
    assert sale["business_date"] == "2026-08-27"
    assert sale["channel_code"] == "MEITUAN_DELIVERY"
    assert sale["gross_sales"] == "10000.00"
    assert sale["customer_paid"] == "9000.00"
    assert sale["order_count"] == 180

    trace = get_sales_trace(db, sale["id"])
    assert trace["file"]["file_name"] == "meituan_2026_08_27.csv"
    assert trace["batch"]["id"] == result.import_batch_id
    assert trace["raw_row"]["row_number"] == 1
    raw = json.loads(trace["raw_row"]["raw_payload_json"])
    assert raw["备注"] == "首次导入"


def test_same_sales_file_uploaded_three_times_never_double_counts(tmp_path):
    from data_foundation import import_daily_sales, list_daily_sales, list_import_batches

    db = migrated_db(tmp_path)
    results = [
        import_daily_sales(db, 1, "same.csv", sample_csv(), "MEITUAN_EXPORT")
        for _ in range(3)
    ]

    assert results[0].accepted_rows == 1
    assert results[1].duplicate_rows == 1
    assert results[2].duplicate_rows == 1
    assert results[1].accepted_rows == 0
    assert results[2].accepted_rows == 0

    rows = list_daily_sales(db, 1)
    assert len(rows) == 1
    assert sum(float(r["gross_sales"]) for r in rows) == 10000.0
    assert len(list_import_batches(db, 1)) == 3


def test_changed_sales_row_updates_same_logical_day_channel_instead_of_accumulating(tmp_path):
    from data_foundation import import_daily_sales, list_daily_sales

    db = migrated_db(tmp_path)
    first = import_daily_sales(db, 1, "day.csv", sample_csv("10000.00"), "MEITUAN_EXPORT")
    second = import_daily_sales(db, 1, "day_corrected.csv", sample_csv("10200.00"), "MEITUAN_EXPORT")

    assert first.accepted_rows == 1
    assert second.accepted_rows == 1
    assert second.updated_rows == 1
    rows = list_daily_sales(db, 1)
    assert len(rows) == 1
    assert rows[0]["gross_sales"] == "10200.00"
    assert rows[0]["import_batch_id"] == second.import_batch_id


def test_invalid_sales_rows_are_retained_as_rejected_raw_rows(tmp_path):
    from data_foundation import import_daily_sales

    db = migrated_db(tmp_path)
    bad = (
        "营业日期,渠道代码,销售额,订单数\n"
        "2026-08-27,MEITUAN_DELIVERY,not-money,180\n"
    ).encode("utf-8")
    result = import_daily_sales(db, 1, "bad.csv", bad, "MEITUAN_EXPORT")

    assert result.accepted_rows == 0
    assert result.rejected_rows == 1
    assert result.status == "FAILED"
    with sqlite3.connect(db) as con:
        batch = con.execute("SELECT rejected_rows,status FROM import_batches WHERE id=?", (result.import_batch_id,)).fetchone()
        raw = con.execute("SELECT parse_status,error_message FROM raw_import_rows WHERE import_batch_id=?", (result.import_batch_id,)).fetchone()
    assert batch == (1, "FAILED")
    assert raw[0] == "REJECTED"
    assert "销售额" in raw[1]


def test_sales_parser_uses_field_names_not_column_positions_and_tolerates_unknown_columns(tmp_path):
    from data_foundation import import_daily_sales, list_daily_sales

    db = migrated_db(tmp_path)
    shuffled = (
        "平台补贴,订单数,未知新字段,销售额,营业日期,渠道代码,顾客实付,商家优惠,退款金额,退款笔数\n"
        "300,180,平台未来字段,10000,2026-08-27,MEITUAN_DELIVERY,9000,500,100,2\n"
    ).encode("utf-8")
    result = import_daily_sales(db, 1, "shuffled.csv", shuffled, "MEITUAN_EXPORT")
    assert result.status == "COMPLETED"
    assert result.unknown_fields == ["未知新字段"]
    sale = list_daily_sales(db, 1)[0]
    assert sale["gross_sales"] == "10000.00"
    assert sale["platform_subsidy"] == "300.00"

def test_missing_optional_sales_fields_remain_unknown_not_fabricated_zero(tmp_path):
    from data_foundation import import_daily_sales, list_daily_sales

    db = migrated_db(tmp_path)
    minimal = (
        "营业日期,渠道代码,销售额\n"
        "2026-08-27,CASH,888.88\n"
    ).encode("utf-8")
    result = import_daily_sales(db, 1, "cash.csv", minimal, "MANUAL")
    assert result.accepted_rows == 1
    row = list_daily_sales(db, 1)[0]
    assert row["customer_paid"] is None
    assert row["order_count"] is None
    assert row["refund_amount"] is None
    assert row["merchant_discount"] is None
    assert row["platform_subsidy"] is None

def test_sales_discount_refund_and_subsidy_are_positive_magnitudes(tmp_path):
    from data_foundation import import_daily_sales, list_daily_sales

    db = migrated_db(tmp_path)
    data = (
        "营业日期,渠道代码,销售额,退款金额,商家优惠,平台补贴\n"
        "2026-08-27,MEITUAN_DELIVERY,1000,-20,-30,-40\n"
    ).encode()
    import_daily_sales(db, 1, "sign.csv", data, "MEITUAN_EXPORT")
    row = list_daily_sales(db, 1)[0]
    assert row["refund_amount"] == "20.00"
    assert row["merchant_discount"] == "30.00"
    assert row["platform_subsidy"] == "40.00"
