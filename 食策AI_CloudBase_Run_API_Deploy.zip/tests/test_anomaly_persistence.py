from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


def test_recalculation_preserves_anomaly_identity_after_action_links_to_it(tmp_path):
    from db import migrate_database
    from repositories.action_repository import ActionRepository
    from repositories.mini_sales_repository import MiniSalesRepository
    from services.anomaly_engine import AnomalyEngine

    db = tmp_path / "anomaly-stable.db"
    create_v04_db(db)
    migrate_database(db)
    with sqlite3.connect(db) as con:
        con.execute(
            "INSERT OR IGNORE INTO store_profiles(store_id,category_code,city_code,created_at,updated_at) "
            "VALUES(1,'MILK_TEA','URUMQI',1,1)"
        )
        con.commit()

    repo = MiniSalesRepository(db)
    for day in ("2026-08-27", "2026-08-28", "2026-08-29", "2026-08-30", "2026-08-31", "2026-09-01"):
        repo.upsert_store_total(1, day, "5000", "TEST", day, order_count=100)
    repo.upsert_store_total(1, "2026-09-02", "4000", "TEST", "today", order_count=100)

    engine = AnomalyEngine(db)
    first = engine.detect(1, "2026-09-02")
    anomaly = next(x for x in first if x.anomaly_type == "AOV_LOW")
    ActionRepository(db).create_action(
        1, "2026-09-02", anomaly.id, "AOV_RECOVERY", "提高客单价", "客单价偏低", "AOV", "UP", 1
    )

    second = engine.detect(1, "2026-09-02")
    second_anomaly = next(x for x in second if x.anomaly_type == "AOV_LOW")

    assert second_anomaly.id == anomaly.id
