from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db
from tests.test_settlement_payment_import_v2 import settlement_csv


@pytest.fixture
def action_db(tmp_path):
    from db import migrate_database

    db = tmp_path / "action-engine.db"
    create_v04_db(db)
    migrate_database(db)
    with sqlite3.connect(db) as con:
        con.execute(
            "INSERT OR IGNORE INTO store_profiles(store_id,category_code,city_code,created_at,updated_at) "
            "VALUES(1,'MILK_TEA','URUMQI',1,1)"
        )
        con.commit()
    return db


def seed_aov_issue(db):
    from repositories.mini_sales_repository import MiniSalesRepository

    repo = MiniSalesRepository(db)
    for day in ("2026-08-27", "2026-08-28", "2026-08-29", "2026-08-30", "2026-08-31", "2026-09-01"):
        repo.upsert_store_total(1, day, "5000", "TEST", day, order_count=100)
    repo.upsert_store_total(1, "2026-09-02", "4000", "TEST", "today", order_count=100)


def test_action_engine_returns_at_most_three_and_links_to_issue(action_db):
    from data_foundation import import_settlements
    from services.action_engine import ActionEngine

    seed_aov_issue(action_db)
    import_settlements(action_db, 1, "s.csv", settlement_csv(expected="386.00", ref="UNPAID"), "MEITUAN_SETTLEMENT")

    actions = ActionEngine(action_db).generate(1, "2026-09-02")

    assert 1 <= len(actions) <= 3
    assert all(a.anomaly_id for a in actions)
    assert actions[0].action_type == "CHECK_RECONCILIATION"


def test_action_generation_is_idempotent_and_keeps_existing_state(action_db):
    from services.action_engine import ActionEngine

    seed_aov_issue(action_db)
    engine = ActionEngine(action_db)
    first = engine.generate(1, "2026-09-02")
    assert len(first) == 1
    engine.execute(first[0].id, 1, executed_at=1234, note="完成")

    second = engine.generate(1, "2026-09-02")

    assert second[0].id == first[0].id
    assert second[0].status == "WAITING_VERIFICATION"


def test_opening_action_never_marks_it_executed(action_db):
    from services.action_engine import ActionEngine

    seed_aov_issue(action_db)
    engine = ActionEngine(action_db)
    action = engine.generate(1, "2026-09-02")[0]

    viewed = engine.get(action.id, 1)

    assert viewed.status == "PENDING"


def test_action_api_execute_skip_and_remind_require_explicit_calls(tmp_path, monkeypatch):
    import app as app_module
    import mini.auth as auth_module
    from mini.auth import WechatIdentity
    from repositories.mini_sales_repository import MiniSalesRepository

    class FakeProvider:
        def exchange_code(self, code: str):
            return WechatIdentity(openid=f"test:{code}", unionid=None)

    db = tmp_path / "api.db"
    create_v04_db(db)
    monkeypatch.setattr(app_module, "DB_PATH", db)
    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeProvider())
    client = TestClient(app_module.app)
    with client:
        login = client.post("/api/mini/v1/auth/wechat", json={"code": "owner-action"}).json()
        headers = {"Authorization": f"Bearer {login['token']}"}
        store = client.post(
            "/api/mini/v1/store",
            headers=headers,
            json={"name": "测试店", "category_code": "MILK_TEA"},
        ).json()["store"]
        store_id = int(store["id"])
        repo = MiniSalesRepository(db)
        for day in ("2026-08-27", "2026-08-28", "2026-08-29", "2026-08-30", "2026-08-31", "2026-09-01"):
            repo.upsert_store_total(store_id, day, "5000", "TEST", day, order_count=100)
        repo.upsert_store_total(store_id, "2026-09-02", "4000", "TEST", "today", order_count=100)

        listing = client.get("/api/mini/v1/actions?date=2026-09-02", headers=headers)
        assert listing.status_code == 200
        action = listing.json()["actions"][0]
        assert action["status"] == "PENDING"

        detail = client.get(f"/api/mini/v1/actions/{action['id']}", headers=headers)
        assert detail.json()["action"]["status"] == "PENDING"

        executed = client.post(
            f"/api/mini/v1/actions/{action['id']}/execute",
            headers=headers,
            json={"note": "已经调整"},
        )
        assert executed.status_code == 200
        assert executed.json()["action"]["status"] == "WAITING_VERIFICATION"


def test_remind_creates_pending_reminder_not_fake_sent(action_db):
    from services.action_engine import ActionEngine

    seed_aov_issue(action_db)
    engine = ActionEngine(action_db)
    action = engine.generate(1, "2026-09-02")[0]
    reminder = engine.remind(action.id, user_id=1, store_id=1, scheduled_at=999999)

    assert reminder["status"] == "PENDING"
    assert engine.get(action.id, 1).status == "REMIND"


def test_action_api_skip_and_remind_endpoints(tmp_path, monkeypatch):
    import app as app_module
    import mini.auth as auth_module
    from mini.auth import WechatIdentity
    from repositories.action_repository import ActionRepository

    class FakeProvider:
        def exchange_code(self, code: str):
            return WechatIdentity(openid=f"test:{code}", unionid=None)

    db = tmp_path / "api-skip-remind.db"
    create_v04_db(db)
    monkeypatch.setattr(app_module, "DB_PATH", db)
    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeProvider())
    client = TestClient(app_module.app)
    with client:
        login = client.post("/api/mini/v1/auth/wechat", json={"code": "owner-sr"}).json()
        headers = {"Authorization": f"Bearer {login['token']}"}
        store = client.post(
            "/api/mini/v1/store", headers=headers,
            json={"name": "测试店", "category_code": "MILK_TEA"},
        ).json()["store"]
        store_id = int(store["id"])
        repo = ActionRepository(db)
        skip_action = repo.create_action(store_id, "2026-09-02", None, "SKIP_TEST", "暂不做", "测试", "AOV", "UP", 2)
        remind_action = repo.create_action(store_id, "2026-09-02", None, "REMIND_TEST", "明天提醒", "测试", "AOV", "UP", 2)

        skipped = client.post(f"/api/mini/v1/actions/{skip_action['id']}/skip", headers=headers)
        reminded = client.post(
            f"/api/mini/v1/actions/{remind_action['id']}/remind",
            headers=headers,
            json={"scheduled_at": 1893456000000},
        )

    assert skipped.status_code == 200
    assert skipped.json()["action"]["status"] == "SKIPPED"
    assert reminded.status_code == 200
    assert reminded.json()["reminder"]["status"] == "PENDING"
    assert reminded.json()["action"]["status"] == "REMIND"
