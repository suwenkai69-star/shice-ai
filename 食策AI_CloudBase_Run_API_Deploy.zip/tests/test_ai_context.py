from __future__ import annotations

import json
import sqlite3
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


@pytest.fixture
def ai_db(tmp_path):
    from db import migrate_database

    db = tmp_path / "ai-context.db"
    create_v04_db(db)
    migrate_database(db)
    with sqlite3.connect(db) as con:
        con.execute(
            "INSERT OR IGNORE INTO store_profiles(store_id,category_code,city_code,created_at,updated_at) VALUES(1,'MILK_TEA',NULL,1,1)"
        )
        con.execute(
            "UPDATE app_state SET json=? WHERE store_id=1",
            (json.dumps({"chat": "老板说今天人工肯定很高", "business": None}, ensure_ascii=False),),
        )
        con.commit()
    return db


def test_labor_question_without_labor_data_is_blocked(ai_db):
    from services.ai_context_service import AIContextService
    from services.sufficiency_gate import SufficiencyGate

    ctx = AIContextService(ai_db).build(1, "我今天人工是不是太高？", "2026-09-02")
    gate = SufficiencyGate().check("LABOR_DIAGNOSIS", ctx)

    assert gate.sufficient is False
    assert "人工" in gate.missing_data


def test_context_contains_actual_sales_fact_but_not_legacy_free_chat(ai_db):
    from repositories.mini_sales_repository import MiniSalesRepository
    from services.ai_context_service import AIContextService

    MiniSalesRepository(ai_db).upsert_store_total(1, "2026-09-02", "1000", "MANUAL", "m1", order_count=20)
    ctx = AIContextService(ai_db).build(1, "今天生意怎么样？", "2026-09-02")

    assert ctx.facts["sales"]["amount"] == "1000.00"
    assert ctx.facts["sales"]["source"] == "ACTUAL_STORE_TOTAL"
    assert "老板说今天人工肯定很高" not in repr(ctx)


def test_context_separates_estimates_from_facts(ai_db):
    from repositories.mini_sales_repository import MiniSalesRepository
    from repositories.mini_cost_repository import MiniCostRepository
    from services.ai_context_service import AIContextService

    MiniSalesRepository(ai_db).upsert_store_total(1, "2026-09-02", "1000", "MANUAL", "m1", order_count=20)
    # One actual cost is still a fact; missing costs keep profit estimate separate and cautious.
    MiniCostRepository(ai_db).add_cost_entry(
        1, amount="300", cost_type="FOOD", source_type="ACTUAL", business_date="2026-09-02"
    )
    ctx = AIContextService(ai_db).build(1, "今天赚了多少？", "2026-09-02")

    assert ctx.facts["sales"]["amount"] == "1000.00"
    assert "profit" in ctx.estimates
    assert ctx.estimates["profit"]["status"] in {"ESTIMATED_RANGE", "UNAVAILABLE"}
    assert isinstance(ctx.missing_data, tuple)


def test_generic_sales_question_is_sufficient_when_actual_sales_exists(ai_db):
    from repositories.mini_sales_repository import MiniSalesRepository
    from services.ai_context_service import AIContextService
    from services.sufficiency_gate import SufficiencyGate

    MiniSalesRepository(ai_db).upsert_store_total(1, "2026-09-02", "1000", "MANUAL", "m1", order_count=20)
    ctx = AIContextService(ai_db).build(1, "今天卖得怎么样？", "2026-09-02")
    gate = SufficiencyGate().check("SALES_DIAGNOSIS", ctx)

    assert gate.sufficient is True
    assert gate.missing_data == ()


def test_context_contract_exposes_reconciliation_verifications_and_benchmarks(ai_db):
    from services.ai_context_service import AIContextService

    ctx = AIContextService(ai_db).build(1, "今天怎么样？", "2026-09-02")

    assert hasattr(ctx, "reconciliation")
    assert hasattr(ctx, "recent_verifications")
    assert hasattr(ctx, "benchmarks_used")
    assert isinstance(ctx.recent_verifications, tuple)
    assert isinstance(ctx.benchmarks_used, tuple)
