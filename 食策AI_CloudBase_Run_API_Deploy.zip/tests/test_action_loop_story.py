from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


class StoryNotificationProvider:
    def __init__(self):
        self.sent = []

    def send(self, reminder):
        from notifications.provider import SendResult
        self.sent.append(reminder)
        return SendResult(int(reminder["id"]), "SENT")


def test_full_action_loop_story(tmp_path):
    from db import migrate_database
    from repositories.mini_sales_repository import MiniSalesRepository
    from services.action_engine import ActionEngine
    from services.reminder_service import ReminderService
    from services.verification_engine import VerificationEngine

    db = tmp_path / "story.db"
    create_v04_db(db)
    migrate_database(db)
    sales = MiniSalesRepository(db)
    for day in ("2026-08-27", "2026-08-28", "2026-08-29", "2026-08-30", "2026-08-31", "2026-09-01"):
        sales.upsert_store_total(1, day, "5000", "TEST", day, order_count=100)
    sales.upsert_store_total(1, "2026-09-02", "4000", "TEST", "low-aov", order_count=100)

    engine = ActionEngine(db)
    action = engine.generate(1, "2026-09-02")[0]
    assert action.action_type == "AOV_RECOVERY"
    assert action.status == "PENDING"

    reminder = engine.remind(action.id, user_id=1, store_id=1, scheduled_at=2000)
    assert reminder["status"] == "PENDING"
    executed = engine.execute(action.id, 1, executed_at=1500, note="已经调整低价套餐曝光")
    assert executed.status == "WAITING_VERIFICATION"

    provider = StoryNotificationProvider()
    send_results = ReminderService(db, provider).dispatch_due(now=2000)
    assert [r.status for r in send_results] == ["SENT"]

    sales.upsert_store_total(1, "2026-09-03", "4500", "TEST", "next-day", order_count=100)
    verified = VerificationEngine(db).verify(action.id, "2026-09-03")
    assert verified.result == "IMPROVED"
    assert "执行后相关指标" in verified.explanation
    assert "导致" not in verified.explanation
    assert engine.get(action.id, 1).status == "VERIFIED"
