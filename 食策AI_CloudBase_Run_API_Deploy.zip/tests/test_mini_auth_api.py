from __future__ import annotations

import sys
from pathlib import Path

from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import app as api_app


class FakeAuthProvider:
    def __init__(self, openid: str):
        self.openid = openid

    def exchange_code(self, code: str):
        from mini.auth import WechatIdentity
        return WechatIdentity(openid=self.openid, unionid=None)


def client_for(monkeypatch, tmp_path):
    db = tmp_path / "mini-api.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    return TestClient(api_app.app), db


def _login(client, monkeypatch, openid: str) -> str:
    import mini.auth as auth_module

    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeAuthProvider(openid))
    r = client.post("/api/mini/v1/auth/wechat", json={"code": "wx-code"})
    assert r.status_code == 200, r.text
    return r.json()["token"]


def test_wechat_login_and_store_onboarding(client=None, monkeypatch=None):
    # pytest injects fixtures only when named in the signature; this body is replaced below.
    pass


def test_wechat_login_and_store_onboarding(monkeypatch, tmp_path):
    client, _ = client_for(monkeypatch, tmp_path)
    with client:
        token = _login(client, monkeypatch, "openid-1")
        created = client.post(
            "/api/mini/v1/store",
            headers={"Authorization": f"Bearer {token}"},
            json={"name": "老王奶茶", "category_code": "MILK_TEA"},
        )
        fetched = client.get("/api/mini/v1/store", headers={"Authorization": f"Bearer {token}"})
    assert created.status_code == 200
    assert created.json()["store"]["name"] == "老王奶茶"
    assert created.json()["store"]["category_code"] == "MILK_TEA"
    assert fetched.status_code == 200
    assert fetched.json()["store"]["id"] == created.json()["store"]["id"]


def test_missing_or_invalid_token_returns_401(monkeypatch, tmp_path):
    client, _ = client_for(monkeypatch, tmp_path)
    with client:
        missing = client.get("/api/mini/v1/store")
        bad = client.get("/api/mini/v1/store", headers={"Authorization": "Bearer not-a-token"})
    assert missing.status_code == 401
    assert bad.status_code == 401


def test_user_cannot_read_another_users_store(monkeypatch, tmp_path):
    client, _ = client_for(monkeypatch, tmp_path)
    with client:
        token_a = _login(client, monkeypatch, "openid-a")
        a = client.post(
            "/api/mini/v1/store",
            headers={"Authorization": f"Bearer {token_a}"},
            json={"name": "A店", "category_code": "MILK_TEA"},
        )
        assert a.status_code == 200

        token_b = _login(client, monkeypatch, "openid-b")
        b = client.get("/api/mini/v1/store", headers={"Authorization": f"Bearer {token_b}"})
    assert b.status_code == 404


def test_store_patch_is_scoped_to_logged_in_user(monkeypatch, tmp_path):
    client, _ = client_for(monkeypatch, tmp_path)
    with client:
        token = _login(client, monkeypatch, "openid-patch")
        client.post(
            "/api/mini/v1/store",
            headers={"Authorization": f"Bearer {token}"},
            json={"name": "旧名字", "category_code": "MILK_TEA"},
        )
        r = client.patch(
            "/api/mini/v1/store",
            headers={"Authorization": f"Bearer {token}"},
            json={"name": "新名字", "city_code": "URUMQI"},
        )
    assert r.status_code == 200
    assert r.json()["store"]["name"] == "新名字"
    assert r.json()["store"]["city_code"] == "URUMQI"
