from __future__ import annotations

import json

import httpx
import pytest


class StubClient:
    def __init__(self, payload: dict, status_code: int = 200):
        self.payload = payload
        self.status_code = status_code
        self.calls = []

    def post(self, url, **kwargs):
        self.calls.append((url, kwargs))
        request = httpx.Request("POST", url)
        return httpx.Response(self.status_code, json=self.payload, request=request)


def _response_payload(content: dict) -> dict:
    return {
        "output": [
            {
                "type": "message",
                "role": "assistant",
                "content": [
                    {"type": "output_text", "text": json.dumps(content, ensure_ascii=False), "annotations": []}
                ],
            }
        ]
    }


def test_openai_recognition_provider_sends_image_and_parses_structured_fields():
    from recognition.providers.openai import OpenAIRecognitionProvider

    client = StubClient(
        _response_payload(
            {
                "platform": "MEITUAN_DELIVERY",
                "page_type": "DAILY_REPORT",
                "fields": [
                    {"field_code": "BUSINESS_DATE", "value": "2026-09-02", "confidence": 0.99, "raw_text": "2026-09-02"},
                    {"field_code": "GROSS_SALES", "value": "3860.00", "confidence": 0.97, "raw_text": "¥3,860.00"},
                ],
            }
        )
    )
    provider = OpenAIRecognitionProvider(api_key="sk-test", model="vision-model", client=client)

    result = provider.recognize(b"\x89PNG\r\n\x1a\nfixture")

    assert result.platform == "MEITUAN_DELIVERY"
    assert result.page_type == "DAILY_REPORT"
    assert result.provider == "openai-responses"
    assert result.model_version == "vision-model"
    assert [(f.field_code, f.value) for f in result.fields] == [
        ("BUSINESS_DATE", "2026-09-02"),
        ("GROSS_SALES", "3860.00"),
    ]

    url, kwargs = client.calls[0]
    assert url == "https://api.openai.com/v1/responses"
    assert kwargs["headers"]["Authorization"] == "Bearer sk-test"
    body = kwargs["json"]
    assert body["model"] == "vision-model"
    content = body["input"][0]["content"]
    image = next(item for item in content if item["type"] == "input_image")
    assert image["image_url"].startswith("data:image/png;base64,")
    assert body["text"]["format"]["type"] == "json_schema"
    assert body["text"]["format"]["strict"] is True


def test_openai_recognition_provider_rejects_invalid_structured_output():
    from recognition.providers.openai import OpenAIRecognitionProvider, OpenAIRecognitionError

    client = StubClient(_response_payload({"platform": "MEITUAN_DELIVERY", "page_type": "DAILY_REPORT", "fields": "bad"}))
    provider = OpenAIRecognitionProvider(api_key="sk-test", model="vision-model", client=client)

    with pytest.raises(OpenAIRecognitionError):
        provider.recognize(b"jpeg-ish")


def test_upload_provider_factory_uses_openai_only_when_fully_configured(monkeypatch):
    import mini.upload_routes as upload_routes

    monkeypatch.setenv("RECOGNITION_PROVIDER", "openai")
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    monkeypatch.setenv("OPENAI_RECOGNITION_MODEL", "vision-model")

    provider = upload_routes.get_recognition_provider()

    assert provider.__class__.__name__ == "OpenAIRecognitionProvider"
    assert provider.model == "vision-model"
