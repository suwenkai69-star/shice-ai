from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


@pytest.fixture
def v3_db(tmp_path):
    from db import migrate_database

    db = tmp_path / "mini.db"
    create_v04_db(db)
    migrate_database(db)
    return db


def _add_store(db: Path, store_id: int, user_id: int, name: str):
    with sqlite3.connect(db) as con:
        con.execute("INSERT INTO users(id,name,role) VALUES(?,?,?)", (user_id, f"u{user_id}", "owner"))
        con.execute(
            "INSERT INTO stores(id,user_id,name,type,store_type,timezone,currency,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (store_id, user_id, name, "奶茶店", "奶茶店", "Asia/Shanghai", "CNY", 1, 1),
        )
        con.execute(
            "INSERT INTO store_profiles(store_id,category_code,created_at,updated_at) VALUES(?,?,?,?)",
            (store_id, "MILK_TEA", 1, 1),
        )
        con.commit()


def test_sales_repository_never_crosses_store_boundary(v3_db):
    from repositories.mini_sales_repository import MiniSalesRepository

    _add_store(v3_db, 2, 2, "二店")
    repo = MiniSalesRepository(v3_db)
    repo.upsert_store_total(1, "2026-09-02", "1000.00", "MANUAL", "manual-1")
    repo.upsert_store_total(2, "2026-09-02", "2000.00", "MANUAL", "manual-2")
    assert repo.get_store_total(1, "2026-09-02")["gross_sales"] == "1000.00"
    assert repo.get_store_total(2, "2026-09-02")["gross_sales"] == "2000.00"


def test_store_repository_creates_mini_user_and_single_store(v3_db):
    from repositories.mini_store_repository import MiniStoreRepository

    repo = MiniStoreRepository(v3_db)
    user = repo.create_or_get_user("openid-new")
    created = repo.create_store(user["user_id"], "老王奶茶", "MILK_TEA")
    current = repo.get_current_store(user["user_id"])

    assert created["name"] == "老王奶茶"
    assert current["id"] == created["id"]
    assert current["category_code"] == "MILK_TEA"
    assert repo.create_or_get_user("openid-new")["id"] == user["id"]


def test_store_repository_does_not_return_another_users_store(v3_db):
    from repositories.mini_store_repository import MiniStoreRepository

    repo = MiniStoreRepository(v3_db)
    user_a = repo.create_or_get_user("openid-a")
    user_b = repo.create_or_get_user("openid-b")
    store_a = repo.create_store(user_a["user_id"], "A店", "MILK_TEA")
    assert repo.get_current_store(user_b["user_id"]) is None
    with pytest.raises(PermissionError):
        repo.bind_store(user_b["user_id"], store_a["id"])


def test_cost_repository_is_store_scoped_and_filters_approved_benchmarks(v3_db):
    from repositories.mini_cost_repository import MiniCostRepository

    _add_store(v3_db, 2, 2, "二店")
    with sqlite3.connect(v3_db) as con:
        con.execute(
            "INSERT INTO cost_entries(store_id,business_date,cost_type,amount,source_type,created_at) VALUES(?,?,?,?,?,?)",
            (1, "2026-09-02", "MARKETING", "50.00", "ACTUAL", 1),
        )
        con.execute(
            "INSERT INTO cost_entries(store_id,business_date,cost_type,amount,source_type,created_at) VALUES(?,?,?,?,?,?)",
            (2, "2026-09-02", "MARKETING", "99.00", "ACTUAL", 1),
        )
        base = (
            "MILK_TEA", "COUNTRY", "CN", "FOOD_COST_RATE", "0.38", "0.42", "0.45", "RATE",
            "Source", "https://example.com/source", "2026-01-01", "MEDIUM", None, "2026-01-01", None, 1, 1,
        )
        con.execute(
            "INSERT INTO industry_benchmarks(category_code,region_level,region_code,metric_code,low_value,mid_value,high_value,unit,source_name,source_url,source_date,confidence_level,review_status,valid_from,valid_to,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            base[:12] + ("APPROVED",) + base[13:],
        )
        con.execute(
            "INSERT INTO industry_benchmarks(category_code,region_level,region_code,metric_code,low_value,mid_value,high_value,unit,source_name,source_url,source_date,confidence_level,review_status,valid_from,valid_to,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            ("MILK_TEA", "CITY", "URUMQI", "FOOD_COST_RATE", "0.10", "0.11", "0.12", "RATE", "Draft", "https://example.com/draft", "2026-01-01", "LOW", "DRAFT", "2026-01-01", None, 1, 1),
        )
        con.commit()

    repo = MiniCostRepository(v3_db)
    assert [r["amount"] for r in repo.list_cost_entries(1, "2026-09-01", "2026-09-03")] == ["50.00"]
    rows = repo.list_approved_benchmarks("MILK_TEA", "FOOD_COST_RATE", ["URUMQI", "CN"])
    assert len(rows) == 1
    assert rows[0]["review_status"] == "APPROVED"


def test_cost_profile_round_trip(v3_db):
    from repositories.mini_cost_repository import MiniCostRepository

    repo = MiniCostRepository(v3_db)
    saved = repo.save_profile(1, {"food_cost_mode": "USER_ESTIMATE", "food_cost_value": "0.35"})
    loaded = repo.get_profile(1)
    assert saved["food_cost_value"] == "0.35"
    assert loaded["food_cost_mode"] == "USER_ESTIMATE"
