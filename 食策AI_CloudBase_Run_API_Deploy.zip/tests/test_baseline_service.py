from __future__ import annotations

import sqlite3
import sys
from decimal import Decimal
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_benchmark_service import insert_benchmark
from tests.test_schema_v2 import create_v04_db


@pytest.fixture
def v3_db(tmp_path):
    from db import migrate_database

    db = tmp_path / "baseline.db"
    create_v04_db(db)
    migrate_database(db)
    with sqlite3.connect(db) as con:
        con.execute(
            "INSERT OR IGNORE INTO store_profiles(store_id,category_code,city_code,created_at,updated_at) "
            "VALUES(1,'MILK_TEA','URUMQI',1,1)"
        )
        con.commit()
    return db


def seed_store_total(db, date: str, sales: str, orders: int | None = None) -> None:
    from repositories.mini_sales_repository import MiniSalesRepository

    MiniSalesRepository(db).upsert_store_total(
        1,
        date,
        sales,
        "TEST",
        f"total:{date}",
        order_count=orders,
    )


def test_store_7d_baseline_beats_industry_when_enough_history(v3_db):
    from services.baseline_service import BaselineService

    for day, sales, orders in (
        ("2026-08-27", "4900", 100),
        ("2026-08-28", "5000", 100),
        ("2026-08-29", "5100", 100),
        ("2026-08-30", "5000", 100),
        ("2026-08-31", "5200", 100),
        ("2026-09-01", "5000", 100),
    ):
        seed_store_total(v3_db, day, sales, orders)
    insert_benchmark(
        v3_db,
        region_level="CITY",
        region_code="URUMQI",
        metric_code="AOV",
        low="30",
        mid="35",
        high="40",
    )

    baseline = BaselineService(v3_db).get("AOV", 1, "2026-09-02")

    assert baseline is not None
    assert baseline.source == "STORE_7D"
    assert baseline.sample_size == 6
    assert Decimal("49") <= baseline.mid <= Decimal("51")


def test_city_benchmark_is_used_when_store_history_is_insufficient(v3_db):
    from services.baseline_service import BaselineService

    seed_store_total(v3_db, "2026-09-01", "5000", 100)
    insert_benchmark(
        v3_db,
        region_level="COUNTRY",
        region_code="CN",
        metric_code="AOV",
        low="30",
        mid="35",
        high="40",
    )
    insert_benchmark(
        v3_db,
        region_level="CITY",
        region_code="URUMQI",
        metric_code="AOV",
        low="45",
        mid="50",
        high="55",
    )

    baseline = BaselineService(v3_db).get("AOV", 1, "2026-09-02")

    assert baseline is not None
    assert baseline.source == "LOCAL_CATEGORY"
    assert baseline.low == Decimal("45")
    assert baseline.mid == Decimal("50")
    assert baseline.high == Decimal("55")
    assert baseline.sample_size == 0


def test_history_uses_robust_range_instead_of_single_prior_day(v3_db):
    from services.baseline_service import BaselineService

    values = ["5000", "5100", "4900", "5000", "5050", "20000"]
    days = ["2026-08-27", "2026-08-28", "2026-08-29", "2026-08-30", "2026-08-31", "2026-09-01"]
    for day, value in zip(days, values):
        seed_store_total(v3_db, day, value, 100)

    baseline = BaselineService(v3_db).get("AOV", 1, "2026-09-02")

    assert baseline is not None
    assert baseline.source == "STORE_7D"
    assert baseline.mid < Decimal("60")
    assert baseline.high < Decimal("100")


def test_aov_history_ignores_days_without_reliable_order_count(v3_db):
    from services.baseline_service import BaselineService

    for day in ("2026-08-27", "2026-08-28", "2026-08-29", "2026-08-30", "2026-08-31", "2026-09-01"):
        seed_store_total(v3_db, day, "5000", None)

    assert BaselineService(v3_db).get("AOV", 1, "2026-09-02") is None


def test_phase3_anomaly_table_is_created_additively(v3_db):
    # Phase 3 stays within unreleased Schema V3, so existing V3 dev DBs must gain the table idempotently.
    from db import migrate_database

    migrate_database(v3_db)
    with sqlite3.connect(v3_db) as con:
        names = {row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert "anomaly_events" in names
