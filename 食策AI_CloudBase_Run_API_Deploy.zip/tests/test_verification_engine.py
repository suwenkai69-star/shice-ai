from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


@pytest.fixture
def verification_db(tmp_path):
    from db import migrate_database

    db = tmp_path / "verification.db"
    create_v04_db(db)
    migrate_database(db)
    return db


def _create_aov_action(db, before: str | None, after: str | None, direction: str = "UP") -> int:
    from repositories.action_repository import ActionRepository
    from repositories.mini_sales_repository import MiniSalesRepository

    sales = MiniSalesRepository(db)
    if before is not None:
        # 100 orders makes the desired AOV equal to gross_sales / 100.
        sales.upsert_store_total(1, "2026-09-02", str(float(before) * 100), "TEST", "before", order_count=100)
    if after is not None:
        sales.upsert_store_total(1, "2026-09-03", str(float(after) * 100), "TEST", "after", order_count=100)

    repo = ActionRepository(db)
    action = repo.create_action(
        store_id=1,
        business_date="2026-09-02",
        anomaly_id=None,
        action_type="AOV_VERIFY_TEST",
        title="提高客单价",
        reason="测试",
        expected_metric="AOV",
        expected_direction=direction,
        priority=1,
    )
    repo.mark_executed(action["id"], 1, executed_at=1234, note="已执行")
    return int(action["id"])


@pytest.mark.parametrize(
    "before,after,expected",
    [
        ("50", "55", "IMPROVED"),
        ("50", "51", "NO_CLEAR_CHANGE"),
        ("50", "45", "WORSENED"),
        (None, "55", "INSUFFICIENT_DATA"),
    ],
)
def test_verification_states_for_upward_metric(verification_db, before, after, expected):
    from services.verification_engine import VerificationEngine

    action_id = _create_aov_action(verification_db, before, after, direction="UP")
    result = VerificationEngine(verification_db).verify(action_id, "2026-09-03")

    assert result.result == expected
    assert "执行后相关指标" in result.explanation
    assert "导致" not in result.explanation


def test_verification_is_idempotent_for_same_date(verification_db):
    from services.verification_engine import VerificationEngine

    action_id = _create_aov_action(verification_db, "50", "55")
    engine = VerificationEngine(verification_db)
    first = engine.verify(action_id, "2026-09-03")
    second = engine.verify(action_id, "2026-09-03")

    assert second.id == first.id
    with sqlite3.connect(verification_db) as con:
        count = con.execute(
            "SELECT COUNT(*) FROM action_verifications WHERE action_id=? AND verification_date='2026-09-03'",
            (action_id,),
        ).fetchone()[0]
        status = con.execute("SELECT status FROM action_items WHERE id=?", (action_id,)).fetchone()[0]
    assert count == 1
    assert status == "VERIFIED"


def test_verification_refuses_unexecuted_action(verification_db):
    from repositories.action_repository import ActionRepository
    from services.verification_engine import VerificationEngine

    action = ActionRepository(verification_db).create_action(
        1, "2026-09-02", None, "NOT_EXECUTED", "测试", "测试", "AOV", "UP", 1
    )

    with pytest.raises(ValueError, match="executed"):
        VerificationEngine(verification_db).verify(action["id"], "2026-09-03")


def test_verification_aov_uses_channel_sum_when_whole_store_total_is_absent(tmp_path):
    from data_foundation import import_daily_sales
    from db import migrate_database
    from repositories.action_repository import ActionRepository
    from services.verification_engine import VerificationEngine
    from tests.test_schema_v2 import create_v04_db

    db = tmp_path / "channel-aov-verify.db"
    create_v04_db(db)
    migrate_database(db)
    before = (
        "营业日期,渠道代码,销售额,顾客实付,订单数\n"
        "2026-09-02,MEITUAN_DELIVERY,4000.00,4000.00,100\n"
    ).encode("utf-8")
    after = (
        "营业日期,渠道代码,销售额,顾客实付,订单数\n"
        "2026-09-03,MEITUAN_DELIVERY,4600.00,4600.00,100\n"
    ).encode("utf-8")
    import_daily_sales(db, 1, "before.csv", before, "TEST")
    import_daily_sales(db, 1, "after.csv", after, "TEST")

    repo = ActionRepository(db)
    action = repo.create_action(1, "2026-09-02", None, "AOV_RECOVERY", "提高客单价", "测试", "AOV", "UP", 1)
    repo.mark_executed(action["id"], 1, executed_at=1234)

    result = VerificationEngine(db).verify(action["id"], "2026-09-03")

    assert result.before_value == "40.00"
    assert result.after_value == "46.00"
    assert result.result == "IMPROVED"
