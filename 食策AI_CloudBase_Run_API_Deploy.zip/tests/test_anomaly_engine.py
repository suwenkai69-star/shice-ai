from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


@pytest.fixture
def v3_db(tmp_path):
    from db import migrate_database

    db = tmp_path / "anomaly.db"
    create_v04_db(db)
    migrate_database(db)
    with sqlite3.connect(db) as con:
        con.execute(
            "INSERT OR IGNORE INTO store_profiles(store_id,category_code,city_code,created_at,updated_at) "
            "VALUES(1,'MILK_TEA','URUMQI',1,1)"
        )
        con.commit()
    return db


def seed_total(db, business_date: str, sales: str, orders: int):
    from repositories.mini_sales_repository import MiniSalesRepository

    MiniSalesRepository(db).upsert_store_total(
        1, business_date, sales, "TEST", f"seed:{business_date}", order_count=orders
    )


def test_detects_low_aov_against_reliable_store_history(v3_db):
    from services.anomaly_engine import AnomalyEngine

    for day in ("2026-08-27", "2026-08-28", "2026-08-29", "2026-08-30", "2026-08-31", "2026-09-01"):
        seed_total(v3_db, day, "5000", 100)
    seed_total(v3_db, "2026-09-02", "4000", 100)

    issues = AnomalyEngine(v3_db).detect(1, "2026-09-02")

    aov = next(item for item in issues if item.anomaly_type == "AOV_LOW")
    assert aov.metric_code == "AOV"
    assert aov.baseline_source == "STORE_7D"
    assert aov.confidence == "HIGH"
    assert "客单价" in aov.user_title
    assert aov.observed_value == "40.00"


def test_top_issues_never_returns_more_than_three_and_deduplicates_root_cause(v3_db):
    from repositories.insight_repository import InsightRepository
    from services.anomaly_engine import AnomalyEngine

    InsightRepository(v3_db).replace_anomalies(
        1,
        "2026-09-02",
        [
            _row("AOV_LOW", "AOV", "HIGH", "HIGH", 3, 2, "LOW_PRICE_MIX", "500"),
            _row("LOW_PRICE_SHARE_HIGH", "LOW_PRICE_SHARE", "HIGH", "HIGH", 3, 2, "LOW_PRICE_MIX", "800"),
            _row("RECONCILIATION_DIFFERENCE", "RECONCILIATION_DIFF", "HIGH", "HIGH", 3, 1, "CASH_DIFF", "386"),
            _row("SALES_LOW", "SALES", "MEDIUM", "HIGH", 2, 2, "SALES", "300"),
            _row("LABOR_HIGH", "LABOR_RATE", "MEDIUM", "MEDIUM", 2, 1, "LABOR", "200"),
        ],
    )

    top = AnomalyEngine(v3_db).top_issues(1, "2026-09-02")

    assert len(top) == 3
    groups = [item.root_cause_group for item in top]
    assert len(groups) == len(set(groups))


def test_high_severity_low_confidence_does_not_outrank_reliable_cash_difference(v3_db):
    from repositories.insight_repository import InsightRepository
    from services.anomaly_engine import AnomalyEngine

    InsightRepository(v3_db).replace_anomalies(
        1,
        "2026-09-02",
        [
            _row("AOV_LOW", "AOV", "CRITICAL", "LOW", 3, 3, "LOW_PRICE_MIX", "1000"),
            _row("RECONCILIATION_DIFFERENCE", "RECONCILIATION_DIFF", "HIGH", "HIGH", 3, 1, "CASH_DIFF", "386"),
        ],
    )

    top = AnomalyEngine(v3_db).top_issues(1, "2026-09-02")

    assert top[0].anomaly_type == "RECONCILIATION_DIFFERENCE"


def test_low_confidence_issue_uses_uncertain_language(v3_db):
    from repositories.insight_repository import InsightRepository
    from services.anomaly_engine import AnomalyEngine

    InsightRepository(v3_db).replace_anomalies(
        1,
        "2026-09-02",
        [_row("AOV_LOW", "AOV", "HIGH", "LOW", 3, 1, "LOW_PRICE_MIX", "500")],
    )

    issue = AnomalyEngine(v3_db).top_issues(1, "2026-09-02")[0]
    assert "可能" in issue.user_message


def test_issue_api_is_store_scoped(tmp_path, monkeypatch):
    import app as app_module
    import mini.auth as auth_module
    from mini.auth import WechatIdentity
    from repositories.insight_repository import InsightRepository

    class FakeProvider:
        def exchange_code(self, code: str):
            return WechatIdentity(openid=f"test:{code}", unionid=None)

    db = tmp_path / "api.db"
    create_v04_db(db)
    monkeypatch.setattr(app_module, "DB_PATH", db)
    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeProvider())
    client = TestClient(app_module.app)
    with client:
        login = client.post("/api/mini/v1/auth/wechat", json={"code": "owner-a"}).json()
        headers = {"Authorization": f"Bearer {login['token']}"}
        created = client.post(
            "/api/mini/v1/store",
            headers=headers,
            json={"name": "测试奶茶", "category_code": "MILK_TEA"},
        ).json()["store"]
        store_id = int(created["id"])
        InsightRepository(db).replace_anomalies(
            store_id,
            "2026-09-02",
            [_row("SALES_LOW", "SALES", "MEDIUM", "HIGH", 2, 1, "SALES", "200")],
        )

        response = client.get(
            "/api/mini/v1/issues/today?date=2026-09-02", headers=headers
        )
        assert response.status_code == 200
        body = response.json()
        assert len(body["issues"]) == 1
        assert body["issues"][0]["anomaly_type"] == "SALES_LOW"


def _row(
    anomaly_type: str,
    metric_code: str,
    severity: str,
    confidence: str,
    actionability: int,
    persistence: int,
    root: str,
    impact: str,
):
    return {
        "anomaly_type": anomaly_type,
        "metric_code": metric_code,
        "observed_value": "1",
        "baseline_low": "2",
        "baseline_high": "3",
        "baseline_source": "STORE_7D",
        "estimated_impact_low": impact,
        "estimated_impact_high": impact,
        "severity": severity,
        "confidence": confidence,
        "actionability": actionability,
        "persistence": persistence,
        "root_cause_group": root,
        "status": "OPEN",
    }


def test_detect_includes_evidence_backed_reconciliation_difference(v3_db):
    from data_foundation import import_settlements
    from services.anomaly_engine import AnomalyEngine
    from tests.test_settlement_payment_import_v2 import settlement_csv

    import_settlements(
        v3_db,
        1,
        "settlement.csv",
        settlement_csv(expected="386.00", ref="UNPAID-386"),
        "MEITUAN_SETTLEMENT",
    )

    issues = AnomalyEngine(v3_db).detect(1, "2026-09-02")

    recon = next(item for item in issues if item.anomaly_type == "RECONCILIATION_DIFFERENCE")
    assert recon.estimated_impact_high == "386.00"
    assert recon.confidence == "HIGH"
    assert "没对上" in recon.user_message
    assert "少给" not in recon.user_message


def test_aov_anomaly_uses_channel_sum_when_no_whole_store_total(tmp_path):
    from data_foundation import import_daily_sales
    from db import migrate_database
    from repositories.mini_sales_repository import MiniSalesRepository
    from services.anomaly_engine import AnomalyEngine
    from tests.test_schema_v2 import create_v04_db

    db = tmp_path / "channel-aov.db"
    create_v04_db(db)
    migrate_database(db)
    sales = MiniSalesRepository(db)
    for day in ("2026-08-27", "2026-08-28", "2026-08-29", "2026-08-30", "2026-08-31", "2026-09-01"):
        sales.upsert_store_total(1, day, "5000.00", "TEST", day, order_count=100)

    current = (
        "营业日期,渠道代码,销售额,顾客实付,订单数\n"
        "2026-09-02,MEITUAN_DELIVERY,4000.00,4000.00,100\n"
    ).encode("utf-8")
    import_daily_sales(db, 1, "current.csv", current, "TEST")

    issues = AnomalyEngine(db).detect(1, "2026-09-02")

    aov = next(item for item in issues if item.anomaly_type == "AOV_LOW")
    assert aov.observed_value == "40.00"
    assert aov.baseline_source.startswith("STORE_")
