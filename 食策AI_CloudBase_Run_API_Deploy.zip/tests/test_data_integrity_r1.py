from __future__ import annotations

import json
import sqlite3
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


def migrated_db(tmp_path: Path) -> Path:
    from db_v2 import migrate_database
    db = tmp_path / "r1.db"
    create_v04_db(db)
    migrate_database(db)
    return db


def test_partial_sales_correction_is_rejected_without_erasing_previous_values(tmp_path):
    from data_foundation import get_sales_trace, import_daily_sales, list_daily_sales

    db = migrated_db(tmp_path)
    full = (
        "营业日期,渠道代码,销售额,顾客实付,订单数,退款金额,退款笔数,商家优惠,平台补贴\n"
        "2026-08-27,MEITUAN_DELIVERY,1000,900,10,20,1,30,40\n"
    ).encode()
    partial = (
        "营业日期,渠道代码,销售额,订单数\n"
        "2026-08-27,MEITUAN_DELIVERY,1100,11\n"
    ).encode()

    import_daily_sales(db, 1, "full.csv", full, "MEITUAN_EXPORT")
    result = import_daily_sales(db, 1, "partial.csv", partial, "MEITUAN_EXPORT")
    row = list_daily_sales(db, 1)[0]

    assert result.status == "FAILED"
    assert result.updated_rows == 0
    assert result.rejected_rows == 1
    assert "字段不完整" in (result.error_message or "")
    assert row["gross_sales"] == "1000.00"
    assert row["order_count"] == 10
    assert row["customer_paid"] == "900.00"
    assert row["refund_amount"] == "20.00"
    assert row["refund_count"] == 1
    assert row["merchant_discount"] == "30.00"
    assert row["platform_subsidy"] == "40.00"
    assert get_sales_trace(db, row["id"])["file"]["file_name"] == "full.csv"


def test_partial_settlement_correction_is_rejected_without_erasing_existing_fields_or_fees(tmp_path):
    from data_foundation import import_settlements, list_platform_fees, list_settlements

    db = migrated_db(tmp_path)
    full = (
        "渠道代码,结算周期开始,结算周期结束,结算日期,顾客实付,佣金,配送费,商家优惠,平台应结算,结算单号\n"
        "MEITUAN_DELIVERY,2026-08-01,2026-08-07,2026-08-08,1100,100,50,20,930,S-1\n"
    ).encode()
    partial = (
        "渠道代码,结算日期,顾客实付,结算单号\n"
        "MEITUAN_DELIVERY,2026-08-08,1200,S-1\n"
    ).encode()

    import_settlements(db, 1, "full.csv", full, "MEITUAN_SETTLEMENT")
    result = import_settlements(db, 1, "partial.csv", partial, "MEITUAN_SETTLEMENT")
    row = list_settlements(db, 1)[0]
    fees = {x["fee_type"]: x["amount"] for x in list_platform_fees(db, 1)}

    assert result.status == "FAILED"
    assert result.updated_rows == 0
    assert result.rejected_rows == 1
    assert "字段不完整" in (result.error_message or "")
    assert row["customer_paid"] == "1100.00"
    assert row["commission_fee"] == "100.00"
    assert row["delivery_fee"] == "50.00"
    assert row["merchant_discount"] == "20.00"
    assert row["reported_expected_settlement"] == "930.00"
    assert fees["COMMISSION"] == "100.00"
    assert fees["DELIVERY"] == "50.00"
    assert fees["MERCHANT_DISCOUNT"] == "20.00"


def test_settlement_level_fees_do_not_fabricate_a_business_date(tmp_path):
    from data_foundation import import_settlements, list_platform_fees

    db = migrated_db(tmp_path)
    data = (
        "渠道代码,结算周期开始,结算周期结束,结算日期,佣金,平台应结算,结算单号\n"
        "MEITUAN_DELIVERY,2026-08-01,2026-08-07,2026-08-08,700,1000,S-WEEK\n"
    ).encode()
    import_settlements(db, 1, "weekly.csv", data, "MEITUAN_SETTLEMENT")
    fee = list_platform_fees(db, 1)[0]
    assert fee["business_date"] is None


def test_explicit_channel_conflict_rejects_row_instead_of_silently_mixing_batch_channel(tmp_path):
    from data_foundation import import_daily_sales, list_daily_sales

    db = migrated_db(tmp_path)
    data = (
        "营业日期,渠道代码,销售额\n"
        "2026-08-27,DOUYIN_LOCAL,1000\n"
    ).encode()
    result = import_daily_sales(
        db, 1, "conflict.csv", data, "MEITUAN_EXPORT", channel_code="MEITUAN_DELIVERY"
    )
    assert result.status == "FAILED"
    assert result.rejected_rows == 1
    assert "渠道" in (result.error_message or "")
    assert list_daily_sales(db, 1) == []


def test_manual_reconciliation_rejects_cross_channel_match(tmp_path):
    from data_foundation import (
        create_reconciliation_match,
        import_payments,
        import_settlements,
        list_payments,
        list_settlements,
    )

    db = migrated_db(tmp_path)
    settlement = (
        "渠道代码,结算日期,平台应结算,结算单号\n"
        "MEITUAN_DELIVERY,2026-08-28,1000,MT-X\n"
    ).encode()
    payment = (
        "渠道代码,到账日期,到账金额,银行流水号\n"
        "DOUYIN_LOCAL,2026-08-28,1000,BANK-X\n"
    ).encode()
    import_settlements(db, 1, "s.csv", settlement, "MEITUAN_SETTLEMENT")
    import_payments(db, 1, "p.csv", payment, "BANK_STATEMENT")
    sid = list_settlements(db, 1)[0]["id"]
    pid = list_payments(db, 1)[0]["id"]
    with pytest.raises(ValueError, match="渠道"):
        create_reconciliation_match(db, sid, pid, "1000")


def test_empty_csv_is_failed_but_still_has_auditable_import_batch(tmp_path):
    from data_foundation import import_daily_sales, list_import_batches

    db = migrated_db(tmp_path)
    result = import_daily_sales(db, 1, "empty.csv", b"", "MANUAL")
    assert result.status == "FAILED"
    assert result.row_count == 0
    assert result.import_batch_id > 0
    assert "没有" in (result.error_message or "") or "空" in (result.error_message or "")
    batches = list_import_batches(db, 1)
    assert batches[-1]["status"] == "FAILED"


def test_malformed_json_is_failed_but_still_has_auditable_import_batch(tmp_path):
    from data_foundation import import_daily_sales, list_import_batches

    db = migrated_db(tmp_path)
    result = import_daily_sales(db, 1, "bad.json", b"{not-json", "MANUAL", mime_type="application/json")
    assert result.status == "FAILED"
    assert result.import_batch_id > 0
    assert list_import_batches(db, 1)[-1]["status"] == "FAILED"


def test_common_chinese_csv_encoding_and_unpadded_date_are_accepted(tmp_path):
    from data_foundation import import_daily_sales, list_daily_sales

    db = migrated_db(tmp_path)
    data = (
        "营业日期,渠道代码,销售额\n"
        "2026/8/7,MEITUAN_DELIVERY,1000\n"
    ).encode("gb18030")
    result = import_daily_sales(db, 1, "gb.csv", data, "MEITUAN_EXPORT")
    assert result.status == "COMPLETED"
    assert list_daily_sales(db, 1)[0]["business_date"] == "2026-08-07"


def test_migration_refreshes_stale_canonical_v04_backup_before_upgrade(tmp_path):
    import hashlib
    from db_v2 import migrate_database

    db = tmp_path / "shice_ai.db"
    create_v04_db(db)
    stale = tmp_path / "shice_ai_v04_backup.db"
    stale.write_bytes(b"stale-backup")
    current_hash = hashlib.sha256(db.read_bytes()).hexdigest()

    migrate_database(db)

    assert hashlib.sha256(stale.read_bytes()).hexdigest() == current_hash
    timestamped = list(tmp_path.glob("shice_ai_v04_backup_*.db"))
    assert timestamped
    assert hashlib.sha256(timestamped[-1].read_bytes()).hexdigest() == current_hash


def test_channel_net_revenue_is_not_an_alias_of_expected_settlement():
    from data_foundation import calculate_channel_net_revenue, calculate_expected_settlement

    values = {
        "gross_sales": "1200",
        "customer_paid": "1000",
        "platform_subsidy": "100",
        "commission_fee": "50",
        "delivery_fee": "20",
        "technical_service_fee": "10",
        "promotion_fee": "5",
        "merchant_discount": "30",
        "refund_amount": "5",
        "other_fee": "0",
    }
    settlement = calculate_expected_settlement(values, "CUSTOMER_PAID_SUBSIDY_ADD_V1")
    revenue = calculate_channel_net_revenue(values, "CUSTOMER_PAID_V1")
    assert settlement != revenue
    assert str(revenue) == "1000.00"


def test_save_state_keeps_legacy_type_and_schema_v2_store_type_in_sync(monkeypatch, tmp_path):
    import app as api_app

    db = tmp_path / "app.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    state = api_app.get_state()
    state["settings"]["storeType"] = "咖啡店"
    api_app.save_state(state)
    with sqlite3.connect(db) as con:
        row = con.execute("SELECT type,store_type FROM stores WHERE id=1").fetchone()
    assert row == ("咖啡店", "咖啡店")


def test_server_backup_reset_and_restore_include_data_foundation(monkeypatch, tmp_path):
    import app as api_app

    db = tmp_path / "api.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    client = TestClient(api_app.app)
    sales = (
        "营业日期,渠道代码,销售额,顾客实付,订单数\n"
        "2026-08-27,MEITUAN_DELIVERY,1000,900,10\n"
    ).encode()

    with client:
        r = client.post(
            "/api/v2/import/sales?store_id=1&source_type=MEITUAN_EXPORT",
            files={"file": ("sales.csv", sales, "text/csv")},
        )
        assert r.status_code == 200
        backup = client.get("/api/backup")
        assert backup.status_code == 200
        payload = backup.json()
        assert payload["backup_format"] == "shice-ai-full-v1"
        assert len(payload["data_foundation"]["daily_channel_sales"]) == 1

        reset = client.post("/api/reset")
        assert reset.status_code == 200
        after_reset = client.get("/api/v2/sales/daily?store_id=1").json()["sales"]
        assert after_reset == []

        restored = client.post("/api/restore", json=payload)
        assert restored.status_code == 200
        after_restore = client.get("/api/v2/sales/daily?store_id=1").json()["sales"]
        assert len(after_restore) == 1
        assert after_restore[0]["gross_sales"] == "1000.00"


def test_empty_v2_api_upload_returns_400_and_keeps_failed_batch(monkeypatch, tmp_path):
    import app as api_app

    db = tmp_path / "api-empty.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    client = TestClient(api_app.app)
    with client:
        response = client.post(
            "/api/v2/import/sales?store_id=1&source_type=MANUAL",
            files={"file": ("empty.csv", b"", "text/csv")},
        )
        batches = client.get("/api/v2/import-batches?store_id=1").json()["import_batches"]
    assert response.status_code == 400
    assert batches[-1]["status"] == "FAILED"
    assert batches[-1]["row_count"] == 0


def test_malformed_json_v2_api_upload_returns_400_and_keeps_failed_batch(monkeypatch, tmp_path):
    import app as api_app

    db = tmp_path / "api-bad-json.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    client = TestClient(api_app.app)
    with client:
        response = client.post(
            "/api/v2/import/sales?store_id=1&source_type=MANUAL",
            files={"file": ("bad.json", b"{bad-json", "application/json")},
        )
        batches = client.get("/api/v2/import-batches?store_id=1").json()["import_batches"]
    assert response.status_code == 400
    assert batches[-1]["status"] == "FAILED"
    assert "解析" in (batches[-1]["error_message"] or "")


def test_legacy_csv_upload_accepts_gb18030_for_real_chinese_exports(monkeypatch, tmp_path):
    import app as api_app

    db = tmp_path / "api-legacy-gb.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    client = TestClient(api_app.app)
    products = (
        "商品,销量,平均实付价,单位成本\n"
        "珍珠奶茶,10,12,3\n"
    ).encode("gb18030")
    with client:
        response = client.post(
            "/api/upload/products",
            files={"file": ("products.csv", products, "text/csv")},
        )
    assert response.status_code == 200
    assert response.json()["rows"] == 1


def test_static_html_uses_v050_r1_label_and_has_no_bottom_demo_store_card():
    html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")
    assert "V0.5.0-R1" in html
    assert "食策AI V0.4" not in html
    assert 'class="store-card"' not in html
    assert "奶茶店 · 本地演示数据" not in html
