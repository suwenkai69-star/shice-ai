from __future__ import annotations

import io
import sqlite3
from pathlib import Path

from fastapi.testclient import TestClient
from openpyxl import Workbook

import app as api_app
from tests.test_mini_auth_api import FakeAuthProvider

SALES_CSV = (
    "business_date,channel_code,gross_sales,customer_paid,order_count,refund_amount\n"
    "2026-09-02,MEITUAN_DELIVERY,3860.00,3120.00,72,86.00\n"
).encode("utf-8")


def client_for(monkeypatch, tmp_path):
    db = tmp_path / "file-api.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    return TestClient(api_app.app), db


def login_and_store(client, monkeypatch):
    import mini.auth as auth_module

    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeAuthProvider("file-user"))
    token = client.post("/api/mini/v1/auth/wechat", json={"code": "x"}).json()["token"]
    store = client.post(
        "/api/mini/v1/store",
        headers={"Authorization": f"Bearer {token}"},
        json={"name": "文件测试店", "category_code": "MILK_TEA"},
    ).json()["store"]
    return token, store


def test_file_upload_is_preview_only_until_confirmed(monkeypatch, tmp_path):
    client, db = client_for(monkeypatch, tmp_path)
    with client:
        token, store = login_and_store(client, monkeypatch)
        headers = {"Authorization": f"Bearer {token}"}
        upload = client.post(
            "/api/mini/v1/uploads/file",
            headers=headers,
            files={"file": ("sales.csv", SALES_CSV, "text/csv")},
        )
        assert upload.status_code == 200, upload.text
        body = upload.json()
        assert body["status"] == "NEEDS_CONFIRMATION"
        assert body["preview"]["data_type"] == "SALES"
        with sqlite3.connect(db) as con:
            assert con.execute("SELECT COUNT(*) FROM daily_channel_sales WHERE store_id=?", (store["id"],)).fetchone()[0] == 0

        confirm = client.post(f"/api/mini/v1/uploads/{body['id']}/confirm", headers=headers)
        assert confirm.status_code == 200, confirm.text
        assert confirm.json()["status"] == "IMPORTED"

    with sqlite3.connect(db) as con:
        sales = con.execute(
            """SELECT s.gross_sales,s.customer_paid,s.order_count,s.source
               FROM daily_channel_sales s JOIN channels c ON c.id=s.channel_id
               WHERE s.store_id=? AND c.code='MEITUAN_DELIVERY'""",
            (store["id"],),
        ).fetchone()
        link = con.execute(
            "SELECT import_batch_id,confirmed_by_user_id FROM document_import_links WHERE document_id=?",
            (body["id"],),
        ).fetchone()
    assert sales == ("3860.00", "3120.00", 72, "MINI_FILE_CONFIRMED")
    assert link[0] is not None


def test_xlsx_upload_is_parsed_read_only_then_confirmed(monkeypatch, tmp_path):
    wb = Workbook()
    ws = wb.active
    ws.append(["business_date", "channel_code", "gross_sales", "order_count"])
    ws.append(["2026-09-02", "TAOBAO_FLASH", "1200.00", 24])
    raw = io.BytesIO()
    wb.save(raw)

    client, db = client_for(monkeypatch, tmp_path)
    with client:
        token, store = login_and_store(client, monkeypatch)
        headers = {"Authorization": f"Bearer {token}"}
        upload = client.post(
            "/api/mini/v1/uploads/file",
            headers=headers,
            files={"file": ("taobao.xlsx", raw.getvalue(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")},
        )
        assert upload.status_code == 200, upload.text
        assert upload.json()["preview"]["row_count"] == 1
        confirm = client.post(f"/api/mini/v1/uploads/{upload.json()['id']}/confirm", headers=headers)
        assert confirm.status_code == 200, confirm.text
    with sqlite3.connect(db) as con:
        row = con.execute(
            """SELECT s.gross_sales FROM daily_channel_sales s JOIN channels c ON c.id=s.channel_id
               WHERE s.store_id=? AND c.code='TAOBAO_FLASH'""",
            (store["id"],),
        ).fetchone()
    assert row == ("1200.00",)


def test_malformed_xlsx_leaves_failed_auditable_document(monkeypatch, tmp_path):
    client, db = client_for(monkeypatch, tmp_path)
    with client:
        token, store = login_and_store(client, monkeypatch)
        upload = client.post(
            "/api/mini/v1/uploads/file",
            headers={"Authorization": f"Bearer {token}"},
            files={"file": ("broken.xlsx", b"not-an-xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")},
        )
    assert upload.status_code == 400
    with sqlite3.connect(db) as con:
        doc = con.execute(
            "SELECT status,error_code,error_message FROM upload_documents WHERE store_id=? ORDER BY id DESC LIMIT 1",
            (store["id"],),
        ).fetchone()
    assert doc[0] == "FAILED"
    assert doc[1] == "FILE_PARSE_ERROR"
    assert doc[2]


def test_gb18030_csv_preview_and_confirm(monkeypatch, tmp_path):
    raw = "营业日期,渠道代码,营业额,订单数\n2026/9/2,MEITUAN_DELIVERY,1000.00,10\n".encode("gb18030")
    client, db = client_for(monkeypatch, tmp_path)
    with client:
        token, store = login_and_store(client, monkeypatch)
        headers = {"Authorization": f"Bearer {token}"}
        upload = client.post(
            "/api/mini/v1/uploads/file",
            headers=headers,
            files={"file": ("美团.csv", raw, "text/csv")},
        )
        assert upload.status_code == 200, upload.text
        confirm = client.post(f"/api/mini/v1/uploads/{upload.json()['id']}/confirm", headers=headers)
        assert confirm.status_code == 200, confirm.text
    with sqlite3.connect(db) as con:
        count = con.execute("SELECT COUNT(*) FROM daily_channel_sales WHERE store_id=?", (store["id"],)).fetchone()[0]
    assert count == 1


def test_xls_is_rejected_with_clear_error_and_document_audit(monkeypatch, tmp_path):
    client, db = client_for(monkeypatch, tmp_path)
    with client:
        token, store = login_and_store(client, monkeypatch)
        r = client.post(
            "/api/mini/v1/uploads/file",
            headers={"Authorization": f"Bearer {token}"},
            files={"file": ("legacy.xls", b"xls-bytes", "application/vnd.ms-excel")},
        )
    assert r.status_code == 400
    assert "XLSX" in r.json()["detail"] or "xlsx" in r.json()["detail"]
    with sqlite3.connect(db) as con:
        assert con.execute(
            "SELECT status FROM upload_documents WHERE store_id=? ORDER BY id DESC LIMIT 1", (store["id"],)
        ).fetchone()[0] == "FAILED"
