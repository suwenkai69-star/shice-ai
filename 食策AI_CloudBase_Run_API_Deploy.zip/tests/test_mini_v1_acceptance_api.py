from __future__ import annotations

from fastapi.testclient import TestClient

import app as api_app
from recognition.providers.fake import FakeRecognitionProvider
from tests.test_mini_auth_api import FakeAuthProvider


def _headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def _install_owner(monkeypatch) -> None:
    import mini.auth as auth_module

    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeAuthProvider("mini-v1-acceptance-owner"))


def _install_recognition(monkeypatch, *, day: str, gross_sales: str, order_count: int, platform: str = "MEITUAN_DELIVERY") -> None:
    import mini.upload_routes as upload_routes

    provider = FakeRecognitionProvider(
        {
            "platform": platform,
            "page_type": "DAILY_REPORT",
            "fields": {
                "BUSINESS_DATE": {"value": day, "confidence": 0.99},
                "GROSS_SALES": {"value": gross_sales, "confidence": 0.99},
                "CUSTOMER_PAID": {"value": gross_sales, "confidence": 0.98},
                "ORDER_COUNT": {"value": str(order_count), "confidence": 0.98},
                "PLATFORM_FEE": {"value": "300.00", "confidence": 0.60},
            },
        }
    )
    monkeypatch.setattr(upload_routes, "get_recognition_provider", lambda: provider)


def _upload_confirmed_image(client: TestClient, headers: dict[str, str], monkeypatch, *, day: str, gross_sales: str, order_count: int, platform: str = "MEITUAN_DELIVERY") -> int:
    _install_recognition(monkeypatch, day=day, gross_sales=gross_sales, order_count=order_count, platform=platform)
    uploaded = client.post(
        "/api/mini/v1/uploads/image",
        headers=headers,
        files={"file": (f"{platform.lower()}-{day}.png", b"fixture-image", "image/png")},
    )
    assert uploaded.status_code == 200, uploaded.text
    document_id = int(uploaded.json()["id"])

    draft = client.get(f"/api/mini/v1/uploads/{document_id}", headers=headers)
    assert draft.status_code == 200, draft.text
    body = draft.json()
    assert body["document"]["status"] == "NEEDS_CONFIRMATION"
    low_confidence = next(item for item in body["fields"] if item["field_code"] == "PLATFORM_FEE")
    assert float(low_confidence["confidence"]) < 0.70

    corrected = client.patch(
        f"/api/mini/v1/uploads/{document_id}/fields",
        headers=headers,
        json={"fields": [{"field_code": "PLATFORM_FEE", "confirmed_value": "280.00"}]},
    )
    assert corrected.status_code == 200, corrected.text

    confirmed = client.post(f"/api/mini/v1/uploads/{document_id}/confirm", headers=headers)
    assert confirmed.status_code == 200, confirmed.text
    assert confirmed.json()["status"] == "IMPORTED"
    return document_id


def _manual_store_total(client: TestClient, headers: dict[str, str], *, day: str, gross_sales: str, orders: int) -> None:
    response = client.post(
        "/api/mini/v1/manual/sales",
        headers=headers,
        json={
            "business_date": day,
            "scope": "WHOLE_STORE",
            "gross_sales": gross_sales,
            "order_count": orders,
        },
    )
    assert response.status_code == 200, response.text


def test_mini_v1_owner_journey_reaches_next_day_verification(monkeypatch, tmp_path):
    """Acceptance path: login -> store -> image confirm -> profit -> issue/action -> reminder -> next-day verify."""
    db = tmp_path / "mini-v1-acceptance.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    _install_owner(monkeypatch)

    with TestClient(api_app.app) as client:
        login = client.post("/api/mini/v1/auth/wechat", json={"code": "fixture-code"})
        assert login.status_code == 200, login.text
        token = login.json()["token"]
        headers = _headers(token)

        created = client.post(
            "/api/mini/v1/store",
            headers=headers,
            json={"name": "XX奶茶", "category_code": "MILK_TEA"},
        )
        assert created.status_code == 200, created.text

        # Build a store-specific AOV baseline using only public Mini APIs.
        for day in ("2026-08-27", "2026-08-28", "2026-08-29", "2026-08-30", "2026-08-31", "2026-09-01"):
            _manual_store_total(client, headers, day=day, gross_sales="5000.00", orders=100)

        _upload_confirmed_image(
            client,
            headers,
            monkeypatch,
            day="2026-09-02",
            gross_sales="4000.00",
            order_count=100,
        )

        labor = client.post(
            "/api/mini/v1/manual/cost",
            headers=headers,
            json={"business_date": "2026-09-02", "cost_type": "LABOR", "amount": "500.00", "basis": "ACTUAL"},
        )
        assert labor.status_code == 200, labor.text

        today = client.get("/api/mini/v1/today?date=2026-09-02", headers=headers)
        assert today.status_code == 200, today.text
        home = today.json()
        assert home["sales"]["amount"] == "4000.00"
        assert home["profit"]["status"] == "ESTIMATED_RANGE"
        assert home["profit"]["profit_low"] is not None
        assert home["profit"]["profit_high"] is not None
        assert len(home["top_issues"]) <= 3
        assert any(issue["anomaly_type"] == "AOV_LOW" for issue in home["top_issues"])

        actions = client.get("/api/mini/v1/actions?date=2026-09-02", headers=headers)
        assert actions.status_code == 200, actions.text
        action = next(item for item in actions.json()["actions"] if item["action_type"] == "AOV_RECOVERY")

        executed = client.post(
            f"/api/mini/v1/actions/{action['id']}/execute",
            headers=headers,
            json={"note": "已经调整低价套餐曝光"},
        )
        assert executed.status_code == 200, executed.text
        assert executed.json()["action"]["status"] == "WAITING_VERIFICATION"

        reminder = client.post(
            f"/api/mini/v1/actions/{action['id']}/remind",
            headers=headers,
            json={"scheduled_at": 1788386400000},
        )
        assert reminder.status_code == 200, reminder.text
        assert reminder.json()["reminder"]["status"] == "PENDING"

        _upload_confirmed_image(
            client,
            headers,
            monkeypatch,
            day="2026-09-03",
            gross_sales="4600.00",
            order_count=100,
        )

        next_day = client.get("/api/mini/v1/today?date=2026-09-03", headers=headers)
        assert next_day.status_code == 200, next_day.text
        verification = next_day.json()["yesterday_verification"]
        assert verification is not None
        assert verification["action_id"] == action["id"]
        assert verification["result"] == "IMPROVED"
        assert "执行后相关指标" in verification["explanation"]
        assert "导致" not in verification["explanation"]


def _login_create_store(client: TestClient, monkeypatch, owner: str = "acceptance-extra") -> dict[str, str]:
    import mini.auth as auth_module

    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeAuthProvider(owner))
    login = client.post("/api/mini/v1/auth/wechat", json={"code": "fixture-code"})
    assert login.status_code == 200, login.text
    headers = _headers(login.json()["token"])
    store = client.post(
        "/api/mini/v1/store",
        headers=headers,
        json={"name": "验收奶茶店", "category_code": "MILK_TEA"},
    )
    assert store.status_code == 200, store.text
    return headers


def test_same_day_cumulative_image_update_replaces_instead_of_double_counting(monkeypatch, tmp_path):
    db = tmp_path / "same-day-update.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    with TestClient(api_app.app) as client:
        headers = _login_create_store(client, monkeypatch, "same-day-owner")
        _upload_confirmed_image(client, headers, monkeypatch, day="2026-09-02", gross_sales="2000.00", order_count=40)

        _install_recognition(monkeypatch, day="2026-09-02", gross_sales="4800.00", order_count=96)
        second = client.post(
            "/api/mini/v1/uploads/image",
            headers=headers,
            files={"file": ("meituan-update.png", b"fixture-image-2", "image/png")},
        )
        assert second.status_code == 200, second.text
        doc_id = int(second.json()["id"])
        first_confirm = client.post(f"/api/mini/v1/uploads/{doc_id}/confirm", headers=headers)
        assert first_confirm.status_code == 409, first_confirm.text

        decision = client.post(
            f"/api/mini/v1/uploads/{doc_id}/duplicate-decision",
            headers=headers,
            json={"decision": "REPLACE_EXISTING"},
        )
        assert decision.status_code == 200, decision.text
        assert decision.json()["status"] == "IMPORTED"

        today = client.get("/api/mini/v1/today?date=2026-09-02", headers=headers)
        assert today.status_code == 200, today.text
        assert today.json()["sales"]["amount"] == "4800.00"


def test_pos_store_total_prevents_wechat_alipay_double_count(monkeypatch, tmp_path):
    db = tmp_path / "coverage.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    with TestClient(api_app.app) as client:
        headers = _login_create_store(client, monkeypatch, "coverage-owner")
        _upload_confirmed_image(
            client, headers, monkeypatch, day="2026-09-02", gross_sales="10000.00", order_count=200, platform="POS"
        )
        _upload_confirmed_image(
            client, headers, monkeypatch, day="2026-09-02", gross_sales="3000.00", order_count=60, platform="WECHAT_PAY"
        )
        _upload_confirmed_image(
            client, headers, monkeypatch, day="2026-09-02", gross_sales="2000.00", order_count=40, platform="ALIPAY"
        )

        today = client.get("/api/mini/v1/today?date=2026-09-02", headers=headers)
        assert today.status_code == 200, today.text
        sales = today.json()["sales"]
        assert sales["amount"] == "10000.00"
        assert sales["coverage"] == "WHOLE_STORE_TOTAL"
        assert any("不重复相加" in text for text in sales["warnings"])


def test_reconciliation_acceptance_uses_cautious_copy(monkeypatch, tmp_path):
    db = tmp_path / "reconciliation-acceptance.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    with TestClient(api_app.app) as client:
        headers = _login_create_store(client, monkeypatch, "reconciliation-owner")
        settlement = (
            "渠道代码,结算日期,平台应结算,结算单号\n"
            "MEITUAN_DELIVERY,2026-09-02,1000.00,ACC-386\n"
        ).encode("utf-8")
        payment = (
            "渠道代码,到账日期,到账金额,到账方式,银行流水号,结算单号\n"
            "MEITUAN_DELIVERY,2026-09-02,614.00,银行卡,BANK-386,ACC-386\n"
        ).encode("utf-8")
        for filename, payload in (("settlement.csv", settlement), ("payment.csv", payment)):
            uploaded = client.post(
                "/api/mini/v1/uploads/file",
                headers=headers,
                files={"file": (filename, payload, "text/csv")},
            )
            assert uploaded.status_code == 200, uploaded.text
            confirmed = client.post(f"/api/mini/v1/uploads/{uploaded.json()['id']}/confirm", headers=headers)
            assert confirmed.status_code == 200, confirmed.text

        today = client.get("/api/mini/v1/today?date=2026-09-02", headers=headers)
        assert today.status_code == 200, today.text
        body = today.json()
        assert body["reconciliation"]["status"] == "DIFFERENCE"
        assert body["reconciliation"]["difference"] == "386.00"
        assert "暂时没对上" in body["reconciliation"]["user_message"]
        assert "少给" not in body["reconciliation"]["user_message"]
        assert body["top_issues"][0]["anomaly_type"] == "RECONCILIATION_DIFFERENCE"


def test_health_reports_mini_v1_schema_v3(monkeypatch, tmp_path):
    db = tmp_path / "health.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    with TestClient(api_app.app) as client:
        response = client.get("/api/health")
    assert response.status_code == 200
    body = response.json()
    assert body["version"] == "0.5.0-R1+MiniV1"
    assert body["schema_version"] == 3
    assert body["mini_api_version"] == "v1"
    assert "data-foundation-v3" in body["engine"]
