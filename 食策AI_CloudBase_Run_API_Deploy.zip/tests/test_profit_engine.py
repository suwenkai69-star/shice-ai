from __future__ import annotations

import sqlite3
import sys
from decimal import Decimal
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_benchmark_service import insert_benchmark
from tests.test_schema_v2 import create_v04_db


@pytest.fixture
def v3_db(tmp_path):
    from db import migrate_database
    db = tmp_path / "profit.db"
    create_v04_db(db)
    migrate_database(db)
    with sqlite3.connect(db) as con:
        con.execute(
            "INSERT OR IGNORE INTO store_profiles(store_id,category_code,created_at,updated_at) VALUES(1,'MILK_TEA',1,1)"
        )
        con.commit()
    return db


def seed_store_total(db, store_id, date, amount):
    from repositories.mini_sales_repository import MiniSalesRepository
    MiniSalesRepository(db).upsert_store_total(store_id, date, amount, "MANUAL", "test")


def seed_actual_cost(db, store_id, date, cost_type, amount, basis="CONSUMED"):
    with sqlite3.connect(db) as con:
        con.execute(
            """INSERT INTO cost_entries(store_id,business_date,cost_type,amount,source_type,basis,created_at)
               VALUES(?,?,?,?,?,?,?)""",
            (store_id, date, cost_type, amount, "ACTUAL", basis, 1),
        )
        con.commit()


def test_profit_unavailable_without_real_revenue(v3_db):
    from services.profit_engine import ProfitEngine
    result = ProfitEngine(v3_db).calculate(1, "2026-09-02")
    assert result.status == "UNAVAILABLE"
    assert "营业额" in result.missing_data
    assert result.profit_low is None


def test_profit_returns_range_when_some_costs_are_benchmarks(v3_db):
    from services.profit_engine import ProfitEngine
    seed_store_total(v3_db, 1, "2026-09-02", "10000.00")
    seed_actual_cost(v3_db, 1, "2026-09-02", "LABOR", "1000.00")
    seed_actual_cost(v3_db, 1, "2026-09-02", "MARKETING", "500.00")
    insert_benchmark(v3_db, metric_code="FOOD_COST_RATE", low="0.38", mid="0.42", high="0.45")
    insert_benchmark(v3_db, metric_code="RENT_TO_SALES_RATE", low="0.10", mid="0.12", high="0.17")
    result = ProfitEngine(v3_db).calculate(1, "2026-09-02")
    assert result.status == "ESTIMATED_RANGE"
    assert result.profit_low < result.profit_high
    assert any(x.source == "INDUSTRY_BENCHMARK" for x in result.components)
    assert any(x.code == "LABOR" and x.source == "ACTUAL" for x in result.components)
    assert any(x.code == "MARKETING" and x.low == Decimal("500.00") for x in result.components)


def test_actual_food_cost_overrides_benchmark(v3_db):
    from services.profit_engine import ProfitEngine
    seed_store_total(v3_db, 1, "2026-09-02", "10000.00")
    seed_actual_cost(v3_db, 1, "2026-09-02", "FOOD", "2500.00")
    insert_benchmark(v3_db, metric_code="FOOD_COST_RATE", low="0.38", mid="0.42", high="0.45")
    result = ProfitEngine(v3_db).calculate(1, "2026-09-02")
    food = next(x for x in result.components if x.code == "FOOD")
    assert food.source == "ACTUAL"
    assert food.low == food.high == Decimal("2500.00")


def test_store_history_overrides_industry_benchmark(v3_db):
    from services.profit_engine import ProfitEngine
    for day in ("2026-08-30", "2026-08-31", "2026-09-01"):
        seed_store_total(v3_db, 1, day, "10000.00")
        seed_actual_cost(v3_db, 1, day, "FOOD", "3000.00")
    seed_store_total(v3_db, 1, "2026-09-02", "10000.00")
    insert_benchmark(v3_db, metric_code="FOOD_COST_RATE", low="0.38", mid="0.42", high="0.45")
    result = ProfitEngine(v3_db).calculate(1, "2026-09-02")
    food = next(x for x in result.components if x.code == "FOOD")
    assert food.source == "STORE_HISTORY"
    assert food.low == food.high == Decimal("3000.00")


def test_purchase_amount_is_not_treated_as_consumed_food_cost(v3_db):
    from services.profit_engine import ProfitEngine
    seed_store_total(v3_db, 1, "2026-09-02", "10000.00")
    seed_actual_cost(v3_db, 1, "2026-09-02", "FOOD", "8000.00", basis="PURCHASE")
    insert_benchmark(v3_db, metric_code="FOOD_COST_RATE", low="0.38", mid="0.42", high="0.45")
    result = ProfitEngine(v3_db).calculate(1, "2026-09-02")
    food = next(x for x in result.components if x.code == "FOOD")
    assert food.source == "INDUSTRY_BENCHMARK"


def test_weekly_settlement_fee_without_business_date_is_not_assigned_to_today(v3_db):
    from services.profit_engine import ProfitEngine
    seed_store_total(v3_db, 1, "2026-09-02", "10000.00")
    with sqlite3.connect(v3_db) as con:
        cid = con.execute("SELECT id FROM channels WHERE code='MEITUAN_DELIVERY'").fetchone()[0]
        cur = con.execute(
            """INSERT INTO settlements(store_id,channel_id,settlement_period_start,settlement_period_end,settlement_date,gross_sales,settlement_fingerprint,created_at,updated_at)
               VALUES(?,?,?,?,?,?,?,?,?)""",
            (1, cid, "2026-08-25", "2026-08-31", "2026-09-02", "7000.00", "weekly-1", 1, 1),
        )
        settlement_id = cur.lastrowid
        con.execute(
            """INSERT INTO platform_fees(store_id,channel_id,business_date,settlement_id,fee_type,amount,created_at)
               VALUES(?,?,?,?,?,?,?)""",
            (1, cid, None, settlement_id, "COMMISSION", "700.00", 1),
        )
        con.commit()
    result = ProfitEngine(v3_db).calculate(1, "2026-09-02")
    assert not any(x.code == "PLATFORM" and x.source == "ACTUAL" for x in result.components)


def test_monthly_actual_rent_is_allocated_and_kept_auditable(v3_db):
    from repositories.mini_cost_repository import MiniCostRepository
    from services.profit_engine import ProfitEngine
    seed_store_total(v3_db, 1, "2026-09-02", "10000.00")
    MiniCostRepository(v3_db).save_profile(1, {
        "rent_mode": "ACTUAL_MONTHLY",
        "monthly_rent": "12000.00",
        "operating_days_per_month": 30,
    })
    result = ProfitEngine(v3_db).calculate(1, "2026-09-02")
    rent = next(x for x in result.components if x.code == "RENT")
    assert rent.source == "ACTUAL"
    assert rent.low == rent.high == Decimal("400.00")


def test_labor_does_not_fall_back_to_generic_sales_rate_without_city_and_headcount(v3_db):
    from services.cost_resolver import CostResolver

    seed_store_total(v3_db, 1, "2026-09-02", "10000.00")
    insert_benchmark(v3_db, metric_code="LABOR_COST_RATE", low="0.13", mid="0.14", high="0.16")

    labor = CostResolver(v3_db).resolve(1, "2026-09-02", "LABOR")

    assert labor is None


def test_labor_estimate_uses_local_wages_times_headcount_and_part_time_hours(v3_db):
    from repositories.mini_cost_repository import MiniCostRepository
    from services.cost_resolver import CostResolver

    seed_store_total(v3_db, 1, "2026-09-02", "10000.00")
    with sqlite3.connect(v3_db) as con:
        con.execute("UPDATE store_profiles SET city_code='URUMQI' WHERE store_id=1")
        con.commit()
    insert_benchmark(
        v3_db,
        region_level="CITY",
        region_code="URUMQI",
        metric_code="LABOR_MONTHLY_FULL_TIME",
        low="3000",
        mid="4000",
        high="5000",
    )
    insert_benchmark(
        v3_db,
        region_level="CITY",
        region_code="URUMQI",
        metric_code="LABOR_HOURLY",
        low="18",
        mid="22",
        high="25",
    )
    MiniCostRepository(v3_db).save_profile(
        1,
        {
            "labor_cost_mode": "ESTIMATE_HEADCOUNT",
            "full_time_count": 2,
            "part_time_hours_month": "100",
            "operating_days_per_month": 30,
        },
    )

    labor = CostResolver(v3_db).resolve(1, "2026-09-02", "LABOR")

    assert labor is not None
    assert labor.source == "LOCAL_BENCHMARK"
    assert labor.low == Decimal("260.00")
    assert labor.high == Decimal("416.67")


def test_profit_is_unavailable_when_a_major_core_cost_is_still_unknown(v3_db):
    from services.profit_engine import ProfitEngine

    seed_store_total(v3_db, 1, "2026-09-02", "10000.00")
    insert_benchmark(v3_db, metric_code="FOOD_COST_RATE", low="0.38", mid="0.42", high="0.45")
    insert_benchmark(v3_db, metric_code="RENT_TO_SALES_RATE", low="0.10", mid="0.12", high="0.17")
    insert_benchmark(v3_db, metric_code="UTILITY_COST_RATE", low="0.03", mid="0.03", high="0.04")

    result = ProfitEngine(v3_db).calculate(1, "2026-09-02")

    assert result.status == "UNAVAILABLE"
    assert result.profit_low is None
    assert result.profit_high is None
    assert "人工成本" in result.missing_data


def test_manual_actual_cost_is_treated_as_actual_without_losing_source_provenance(v3_db):
    from repositories.mini_cost_repository import MiniCostRepository
    from services.cost_resolver import CostResolver

    seed_store_total(v3_db, 1, "2026-09-02", "10000.00")
    MiniCostRepository(v3_db).add_cost_entry(
        1,
        business_date="2026-09-02",
        cost_type="LABOR",
        amount="500.00",
        source_type="MINI_MANUAL",
        basis="ACTUAL",
    )

    labor = CostResolver(v3_db).resolve(1, "2026-09-02", "LABOR")

    assert labor is not None
    assert labor.source == "ACTUAL"
    assert labor.low == labor.high == Decimal("500.00")
