from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MINI = ROOT / "miniprogram"


def test_tabbar_has_exact_four_tabs():
    app = json.loads((MINI / "app.json").read_text("utf-8"))
    assert [x["text"] for x in app["tabBar"]["list"]] == ["今天", "待办", "上传", "我的"]
    assert [x["pagePath"] for x in app["tabBar"]["list"]] == [
        "pages/today/index", "pages/actions/index", "pages/upload/index", "pages/profile/index"
    ]


def test_release_config_has_no_localhost_url():
    text = (MINI / "config.js").read_text("utf-8")
    assert "127.0.0.1" not in text
    assert "localhost" not in text.lower()


def test_api_client_attaches_bearer_and_has_error_normalization():
    text = (MINI / "utils/api.js").read_text("utf-8")
    assert "Authorization" in text
    assert "Bearer " in text
    assert "401" in text
    assert "request" in text
    assert "uploadFile" in text


def test_today_first_render_uses_single_today_endpoint():
    text = (MINI / "pages/today/index.js").read_text("utf-8")
    assert 'path: "/today"' in text or "path: '/today'" in text
    for forbidden in ("/profit/today", "/issues/today", "/reconciliation/today"):
        assert forbidden not in text


def test_no_forbidden_web_navigation_labels_in_tabbar():
    app_text = (MINI / "app.json").read_text("utf-8")
    for label in ("数据中心", "经营诊断", "AI营销", "利润分析"):
        assert label not in app_text
