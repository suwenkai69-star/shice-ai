from __future__ import annotations

import sqlite3
from pathlib import Path

from fastapi.testclient import TestClient

import app as api_app
from recognition.providers.fake import FakeRecognitionProvider
from tests.test_mini_auth_api import FakeAuthProvider


def client_for(monkeypatch, tmp_path):
    db = tmp_path / "image-api.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    return TestClient(api_app.app), db


def login_and_store(client, monkeypatch):
    import mini.auth as auth_module
    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeAuthProvider("image-user"))
    token = client.post("/api/mini/v1/auth/wechat", json={"code": "x"}).json()["token"]
    store = client.post(
        "/api/mini/v1/store",
        headers={"Authorization": f"Bearer {token}"},
        json={"name": "截图测试店", "category_code": "MILK_TEA"},
    ).json()["store"]
    return token, store


def install_fake_recognition(monkeypatch):
    import mini.upload_routes as upload_routes
    provider = FakeRecognitionProvider({
        "platform": "MEITUAN_DELIVERY",
        "page_type": "DAILY_REPORT",
        "fields": {
            "BUSINESS_DATE": {"value": "2026-09-02", "confidence": 0.99},
            "GROSS_SALES": {"value": "3860.00", "confidence": 0.98},
            "CUSTOMER_PAID": {"value": "3120.00", "confidence": 0.95},
            "ORDER_COUNT": {"value": "72", "confidence": 0.96},
            "PLATFORM_FEE": {"value": "426.00", "confidence": 0.61},
        },
    })
    monkeypatch.setattr(upload_routes, "get_recognition_provider", lambda: provider)


def test_low_confidence_field_can_be_corrected_before_import(monkeypatch, tmp_path):
    client, db = client_for(monkeypatch, tmp_path)
    install_fake_recognition(monkeypatch)
    with client:
        token, store = login_and_store(client, monkeypatch)
        headers = {"Authorization": f"Bearer {token}"}
        upload = client.post(
            "/api/mini/v1/uploads/image",
            headers=headers,
            files={"file": ("meituan.png", b"fake-png", "image/png")},
        )
        assert upload.status_code == 200, upload.text
        doc_id = upload.json()["id"]
        detail = client.get(f"/api/mini/v1/uploads/{doc_id}", headers=headers)
        assert detail.status_code == 200
        assert detail.json()["document"]["status"] == "NEEDS_CONFIRMATION"
        fee = next(x for x in detail.json()["fields"] if x["field_code"] == "PLATFORM_FEE")
        assert float(fee["confidence"]) < 0.70

        patch = client.patch(
            f"/api/mini/v1/uploads/{doc_id}/fields",
            headers=headers,
            json={"fields": [{"field_code": "PLATFORM_FEE", "confirmed_value": "406.00"}]},
        )
        assert patch.status_code == 200, patch.text
        confirmed = client.post(f"/api/mini/v1/uploads/{doc_id}/confirm", headers=headers)
        assert confirmed.status_code == 200, confirmed.text
        assert confirmed.json()["status"] == "IMPORTED"

    with sqlite3.connect(db) as con:
        sale = con.execute(
            """SELECT s.gross_sales,s.customer_paid,s.order_count,s.source
               FROM daily_channel_sales s JOIN channels c ON c.id=s.channel_id
               WHERE s.store_id=? AND c.code='MEITUAN_DELIVERY'""",
            (store["id"],),
        ).fetchone()
        fee_row = con.execute(
            """SELECT f.amount,f.business_date,f.fee_type FROM platform_fees f JOIN channels c ON c.id=f.channel_id
               WHERE f.store_id=? AND c.code='MEITUAN_DELIVERY'""",
            (store["id"],),
        ).fetchone()
    assert sale == ("3860.00", "3120.00", 72, "MINI_OCR_CONFIRMED")
    assert fee_row == ("406.00", "2026-09-02", "OTHER")


def test_image_confirm_requires_required_template_fields(monkeypatch, tmp_path):
    import mini.upload_routes as upload_routes
    provider = FakeRecognitionProvider({
        "platform": "MEITUAN_DELIVERY", "page_type": "DAILY_REPORT",
        "fields": {"GROSS_SALES": {"value": "1000", "confidence": 0.99}},
    })
    monkeypatch.setattr(upload_routes, "get_recognition_provider", lambda: provider)
    client, _ = client_for(monkeypatch, tmp_path)
    with client:
        token, _ = login_and_store(client, monkeypatch)
        headers = {"Authorization": f"Bearer {token}"}
        upload = client.post("/api/mini/v1/uploads/image", headers=headers, files={"file": ("x.png", b"img", "image/png")})
        r = client.post(f"/api/mini/v1/uploads/{upload.json()['id']}/confirm", headers=headers)
    assert r.status_code == 400
    assert "BUSINESS_DATE" in r.json()["detail"]


def test_unknown_platform_cannot_auto_import(monkeypatch, tmp_path):
    import mini.upload_routes as upload_routes
    provider = FakeRecognitionProvider({
        "platform": "UNKNOWN_PLATFORM", "page_type": "UNKNOWN_PAGE",
        "fields": {"UNKNOWN_FIELD": {"value": "1000", "confidence": 0.99}},
    })
    monkeypatch.setattr(upload_routes, "get_recognition_provider", lambda: provider)
    client, _ = client_for(monkeypatch, tmp_path)
    with client:
        token, _ = login_and_store(client, monkeypatch)
        headers = {"Authorization": f"Bearer {token}"}
        upload = client.post("/api/mini/v1/uploads/image", headers=headers, files={"file": ("x.png", b"img", "image/png")})
        r = client.post(f"/api/mini/v1/uploads/{upload.json()['id']}/confirm", headers=headers)
    assert r.status_code == 400
    assert "模板" in r.json()["detail"] or "平台" in r.json()["detail"]
