from __future__ import annotations

import json
import sqlite3
import sys
from decimal import Decimal
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


@pytest.fixture
def v3_db(tmp_path):
    from db import migrate_database
    db = tmp_path / "mini.db"
    create_v04_db(db)
    migrate_database(db)
    return db


def insert_benchmark(
    db,
    *,
    category_code="MILK_TEA",
    region_level="COUNTRY",
    region_code="CN",
    metric_code="FOOD_COST_RATE",
    low="0.35",
    mid="0.40",
    high="0.45",
    review_status="APPROVED",
    source_name="Source",
    source_url="https://example.com/source",
    source_date="2026-01-01",
    confidence="MEDIUM",
    valid_from="2026-01-01",
):
    with sqlite3.connect(db) as con:
        con.execute(
            """INSERT INTO industry_benchmarks(
                category_code,region_level,region_code,metric_code,low_value,mid_value,high_value,unit,
                source_name,source_url,source_date,confidence_level,review_status,valid_from,valid_to,created_at,updated_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                category_code, region_level, region_code, metric_code, low, mid, high, "RATE",
                source_name, source_url, source_date, confidence, review_status, valid_from, None, 1, 1,
            ),
        )
        con.commit()


def test_unapproved_benchmark_is_never_used(v3_db):
    from services.benchmark_service import BenchmarkService
    insert_benchmark(v3_db, review_status="DRAFT")
    assert BenchmarkService(v3_db).find_range("MILK_TEA", "FOOD_COST_RATE", "URUMQI") is None


def test_local_approved_benchmark_beats_national(v3_db):
    from services.benchmark_service import BenchmarkService
    insert_benchmark(v3_db, region_level="COUNTRY", region_code="CN", low="0.35", high="0.45")
    insert_benchmark(v3_db, region_level="CITY", region_code="URUMQI", low="0.38", mid="0.40", high="0.42")
    result = BenchmarkService(v3_db).find_range("MILK_TEA", "FOOD_COST_RATE", "URUMQI")
    assert result.low == Decimal("0.38")
    assert result.high == Decimal("0.42")
    assert result.region_level == "CITY"


def test_country_benchmark_is_fallback_when_city_missing(v3_db):
    from services.benchmark_service import BenchmarkService
    insert_benchmark(v3_db, region_level="COUNTRY", region_code="CN", low="0.35", high="0.45")
    result = BenchmarkService(v3_db).find_range("MILK_TEA", "FOOD_COST_RATE", "URUMQI")
    assert result.region_level == "COUNTRY"
    assert result.low == Decimal("0.35")


def test_retired_benchmark_is_not_used(v3_db):
    from services.benchmark_service import BenchmarkService
    insert_benchmark(v3_db, review_status="RETIRED")
    assert BenchmarkService(v3_db).find_range("MILK_TEA", "FOOD_COST_RATE") is None


def test_seed_loader_rejects_uncited_or_unapproved_rows(v3_db, tmp_path):
    from services.benchmark_service import BenchmarkService, BenchmarkSeedError

    bad = tmp_path / "bad.json"
    bad.write_text(json.dumps([
        {
            "category_code": "MILK_TEA",
            "region_level": "COUNTRY",
            "region_code": "CN",
            "metric_code": "FOOD_COST_RATE",
            "low_value": "0.38",
            "mid_value": "0.42",
            "high_value": "0.45",
            "unit": "RATE",
            "source_name": "",
            "source_url": "",
            "source_date": "",
            "confidence_level": "MEDIUM",
            "review_status": "APPROVED",
            "valid_from": "2026-01-01"
        }
    ]), encoding="utf-8")
    with pytest.raises(BenchmarkSeedError):
        BenchmarkService(v3_db).load_seed_file(bad)


def test_production_seed_is_valid_and_auditable(v3_db):
    from services.benchmark_service import BenchmarkService
    seed = Path(__file__).resolve().parents[1] / "data" / "benchmarks" / "benchmark_seed.json"
    inserted = BenchmarkService(v3_db).load_seed_file(seed)
    assert inserted >= 1
    result = BenchmarkService(v3_db).find_range("MILK_TEA", "FOOD_COST_RATE", None)
    assert result is not None
    assert result.source_url.startswith("http")
    assert result.source_date
