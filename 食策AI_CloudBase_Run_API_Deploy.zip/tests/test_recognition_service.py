from __future__ import annotations

import sqlite3
from pathlib import Path

from db import migrate_database
from recognition.providers.fake import FakeRecognitionProvider
from recognition.service import RecognitionService
from repositories.upload_repository import UploadRepository
from tests.test_schema_v2 import create_v04_db


def make_db(tmp_path: Path) -> Path:
    db = tmp_path / "recognition.db"
    create_v04_db(db)
    migrate_database(db)
    return db


def seed_image_document(db: Path) -> int:
    storage = Path("mini_uploads/store_1/test.png")
    target = db.parent / storage
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(b"fake-image-bytes")
    return UploadRepository(db).create_document(
        store_id=1,
        user_id=1,
        document_type="IMAGE",
        original_filename="meituan.png",
        storage_key=storage.as_posix(),
        mime_type="image/png",
    )


def test_recognition_creates_draft_not_business_fact(tmp_path):
    db = make_db(tmp_path)
    provider = FakeRecognitionProvider(
        {
            "platform": "MEITUAN_DELIVERY",
            "page_type": "DAILY_REPORT",
            "fields": {
                "BUSINESS_DATE": {"value": "2026-09-02", "confidence": 0.99},
                "GROSS_SALES": {"value": "3860.00", "confidence": 0.98},
                "PLATFORM_FEE": {"value": "426.00", "confidence": 0.61},
            },
        }
    )
    draft = RecognitionService(db, provider=provider).create_draft(seed_image_document(db))
    assert draft.status == "NEEDS_CONFIRMATION"
    assert draft.template_code == "MEITUAN_DELIVERY_DAILY_V1"
    assert any(f.confidence < 0.70 for f in draft.fields)
    with sqlite3.connect(db) as con:
        assert con.execute("SELECT COUNT(*) FROM daily_channel_sales").fetchone()[0] == 0
        assert con.execute("SELECT COUNT(*) FROM payments").fetchone()[0] == 0


def test_unknown_platform_stays_unconfirmed_and_does_not_guess_template(tmp_path):
    db = make_db(tmp_path)
    provider = FakeRecognitionProvider(
        {
            "platform": "UNKNOWN_PLATFORM",
            "page_type": "UNKNOWN_PAGE",
            "fields": {"UNKNOWN_FIELD": {"value": "3860", "confidence": 0.90}},
        }
    )
    draft = RecognitionService(db, provider=provider).create_draft(seed_image_document(db))
    assert draft.status == "NEEDS_CONFIRMATION"
    assert draft.template_code is None
    assert draft.detected_platform == "UNKNOWN_PLATFORM"
    assert draft.fields[0].field_code == "UNKNOWN_FIELD"


def test_template_definitions_cover_locked_v1_platforms_without_unproven_label_aliases():
    from recognition.templates import TEMPLATES

    expected = {
        "MEITUAN_DELIVERY_DAILY_V1",
        "TAOBAO_FLASH_DAILY_V1",
        "JD_DELIVERY_DAILY_V1",
        "DOUYIN_LOCAL_LIFE_DAILY_V1",
        "MEITUAN_DEALS_DAILY_V1",
        "WECHAT_PAY_DAILY_V1",
        "ALIPAY_DAILY_V1",
        "POS_DAILY_TOTAL_V1",
    }
    assert expected.issubset({t.code for t in TEMPLATES.values()})
    assert all(t.label_aliases == {} for t in TEMPLATES.values())


def test_startup_recovery_marks_interrupted_processing_as_retryable_failure(tmp_path):
    from recognition.service import recover_interrupted_jobs
    db = make_db(tmp_path)
    doc_id = seed_image_document(db)
    repo = UploadRepository(db)
    job_id = repo.create_extraction_job(doc_id, provider="fake", status="PROCESSING")
    repo.update_document_status(doc_id, store_id=1, status="PROCESSING")
    recovered = recover_interrupted_jobs(db)
    assert recovered >= 1
    doc = repo.get_document(doc_id, store_id=1)
    job = repo.get_latest_extraction_job(doc_id)
    assert doc["status"] == "FAILED"
    assert doc["error_code"] == "RESTART_INTERRUPTED"
    assert job["status"] == "FAILED"
    assert job["error_code"] == "RESTART_INTERRUPTED"
