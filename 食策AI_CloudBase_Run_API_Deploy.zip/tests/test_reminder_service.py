from __future__ import annotations

import sqlite3
import sys
from dataclasses import dataclass
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


@pytest.fixture
def reminder_db(tmp_path):
    from db import migrate_database
    from repositories.action_repository import ActionRepository

    db = tmp_path / "reminder.db"
    create_v04_db(db)
    migrate_database(db)
    repo = ActionRepository(db)
    action = repo.create_action(1, "2026-09-02", None, "REMIND_TEST", "明天复查", "测试", "AOV", "UP", 1)
    repo.schedule_reminder(action["id"], user_id=1, store_id=1, scheduled_at=1000)
    return db


class FakeNotificationProvider:
    def __init__(self, outcome="SENT"):
        self.outcome = outcome
        self.sent = []

    def send(self, reminder):
        from notifications.provider import SendResult

        self.sent.append(reminder)
        if self.outcome == "SENT":
            return SendResult(reminder_id=int(reminder["id"]), status="SENT")
        if self.outcome == "SKIPPED":
            return SendResult(reminder_id=int(reminder["id"]), status="SKIPPED", error="wechat not configured")
        return SendResult(reminder_id=int(reminder["id"]), status="FAILED", error="provider failed")


def _status(db, reminder_id=1):
    with sqlite3.connect(db) as con:
        return con.execute("SELECT status,error_message FROM reminders WHERE id=?", (reminder_id,)).fetchone()


def test_due_reminder_is_sent_once(reminder_db):
    from services.reminder_service import ReminderService

    fake = FakeNotificationProvider("SENT")
    first = ReminderService(reminder_db, fake).dispatch_due(now=1000)
    second = ReminderService(reminder_db, fake).dispatch_due(now=1000)

    assert [r.status for r in first] == ["SENT"]
    assert second == []
    assert len(fake.sent) == 1
    assert _status(reminder_db) == ("SENT", None)


def test_provider_failure_is_persisted_and_not_retried_implicitly(reminder_db):
    from services.reminder_service import ReminderService

    fake = FakeNotificationProvider("FAILED")
    first = ReminderService(reminder_db, fake).dispatch_due(now=1000)
    second = ReminderService(reminder_db, fake).dispatch_due(now=1000)

    assert first[0].status == "FAILED"
    assert second == []
    assert _status(reminder_db) == ("FAILED", "provider failed")


def test_missing_wechat_configuration_is_skipped_but_kept_as_in_app_pending(reminder_db):
    from services.reminder_service import ReminderService

    fake = FakeNotificationProvider("SKIPPED")
    result = ReminderService(reminder_db, fake).dispatch_due(now=1000)

    assert result[0].status == "SKIPPED"
    status, error = _status(reminder_db)
    assert status == "PENDING"
    assert "not configured" in error


def test_future_reminder_is_not_dispatched(reminder_db):
    from services.reminder_service import ReminderService

    fake = FakeNotificationProvider("SENT")
    assert ReminderService(reminder_db, fake).dispatch_due(now=999) == []
    assert fake.sent == []
