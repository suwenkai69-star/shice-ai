from __future__ import annotations

import sqlite3
from datetime import date, timedelta
from pathlib import Path

from fastapi.testclient import TestClient

import app as api_app
from db import migrate_database
from repositories.mini_sales_repository import MiniSalesRepository
from services.completeness_service import CompletenessService
from tests.test_mini_auth_api import FakeAuthProvider
from tests.test_schema_v2 import create_v04_db


def make_db(tmp_path: Path) -> Path:
    db = tmp_path / "complete.db"
    create_v04_db(db)
    migrate_database(db)
    return db


def seed_channel_sale(db: Path, day: str, channel: str, amount="100.00"):
    from data_foundation import import_daily_sales
    raw = f"business_date,channel_code,gross_sales\n{day},{channel},{amount}\n".encode()
    result = import_daily_sales(db, 1, f"{day}-{channel}.csv", raw, "TEST", channel_code=channel)
    assert result.accepted_rows == 1


def test_repeated_sources_become_expected_after_history(tmp_path):
    db = make_db(tmp_path)
    start = date(2026, 8, 20)
    for i in range(12):
        day = (start + timedelta(days=i)).isoformat()
        seed_channel_sale(db, day, "MEITUAN_DELIVERY")
        seed_channel_sale(db, day, "ALIPAY")
    status = CompletenessService(db).get_status(1, "2026-09-02")
    assert "MEITUAN_DELIVERY" in status.expected_sources
    assert "ALIPAY" in status.expected_sources


def test_five_of_last_seven_operating_days_is_expected(tmp_path):
    db = make_db(tmp_path)
    days = ["2026-08-25", "2026-08-26", "2026-08-27", "2026-08-29", "2026-08-30", "2026-08-31", "2026-09-01"]
    for idx, day in enumerate(days):
        seed_channel_sale(db, day, "ALIPAY")
        if idx < 5:
            seed_channel_sale(db, day, "MEITUAN_DELIVERY")
    status = CompletenessService(db).get_status(1, "2026-09-02")
    assert "MEITUAN_DELIVERY" in status.expected_sources


def test_current_day_received_and_missing_are_separate(tmp_path):
    db = make_db(tmp_path)
    for i in range(12):
        day = (date(2026, 8, 20) + timedelta(days=i)).isoformat()
        seed_channel_sale(db, day, "MEITUAN_DELIVERY")
        seed_channel_sale(db, day, "ALIPAY")
    seed_channel_sale(db, "2026-09-02", "MEITUAN_DELIVERY")
    status = CompletenessService(db).get_status(1, "2026-09-02")
    assert set(status.received_sources) == {"MEITUAN_DELIVERY"}
    assert "ALIPAY" in status.missing_sources
    assert status.completeness_level == "PARTIAL"


def test_user_can_declare_day_complete(tmp_path):
    db = make_db(tmp_path)
    service = CompletenessService(db)
    service.declare_complete(1, "2026-09-02")
    status = service.get_status(1, "2026-09-02")
    assert status.user_declared_complete is True
    assert status.completeness_level == "DECLARED_COMPLETE"


def client_for(monkeypatch, tmp_path):
    db = tmp_path / "complete-api.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    return TestClient(api_app.app), db


def login_store(client, monkeypatch):
    import mini.auth as auth_module
    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeAuthProvider("complete-user"))
    token = client.post("/api/mini/v1/auth/wechat", json={"code": "x"}).json()["token"]
    store = client.post(
        "/api/mini/v1/store", headers={"Authorization": f"Bearer {token}"},
        json={"name": "完整度测试店", "category_code": "MILK_TEA"},
    ).json()["store"]
    return token, store


def test_complete_api_is_scoped_to_logged_in_store(monkeypatch, tmp_path):
    client, _ = client_for(monkeypatch, tmp_path)
    with client:
        token, _ = login_store(client, monkeypatch)
        headers = {"Authorization": f"Bearer {token}"}
        done = client.post(
            "/api/mini/v1/data-status/today/complete?business_date=2026-09-02", headers=headers
        )
        fetched = client.get(
            "/api/mini/v1/data-status/today?business_date=2026-09-02", headers=headers
        )
    assert done.status_code == 200, done.text
    assert fetched.json()["data_status"]["user_declared_complete"] is True
