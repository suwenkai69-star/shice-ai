from __future__ import annotations

import sys
from datetime import datetime, timezone
from pathlib import Path

from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


def migrated_db(tmp_path: Path) -> Path:
    from db import migrate_database

    db = tmp_path / "today.db"
    create_v04_db(db)
    migrate_database(db)
    return db


def test_today_aggregator_uses_whole_store_total_without_double_counting_channel(tmp_path):
    from data_foundation import import_daily_sales
    from repositories.mini_sales_repository import MiniSalesRepository
    from services.today_aggregator import TodayAggregator

    db = migrated_db(tmp_path)
    MiniSalesRepository(db).upsert_store_total(1, "2026-09-02", "1000", "TEST", "whole", order_count=20)
    channel_csv = (
        "营业日期,渠道代码,销售额,顾客实付,订单数\n"
        "2026-09-02,MEITUAN_DELIVERY,500,450,10\n"
    ).encode()
    import_daily_sales(db, 1, "channel.csv", channel_csv, "TEST")

    result = TodayAggregator(db).build(1, "2026-09-02", datetime(2026, 9, 2, 10, 0, tzinfo=timezone.utc))

    assert result["sales"]["amount"] == "1000.00"
    assert result["sales"]["orders"] == 20
    assert result["sales"]["avg_order_value"] == "50.00"
    assert result["sales"]["coverage"] == "WHOLE_STORE_TOTAL"


def test_today_contract_contains_homepage_fields_and_max_three_issues(tmp_path):
    from repositories.insight_repository import InsightRepository
    from services.today_aggregator import TodayAggregator

    db = migrated_db(tmp_path)
    # Stored rows are overwritten by detect(), so create evidence that yields one reliable issue later.
    result = TodayAggregator(db).build(1, "2026-09-02", datetime(2026, 9, 2, 8, 30, tzinfo=timezone.utc))

    required = {
        "date", "as_of", "sales", "profit", "data_status", "top_issues",
        "reconciliation", "pending_actions", "yesterday_verification",
    }
    assert required <= result.keys()
    assert len(result["top_issues"]) <= 3
    assert result["as_of"].startswith("2026-09-02T08:30:00")


def test_today_incomplete_day_explicitly_reports_missing_sources(tmp_path):
    from repositories.mini_sales_repository import MiniSalesRepository
    from services.today_aggregator import TodayAggregator

    db = migrated_db(tmp_path)
    repo = MiniSalesRepository(db)
    for day in ("2026-08-27", "2026-08-28", "2026-08-29", "2026-08-30", "2026-08-31"):
        repo.upsert_store_total(1, day, "1000", "TEST", day, order_count=20)

    result = TodayAggregator(db).build(1, "2026-09-02", datetime(2026, 9, 2, 9, 0, tzinfo=timezone.utc))

    assert result["data_status"]["complete"] is False
    assert "WHOLE_STORE" in result["data_status"]["missing_sources"]
    assert result["sales"]["amount"] is None
    assert result["profit"]["status"] == "UNAVAILABLE"


def test_today_reconciliation_difference_is_visible_in_top_issues(tmp_path):
    from data_foundation import import_settlements
    from services.today_aggregator import TodayAggregator
    from tests.test_settlement_payment_import_v2 import settlement_csv

    db = migrated_db(tmp_path)
    import_settlements(db, 1, "s.csv", settlement_csv(expected="386.00", ref="MISSING"), "MEITUAN_SETTLEMENT")

    result = TodayAggregator(db).build(1, "2026-09-02", datetime(2026, 9, 2, 9, 0, tzinfo=timezone.utc))

    assert result["reconciliation"]["status"] == "DIFFERENCE"
    assert result["top_issues"][0]["anomaly_type"] == "RECONCILIATION_DIFFERENCE"
    assert "少给" not in result["top_issues"][0]["message"]


def test_today_api_single_call_contract(tmp_path, monkeypatch):
    import app as app_module
    import mini.auth as auth_module
    from mini.auth import WechatIdentity
    from repositories.mini_sales_repository import MiniSalesRepository

    class FakeProvider:
        def exchange_code(self, code: str):
            return WechatIdentity(openid=f"test:{code}", unionid=None)

    db = tmp_path / "api.db"
    create_v04_db(db)
    monkeypatch.setattr(app_module, "DB_PATH", db)
    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeProvider())
    client = TestClient(app_module.app)
    with client:
        login = client.post("/api/mini/v1/auth/wechat", json={"code": "owner-home"}).json()
        headers = {"Authorization": f"Bearer {login['token']}"}
        store = client.post(
            "/api/mini/v1/store",
            headers=headers,
            json={"name": "测试店", "category_code": "MILK_TEA"},
        ).json()["store"]
        MiniSalesRepository(db).upsert_store_total(
            int(store["id"]), "2026-09-02", "8420", "TEST", "home", order_count=163
        )

        r = client.get("/api/mini/v1/today?date=2026-09-02", headers=headers)

    assert r.status_code == 200
    body = r.json()
    assert body["date"] == "2026-09-02"
    assert body["sales"]["amount"] == "8420.00"
    assert len(body["top_issues"]) <= 3


def test_today_reports_pending_actions_from_action_repository(tmp_path):
    from repositories.action_repository import ActionRepository
    from services.today_aggregator import TodayAggregator

    db = migrated_db(tmp_path)
    ActionRepository(db).create_action(
        1, "2026-09-02", None, "HOME_PENDING", "今天处理", "测试", "AOV", "UP", 1
    )

    result = TodayAggregator(db).build(1, "2026-09-02", datetime(2026, 9, 2, 10, 0, tzinfo=timezone.utc))

    assert result["pending_actions"] == 1


def test_today_surfaces_latest_verification_without_causal_claim(tmp_path):
    from repositories.action_repository import ActionRepository
    from repositories.mini_sales_repository import MiniSalesRepository
    from services.today_aggregator import TodayAggregator
    from services.verification_engine import VerificationEngine

    db = migrated_db(tmp_path)
    sales = MiniSalesRepository(db)
    sales.upsert_store_total(1, "2026-09-01", "5000", "TEST", "before", order_count=100)
    sales.upsert_store_total(1, "2026-09-02", "5500", "TEST", "after", order_count=100)
    repo = ActionRepository(db)
    action = repo.create_action(1, "2026-09-01", None, "AOV_VERIFY", "提高客单价", "测试", "AOV", "UP", 1)
    repo.mark_executed(action["id"], 1, executed_at=1234)
    VerificationEngine(db).verify(action["id"], "2026-09-02")

    result = TodayAggregator(db).build(1, "2026-09-02", datetime(2026, 9, 2, 10, 0, tzinfo=timezone.utc))

    verification = result["yesterday_verification"]
    assert verification["result"] == "IMPROVED"
    assert "执行后相关指标" in verification["explanation"]
    assert "导致" not in verification["explanation"]


def test_today_automatically_verifies_executed_previous_day_action(tmp_path):
    from repositories.action_repository import ActionRepository
    from repositories.mini_sales_repository import MiniSalesRepository
    from services.today_aggregator import TodayAggregator

    db = migrated_db(tmp_path)
    sales = MiniSalesRepository(db)
    sales.upsert_store_total(1, "2026-09-02", "4000", "TEST", "before", order_count=100)
    sales.upsert_store_total(1, "2026-09-03", "4600", "TEST", "after", order_count=100)
    repo = ActionRepository(db)
    action = repo.create_action(1, "2026-09-02", None, "AOV_RECOVERY", "提高客单价", "测试", "AOV", "UP", 1)
    repo.mark_executed(action["id"], 1, executed_at=1234)
    repo.schedule_reminder(action["id"], user_id=1, store_id=1, scheduled_at=2000)

    result = TodayAggregator(db).build(1, "2026-09-03", datetime(2026, 9, 3, 10, 0, tzinfo=timezone.utc))

    verification = result["yesterday_verification"]
    assert verification is not None
    assert verification["action_id"] == action["id"]
    assert verification["result"] == "IMPROVED"
    assert repo.get_action(action["id"], 1)["status"] == "VERIFIED"
