from __future__ import annotations

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fastapi.testclient import TestClient

import app as v04


def configure_temp_db(monkeypatch, tmp_path: Path) -> Path:
    db_path = tmp_path / "shice_ai.db"
    monkeypatch.setattr(v04, "DB_PATH", db_path)
    v04.init_db()
    return db_path


def test_v04_init_and_state_roundtrip(monkeypatch, tmp_path):
    configure_temp_db(monkeypatch, tmp_path)
    state = v04.get_state()
    assert state["business"] is None
    assert state["settings"]["storeName"] == "永民手作"

    state["settings"]["storeName"] = "测试门店"
    state["actions"]["platform"] = "reviewed"
    v04.save_state(state)

    loaded = v04.get_state()
    assert loaded["settings"]["storeName"] == "测试门店"
    assert loaded["actions"]["platform"] == "reviewed"


def test_v04_business_csv_normalizer_still_accepts_locked_fields():
    rows = v04.parse_csv_bytes(
        "销售收入,销量,食材成本,人员成本,现金利润,理论食材成本率,到家端收入减少比例\n"
        "77194.43,6593,18403.16,21074.08,-7025,24.33,37.95\n".encode("utf-8")
    )
    business = v04.normalize_business(rows, v04.DEFAULT_SETTINGS)
    assert business["revenue"] == 77194.43
    assert business["cups"] == 6593.0
    assert business["cashProfit"] == -7025.0


def test_v04_api_state_and_upload_remain_available(monkeypatch, tmp_path):
    configure_temp_db(monkeypatch, tmp_path)
    with TestClient(v04.app) as client:
        response = client.get("/api/state")
        assert response.status_code == 200
        assert response.json()["state"]["business"] is None

        content = (
            "销售收入,销量,食材成本,人员成本,现金利润\n"
            "1000,100,220,250,100\n"
        ).encode("utf-8")
        response = client.post(
            "/api/upload/business",
            files={"file": ("business.csv", content, "text/csv")},
        )
        assert response.status_code == 200
        assert response.json()["state"]["business"]["revenue"] == 1000.0


def test_v04_frontend_local_fallback_contract_is_present():
    html = (v04.STATIC / "index.html").read_text(encoding="utf-8")
    assert "localStorage" in html
    assert "shice_v04_state" in html
    assert "V0.4 backend unavailable, fallback local mode" in html
