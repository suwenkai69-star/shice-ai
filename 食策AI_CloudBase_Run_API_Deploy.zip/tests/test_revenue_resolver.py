from __future__ import annotations

import sqlite3
import sys
from decimal import Decimal
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


@pytest.fixture
def v3_db(tmp_path):
    from db import migrate_database
    db = tmp_path / "mini.db"
    create_v04_db(db)
    migrate_database(db)
    return db


def seed_store_total(db, store_id, date, amount):
    from repositories.mini_sales_repository import MiniSalesRepository
    MiniSalesRepository(db).upsert_store_total(store_id, date, amount, "MANUAL", "test")


def seed_channel_sale(db, store_id, date, code, amount, source="TEST"):
    with sqlite3.connect(db) as con:
        channel_id = con.execute("SELECT id FROM channels WHERE code=?", (code,)).fetchone()[0]
        con.execute(
            """INSERT INTO daily_channel_sales(store_id,business_date,channel_id,gross_sales,source,created_at,updated_at)
               VALUES(?,?,?,?,?,?,?)""",
            (store_id, date, channel_id, amount, source, 1, 1),
        )
        con.commit()


def test_whole_store_total_wins_over_overlapping_payment_channels(v3_db):
    from services.revenue_resolver import RevenueResolver
    seed_store_total(v3_db, 1, "2026-09-02", "1000.00")
    seed_channel_sale(v3_db, 1, "2026-09-02", "WECHAT_PAY", "600.00")
    seed_channel_sale(v3_db, 1, "2026-09-02", "ALIPAY", "400.00")
    result = RevenueResolver(v3_db).resolve(1, "2026-09-02")
    assert result.amount == Decimal("1000.00")
    assert result.coverage == "WHOLE_STORE_TOTAL"
    assert result.source == "ACTUAL_STORE_TOTAL"


def test_channel_sum_is_used_when_no_whole_store_total(v3_db):
    from services.revenue_resolver import RevenueResolver
    seed_channel_sale(v3_db, 1, "2026-09-02", "MEITUAN_DELIVERY", "700.00")
    seed_channel_sale(v3_db, 1, "2026-09-02", "DOUYIN_LOCAL", "300.00")
    result = RevenueResolver(v3_db).resolve(1, "2026-09-02")
    assert result.amount == Decimal("1000.00")
    assert result.coverage == "CHANNEL_SUM"


def test_resolver_never_uses_settlement_or_payment_as_sales(v3_db):
    from services.revenue_resolver import RevenueResolver
    with sqlite3.connect(v3_db) as con:
        cid = con.execute("SELECT id FROM channels WHERE code='MEITUAN_DELIVERY'").fetchone()[0]
        con.execute(
            """INSERT INTO settlements(store_id,channel_id,settlement_date,reported_expected_settlement,calculation_profile,settlement_fingerprint,created_at,updated_at)
               VALUES(?,?,?,?,?,?,?,?)""",
            (1, cid, "2026-09-02", "999.00", "CUSTOMER_PAID_SUBSIDY_ADD_V1", "s1", 1, 1),
        )
        con.execute(
            """INSERT INTO payments(store_id,channel_id,payment_date,amount,payment_fingerprint,created_at,updated_at)
               VALUES(?,?,?,?,?,?,?)""",
            (1, cid, "2026-09-02", "888.00", "p1", 1, 1),
        )
        con.commit()
    result = RevenueResolver(v3_db).resolve(1, "2026-09-02")
    assert result.amount is None
    assert result.coverage == "NO_SALES_DATA"


def test_explicit_overlap_flag_returns_ambiguous_instead_of_summing(v3_db):
    from services.revenue_resolver import RevenueResolver
    seed_channel_sale(v3_db, 1, "2026-09-02", "WECHAT_PAY", "600.00", source="OVERLAP_POSSIBLE")
    seed_channel_sale(v3_db, 1, "2026-09-02", "MEITUAN_DELIVERY", "700.00")
    result = RevenueResolver(v3_db).resolve(1, "2026-09-02")
    assert result.amount is None
    assert result.coverage == "AMBIGUOUS_CHANNEL_SCOPE"
    assert result.warnings
