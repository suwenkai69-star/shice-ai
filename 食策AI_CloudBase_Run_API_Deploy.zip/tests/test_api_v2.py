from __future__ import annotations

import sys
from pathlib import Path

from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import app as api_app


def client_for(monkeypatch, tmp_path):
    db = tmp_path / "api.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    return TestClient(api_app.app), db


def test_v2_channels_and_legacy_state_are_both_available(monkeypatch, tmp_path):
    client, _ = client_for(monkeypatch, tmp_path)
    with client:
        legacy = client.get("/api/state")
        channels = client.get("/api/v2/channels")
        health = client.get("/api/health")
    assert legacy.status_code == 200
    assert channels.status_code == 200
    codes = {row["code"] for row in channels.json()["channels"]}
    assert {"WECHAT_PAY", "ALIPAY", "CASH", "MEITUAN_DELIVERY", "MEITUAN_FLASH", "JD_DELIVERY", "DOUYIN_LOCAL", "MEITUAN_DEALS", "OTHER"}.issubset(codes)
    assert "TAOBAO_FLASH" in codes
    assert health.json()["version"] == api_app.APP_VERSION
    assert health.json()["schema_version"] == 3
    assert health.json()["mini_api_version"] == "v1"


def test_v2_sales_import_and_listing(monkeypatch, tmp_path):
    client, _ = client_for(monkeypatch, tmp_path)
    csv_bytes = (
        "营业日期,渠道代码,销售额,顾客实付,订单数\n"
        "2026-08-27,MEITUAN_DELIVERY,10000,9000,180\n"
    ).encode()
    with client:
        r = client.post(
            "/api/v2/import/sales?store_id=1&source_type=MEITUAN_EXPORT",
            files={"file": ("sales.csv", csv_bytes, "text/csv")},
        )
        listing = client.get("/api/v2/sales/daily?store_id=1")
        batches = client.get("/api/v2/import-batches?store_id=1")
    assert r.status_code == 200
    assert r.json()["import"]["accepted_rows"] == 1
    assert listing.json()["sales"][0]["gross_sales"] == "10000.00"
    assert len(batches.json()["import_batches"]) == 1


def test_v2_settlement_payment_and_reconciliation_api(monkeypatch, tmp_path):
    client, _ = client_for(monkeypatch, tmp_path)
    settlement = (
        "渠道代码,结算日期,平台应结算,结算单号\n"
        "MEITUAN_DELIVERY,2026-08-28,1000,MT-1\n"
    ).encode()
    payment = (
        "渠道代码,到账日期,到账金额,银行流水号,结算单号\n"
        "MEITUAN_DELIVERY,2026-08-28,990,BANK-1,MT-1\n"
    ).encode()
    with client:
        sr = client.post(
            "/api/v2/import/settlements?store_id=1&source_type=MEITUAN_SETTLEMENT",
            files={"file": ("settlements.csv", settlement, "text/csv")},
        )
        pr = client.post(
            "/api/v2/import/payments?store_id=1&source_type=BANK_STATEMENT",
            files={"file": ("payments.csv", payment, "text/csv")},
        )
        settlements = client.get("/api/v2/settlements?store_id=1")
        payments = client.get("/api/v2/payments?store_id=1")
        reconciliation = client.get("/api/v2/reconciliation?store_id=1&tolerance=10.00")
    assert sr.status_code == pr.status_code == 200
    assert settlements.json()["settlements"][0]["reported_expected_settlement"] == "1000.00"
    assert payments.json()["payments"][0]["amount"] == "990.00"
    item = reconciliation.json()["settlements"][0]
    assert item["settlement_difference"] == "-10.00"
    assert item["status"] == "SMALL_DIFFERENCE"


def test_v2_invalid_upload_returns_clear_400_not_silent_success(monkeypatch, tmp_path):
    client, _ = client_for(monkeypatch, tmp_path)
    bad = b"foo,bar\n1,2\n"
    with client:
        r = client.post(
            "/api/v2/import/sales?store_id=1&source_type=UNKNOWN",
            files={"file": ("bad.csv", bad, "text/csv")},
        )
    assert r.status_code == 400
    body = r.json()
    assert "detail" in body
    assert "失败" in body["detail"] or "缺少" in body["detail"]
