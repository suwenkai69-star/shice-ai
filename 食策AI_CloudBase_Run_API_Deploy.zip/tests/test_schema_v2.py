from __future__ import annotations

import sqlite3
import sys
from decimal import Decimal
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def create_v04_db(path: Path) -> None:
    con = sqlite3.connect(path)
    try:
        con.executescript(
            """
            CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT NOT NULL, role TEXT NOT NULL);
            CREATE TABLE stores (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, name TEXT NOT NULL, type TEXT NOT NULL);
            CREATE TABLE app_state (store_id INTEGER PRIMARY KEY, json TEXT NOT NULL, updated_at INTEGER NOT NULL);
            CREATE TABLE uploads (id INTEGER PRIMARY KEY AUTOINCREMENT, store_id INTEGER NOT NULL, target TEXT NOT NULL, filename TEXT NOT NULL, row_count INTEGER NOT NULL, created_at INTEGER NOT NULL);
            INSERT INTO users(id,name,role) VALUES(1,'演示用户','owner');
            INSERT INTO stores(id,user_id,name,type) VALUES(1,1,'永民手作','奶茶店');
            INSERT INTO app_state(store_id,json,updated_at) VALUES(1,'{\"business\":null}',1);
            """
        )
        con.commit()
    finally:
        con.close()


def table_names(path: Path) -> set[str]:
    with sqlite3.connect(path) as con:
        return {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}


def columns(path: Path, table: str) -> set[str]:
    with sqlite3.connect(path) as con:
        return {r[1] for r in con.execute(f"PRAGMA table_info({table})")}


def test_v04_database_migrates_in_place_to_schema_v2(tmp_path):
    from db_v2 import get_schema_version, migrate_database

    db = tmp_path / "v04.db"
    create_v04_db(db)

    version = migrate_database(db)

    assert version == 2
    assert get_schema_version(db) == 2
    required = {
        "schema_meta",
        "channels",
        "import_files",
        "import_batches",
        "raw_import_rows",
        "daily_channel_sales",
        "settlements",
        "platform_fees",
        "payments",
        "reconciliation_matches",
    }
    assert required.issubset(table_names(db))
    assert {"store_type", "timezone", "currency", "created_at", "updated_at"}.issubset(columns(db, "stores"))

    with sqlite3.connect(db) as con:
        row = con.execute("SELECT user_id,name,type,store_type,timezone,currency FROM stores WHERE id=1").fetchone()
    assert row == (1, "永民手作", "奶茶店", "奶茶店", "Asia/Shanghai", "CNY")


def test_migration_is_idempotent_and_channel_seed_is_unique(tmp_path):
    from db_v2 import migrate_database

    db = tmp_path / "v04.db"
    create_v04_db(db)

    assert migrate_database(db) == 2
    assert migrate_database(db) == 2
    assert migrate_database(db) == 2

    with sqlite3.connect(db) as con:
        rows = con.execute("SELECT code, COUNT(*) FROM channels GROUP BY code ORDER BY code").fetchall()
    assert len(rows) == 9
    assert all(count == 1 for _, count in rows)
    assert {code for code, _ in rows} == {
        "WECHAT_PAY", "ALIPAY", "CASH", "MEITUAN_DELIVERY", "MEITUAN_FLASH",
        "JD_DELIVERY", "DOUYIN_LOCAL", "MEITUAN_DEALS", "OTHER",
    }


def test_migration_failure_rolls_back_every_schema_v2_change(tmp_path):
    from db_v2 import migrate_database

    db = tmp_path / "v04.db"
    create_v04_db(db)
    before = table_names(db)

    with pytest.raises(RuntimeError, match="injected migration failure"):
        migrate_database(db, fail_after_statement=4)

    assert table_names(db) == before
    assert "store_type" not in columns(db, "stores")
    with sqlite3.connect(db) as con:
        assert con.execute("SELECT name FROM stores WHERE id=1").fetchone()[0] == "永民手作"


def test_money_helpers_are_decimal_exact():
    from db_v2 import money, money_text

    assert money("0.1") + money("0.2") == Decimal("0.30")
    assert money_text(Decimal("0.1") + Decimal("0.2")) == "0.30"
    assert money_text("1000") == "1000.00"


def test_required_uniques_and_indexes_exist(tmp_path):
    from db_v2 import migrate_database

    db = tmp_path / "v04.db"
    create_v04_db(db)
    migrate_database(db)

    with sqlite3.connect(db) as con:
        sales_indexes = {r[1] for r in con.execute("PRAGMA index_list(daily_channel_sales)")}
        payment_indexes = {r[1] for r in con.execute("PRAGMA index_list(payments)")}
        settlement_indexes = {r[1] for r in con.execute("PRAGMA index_list(settlements)")}
    assert "uq_daily_channel_sales_store_date_channel" in sales_indexes
    assert "uq_payments_fingerprint" in payment_indexes
    assert "uq_settlements_fingerprint" in settlement_indexes

def test_v04_init_db_runs_application_schema_v3_migration(monkeypatch, tmp_path):
    import app as v04
    from db_v2 import get_schema_version

    db = tmp_path / "app-init.db"
    monkeypatch.setattr(v04, "DB_PATH", db)
    v04.init_db()
    assert get_schema_version(db) == 3

def test_migration_refuses_to_downgrade_a_newer_future_schema(tmp_path):
    from db_v2 import get_schema_version, migrate_database

    db = tmp_path / "future.db"
    create_v04_db(db)
    migrate_database(db)
    with sqlite3.connect(db) as con:
        con.execute("UPDATE schema_meta SET value='3' WHERE key='schema_version'")
        con.commit()

    with pytest.raises(RuntimeError, match="newer schema version"):
        migrate_database(db)
    assert get_schema_version(db) == 3

def test_v04_migration_creates_a_non_overwriting_backup(tmp_path):
    import hashlib
    from db_v2 import migrate_database

    db = tmp_path / "shice_ai.db"
    create_v04_db(db)
    original_hash = hashlib.sha256(db.read_bytes()).hexdigest()

    migrate_database(db)
    backup = tmp_path / "shice_ai_v04_backup.db"
    assert backup.exists()
    assert hashlib.sha256(backup.read_bytes()).hexdigest() == original_hash

    # A later migration run must not overwrite the original V0.4 backup.
    migrate_database(db)
    assert hashlib.sha256(backup.read_bytes()).hexdigest() == original_hash
