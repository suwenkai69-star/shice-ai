from __future__ import annotations

import sys
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db
from tests.test_settlement_payment_import_v2 import payment_csv, settlement_csv


def migrated_db(tmp_path: Path) -> Path:
    from db_v2 import migrate_database
    db = tmp_path / "recon.db"
    create_v04_db(db)
    migrate_database(db)
    return db


def test_calculation_profile_controls_platform_subsidy_sign_and_no_profile_fabricates_nothing():
    from data_foundation import calculate_expected_settlement

    values = {
        "customer_paid": "1000.00",
        "platform_subsidy": "100.00",
        "commission_fee": "50.00",
        "delivery_fee": "20.00",
        "technical_service_fee": "10.00",
        "promotion_fee": "0.00",
        "merchant_discount": "30.00",
        "refund_amount": "5.00",
        "other_fee": "0.00",
    }
    assert calculate_expected_settlement(values, None) is None
    assert calculate_expected_settlement(values, "CUSTOMER_PAID_SUBSIDY_ADD_V1") == Decimal("985.00")
    assert calculate_expected_settlement(values, "CUSTOMER_PAID_SUBSIDY_INCLUDED_V1") == Decimal("885.00")


def test_settlement_import_with_explicit_profile_preserves_reported_and_calculates_separately(tmp_path):
    from data_foundation import import_settlements, list_settlements

    db = migrated_db(tmp_path)
    data = (
        "渠道代码,结算周期开始,结算周期结束,结算日期,顾客实付,佣金,配送费,技术服务费,商家优惠,退款金额,平台补贴,平台应结算,结算单号,计算口径\n"
        "MEITUAN_DELIVERY,2026-08-27,2026-08-27,2026-08-28,1000,50,20,10,30,5,100,990,MT-PROFILE,CUSTOMER_PAID_SUBSIDY_ADD_V1\n"
    ).encode()
    import_settlements(db, 1, "profile.csv", data, "MEITUAN_SETTLEMENT")
    row = list_settlements(db, 1)[0]
    assert row["reported_expected_settlement"] == "990.00"
    assert row["calculated_expected_settlement"] == "985.00"
    assert row["calculation_profile"] == "CUSTOMER_PAID_SUBSIDY_ADD_V1"
    assert row["calculation_version"] == "1"


def test_reconciliation_exact_reference_match_is_matched(tmp_path):
    from data_foundation import get_reconciliation, import_payments, import_settlements

    db = migrated_db(tmp_path)
    import_settlements(db, 1, "s.csv", settlement_csv(expected="1000.00"), "MEITUAN_SETTLEMENT")
    import_payments(db, 1, "p.csv", payment_csv(amount="1000.00"), "BANK_STATEMENT")
    result = get_reconciliation(db, 1, tolerance="10.00")
    item = result["settlements"][0]
    assert item["expected_settlement"] == "1000.00"
    assert item["actual_payment"] == "1000.00"
    assert item["settlement_difference"] == "0.00"
    assert item["status"] == "MATCHED"


def test_reconciliation_small_difference_is_not_called_matched(tmp_path):
    from data_foundation import get_reconciliation, import_payments, import_settlements

    db = migrated_db(tmp_path)
    import_settlements(db, 1, "s.csv", settlement_csv(expected="1000.00"), "MEITUAN_SETTLEMENT")
    import_payments(db, 1, "p.csv", payment_csv(amount="990.00"), "BANK_STATEMENT")
    item = get_reconciliation(db, 1, tolerance="10.00")["settlements"][0]
    assert item["settlement_difference"] == "-10.00"
    assert item["status"] == "SMALL_DIFFERENCE"


def test_reconciliation_missing_payment_and_missing_settlement(tmp_path):
    from data_foundation import get_reconciliation, import_payments, import_settlements

    db = migrated_db(tmp_path)
    import_settlements(db, 1, "s.csv", settlement_csv(expected="1000.00", ref="S-ONLY"), "MEITUAN_SETTLEMENT")
    import_payments(db, 1, "p.csv", payment_csv(amount="500.00", bank_ref="BANK-X", settlement_ref="NO-SUCH"), "BANK_STATEMENT")
    result = get_reconciliation(db, 1)
    s = next(x for x in result["settlements"] if x["settlement_reference"] == "S-ONLY")
    assert s["status"] == "MISSING_PAYMENT"
    assert len(result["unmatched_payments"]) == 1
    assert result["unmatched_payments"][0]["status"] == "MISSING_SETTLEMENT"


def test_one_settlement_can_match_multiple_payments(tmp_path):
    from data_foundation import create_reconciliation_match, get_reconciliation, import_payments, import_settlements, list_payments, list_settlements

    db = migrated_db(tmp_path)
    import_settlements(db, 1, "s.csv", settlement_csv(expected="1000.00", ref="SPLIT"), "MEITUAN_SETTLEMENT")
    import_payments(db, 1, "p1.csv", payment_csv("600.00", "BANK-A", ""), "BANK_STATEMENT")
    import_payments(db, 1, "p2.csv", payment_csv("400.00", "BANK-B", ""), "BANK_STATEMENT")
    sid = list_settlements(db, 1)[0]["id"]
    payments = list_payments(db, 1)
    create_reconciliation_match(db, sid, payments[0]["id"], "600.00", "MANUAL", "HIGH")
    create_reconciliation_match(db, sid, payments[1]["id"], "400.00", "MANUAL", "HIGH")
    item = get_reconciliation(db, 1)["settlements"][0]
    assert item["actual_payment"] == "1000.00"
    assert item["status"] == "MATCHED"


def test_one_payment_can_be_allocated_across_multiple_settlements(tmp_path):
    from data_foundation import create_reconciliation_match, get_reconciliation, import_payments, import_settlements, list_payments, list_settlements

    db = migrated_db(tmp_path)
    import_settlements(db, 1, "s1.csv", settlement_csv(expected="600.00", ref="S1"), "MEITUAN_SETTLEMENT")
    import_settlements(db, 1, "s2.csv", settlement_csv(expected="400.00", ref="S2"), "MEITUAN_SETTLEMENT")
    import_payments(db, 1, "p.csv", payment_csv("1000.00", "BANK-C", ""), "BANK_STATEMENT")
    settlements = list_settlements(db, 1)
    pid = list_payments(db, 1)[0]["id"]
    s1 = next(x for x in settlements if x["settlement_reference"] == "S1")
    s2 = next(x for x in settlements if x["settlement_reference"] == "S2")
    create_reconciliation_match(db, s1["id"], pid, "600.00", "MANUAL", "HIGH")
    create_reconciliation_match(db, s2["id"], pid, "400.00", "MANUAL", "HIGH")
    result = get_reconciliation(db, 1)
    statuses = {x["settlement_reference"]: x["status"] for x in result["settlements"]}
    assert statuses == {"S1": "MATCHED", "S2": "MATCHED"}
    assert result["unmatched_payments"] == []

def test_reference_match_tracks_corrected_payment_amount(tmp_path):
    from data_foundation import get_reconciliation, import_payments, import_settlements

    db = migrated_db(tmp_path)
    import_settlements(db, 1, "s.csv", settlement_csv(expected="1001.00", ref="CORRECT"), "MEITUAN_SETTLEMENT")
    import_payments(db, 1, "p.csv", payment_csv("1000.00", "BANK-CORRECT", "CORRECT"), "BANK_STATEMENT")
    first = get_reconciliation(db, 1)["settlements"][0]
    assert first["actual_payment"] == "1000.00"

    import_payments(db, 1, "p2.csv", payment_csv("1001.00", "BANK-CORRECT", "CORRECT"), "BANK_STATEMENT")
    second = get_reconciliation(db, 1)["settlements"][0]
    assert second["actual_payment"] == "1001.00"
    assert second["status"] == "MATCHED"
