from __future__ import annotations

import sqlite3
from pathlib import Path

from fastapi.testclient import TestClient

import app as api_app
from tests.test_mini_auth_api import FakeAuthProvider


def client_for(monkeypatch, tmp_path):
    db = tmp_path / "manual-api.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    return TestClient(api_app.app), db


def login_and_store(client, monkeypatch):
    import mini.auth as auth_module

    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeAuthProvider("manual-user"))
    token = client.post("/api/mini/v1/auth/wechat", json={"code": "x"}).json()["token"]
    created = client.post(
        "/api/mini/v1/store",
        headers={"Authorization": f"Bearer {token}"},
        json={"name": "手填测试店", "category_code": "MILK_TEA"},
    )
    return token, created.json()["store"]


def test_manual_whole_store_sale_does_not_create_fake_channel(monkeypatch, tmp_path):
    client, db = client_for(monkeypatch, tmp_path)
    with client:
        token, store = login_and_store(client, monkeypatch)
        headers = {"Authorization": f"Bearer {token}"}
        r = client.post(
            "/api/mini/v1/manual/sales",
            headers=headers,
            json={
                "business_date": "2026-09-02",
                "scope": "WHOLE_STORE",
                "gross_sales": "1000.00",
                "order_count": 20,
            },
        )
    assert r.status_code == 200, r.text
    assert r.json()["record"]["scope"] == "WHOLE_STORE"
    with sqlite3.connect(db) as con:
        channel_count = con.execute(
            "SELECT COUNT(*) FROM daily_channel_sales WHERE store_id=?", (store["id"],)
        ).fetchone()[0]
        whole = con.execute(
            "SELECT gross_sales,order_count,source_kind FROM daily_store_sales_totals WHERE store_id=? AND business_date='2026-09-02'",
            (store["id"],),
        ).fetchone()
    assert channel_count == 0
    assert whole == ("1000.00", 20, "MINI_MANUAL")


def test_manual_channel_sale_requires_channel_code(monkeypatch, tmp_path):
    client, _ = client_for(monkeypatch, tmp_path)
    with client:
        token, _ = login_and_store(client, monkeypatch)
        r = client.post(
            "/api/mini/v1/manual/sales",
            headers={"Authorization": f"Bearer {token}"},
            json={"business_date": "2026-09-02", "scope": "CHANNEL", "gross_sales": "1000.00"},
        )
    assert r.status_code == 422


def test_manual_channel_sale_uses_v2_import_lineage(monkeypatch, tmp_path):
    client, db = client_for(monkeypatch, tmp_path)
    with client:
        token, store = login_and_store(client, monkeypatch)
        r = client.post(
            "/api/mini/v1/manual/sales",
            headers={"Authorization": f"Bearer {token}"},
            json={
                "business_date": "2026-09-02",
                "scope": "CHANNEL",
                "channel_code": "MEITUAN_DELIVERY",
                "gross_sales": "3860.00",
                "customer_paid": "3120.00",
                "order_count": 72,
                "refund_amount": "86.00",
            },
        )
    assert r.status_code == 200, r.text
    assert r.json()["record"]["scope"] == "CHANNEL"
    with sqlite3.connect(db) as con:
        row = con.execute(
            """SELECT s.gross_sales,s.customer_paid,s.order_count,s.source,s.import_batch_id,s.raw_import_row_id
               FROM daily_channel_sales s JOIN channels c ON c.id=s.channel_id
               WHERE s.store_id=? AND s.business_date='2026-09-02' AND c.code='MEITUAN_DELIVERY'""",
            (store["id"],),
        ).fetchone()
    assert row[:4] == ("3860.00", "3120.00", 72, "MINI_MANUAL")
    assert row[4] is not None and row[5] is not None


def test_manual_cost_and_payment_are_store_scoped(monkeypatch, tmp_path):
    client, db = client_for(monkeypatch, tmp_path)
    with client:
        token, store = login_and_store(client, monkeypatch)
        headers = {"Authorization": f"Bearer {token}"}
        cost = client.post(
            "/api/mini/v1/manual/cost",
            headers=headers,
            json={"business_date": "2026-09-02", "cost_type": "LABOR", "amount": "600.00", "basis": "ACTUAL"},
        )
        payment = client.post(
            "/api/mini/v1/manual/payment",
            headers=headers,
            json={
                "payment_date": "2026-09-02",
                "channel_code": "MEITUAN_DELIVERY",
                "amount": "2734.00",
                "bank_reference": "bank-manual-1",
            },
        )
    assert cost.status_code == 200, cost.text
    assert payment.status_code == 200, payment.text
    with sqlite3.connect(db) as con:
        c = con.execute(
            "SELECT amount,source_type,basis FROM cost_entries WHERE store_id=?", (store["id"],)
        ).fetchone()
        p = con.execute(
            "SELECT amount,source FROM payments WHERE store_id=?", (store["id"],)
        ).fetchone()
    assert c == ("600.00", "MINI_MANUAL", "ACTUAL")
    assert p == ("2734.00", "MINI_MANUAL")


def test_manual_money_validation_rejects_invalid_amount(monkeypatch, tmp_path):
    client, _ = client_for(monkeypatch, tmp_path)
    with client:
        token, _ = login_and_store(client, monkeypatch)
        r = client.post(
            "/api/mini/v1/manual/sales",
            headers={"Authorization": f"Bearer {token}"},
            json={"business_date": "2026-09-02", "scope": "WHOLE_STORE", "gross_sales": "not-money"},
        )
    assert r.status_code == 400
