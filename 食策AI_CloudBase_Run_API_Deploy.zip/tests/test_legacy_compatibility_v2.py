from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


def migrated_db(tmp_path: Path) -> Path:
    from db_v2 import migrate_database
    db = tmp_path / "legacy.db"
    create_v04_db(db)
    migrate_database(db)
    return db


def test_legacy_adapter_keeps_legacy_only_values_and_overlays_provable_v2_sales(tmp_path):
    from data_foundation import import_daily_sales, legacy_business_adapter

    db = migrated_db(tmp_path)
    legacy = {
        "revenue": 77194.43,
        "cups": 6593,
        "ingredientCost": 18403.16,
        "personnelCost": 21074.08,
        "cashProfit": -7025.0,
        "theoreticalFoodRate": 24.33,
        "deliveryReductionRate": 37.95,
        "source": "legacy",
    }
    data = (
        "营业日期,渠道代码,销售额,订单数\n"
        "2026-08-27,CASH,1000,20\n"
        "2026-08-27,ALIPAY,2000,30\n"
    ).encode()
    import_daily_sales(db, 1, "sales.csv", data, "MANUAL")

    adapted = legacy_business_adapter(db, 1, legacy)
    assert adapted["revenue"] == 3000.0
    assert adapted["cups"] == 50
    assert adapted["ingredientCost"] == legacy["ingredientCost"]
    assert adapted["personnelCost"] == legacy["personnelCost"]
    assert adapted["cashProfit"] == legacy["cashProfit"]
    assert adapted["source"] == "schema-v2+legacy"


def test_legacy_adapter_does_not_create_fake_complete_business_when_legacy_missing(tmp_path):
    from data_foundation import import_daily_sales, legacy_business_adapter

    db = migrated_db(tmp_path)
    data = b"business_date,channel_code,gross_sales\n2026-08-27,CASH,1000\n"
    import_daily_sales(db, 1, "sales.csv", data, "MANUAL")
    assert legacy_business_adapter(db, 1, None) is None


def test_legacy_adapter_does_not_overwrite_order_count_if_v2_has_unknown_orders(tmp_path):
    from data_foundation import import_daily_sales, legacy_business_adapter

    db = migrated_db(tmp_path)
    legacy = {"revenue": 100, "cups": 10, "ingredientCost": 20, "personnelCost": 30, "cashProfit": 10}
    data = b"business_date,channel_code,gross_sales\n2026-08-27,CASH,1000\n"
    import_daily_sales(db, 1, "sales.csv", data, "MANUAL")
    adapted = legacy_business_adapter(db, 1, legacy)
    assert adapted["revenue"] == 1000.0
    assert adapted["cups"] == 10
