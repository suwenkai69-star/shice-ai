from __future__ import annotations

import sqlite3

from fastapi.testclient import TestClient

import app as api_app
from recognition.providers.fake import FakeRecognitionProvider
from services.duplicate_detection import DuplicateDetectionService, ReportIdentity
from tests.test_mini_auth_api import FakeAuthProvider


def report(channel, day, time, amount, cumulative=True):
    return ReportIdentity(
        store_id=1,
        channel_code=channel,
        business_date=day,
        template_code="MEITUAN_DELIVERY_DAILY_V1",
        report_scope="CHANNEL",
        platform_reference=None,
        period_start=None,
        period_end=time,
        cumulative=cumulative,
        amount=amount,
    )


def test_later_cumulative_report_updates_instead_of_adds():
    service = DuplicateDetectionService()
    existing = report("MEITUAN_DELIVERY", "2026-09-02", "14:00", "2000.00", cumulative=True)
    later = report("MEITUAN_DELIVERY", "2026-09-02", "20:00", "4800.00", cumulative=True)
    assert service.classify(later, existing) == "UPDATE"


def test_ambiguous_same_day_report_requires_user_choice():
    service = DuplicateDetectionService()
    existing = report("MEITUAN_DELIVERY", "2026-09-02", None, "2000.00", cumulative=True)
    later = report("MEITUAN_DELIVERY", "2026-09-02", None, "4800.00", cumulative=True)
    assert service.classify(later, existing) == "POSSIBLE_DUPLICATE"


def test_amount_alone_never_proves_update():
    service = DuplicateDetectionService()
    existing = report("MEITUAN_DELIVERY", "2026-09-02", None, "2000.00", cumulative=False)
    later = report("MEITUAN_DELIVERY", "2026-09-02", None, "4800.00", cumulative=False)
    assert service.classify(later, existing) == "POSSIBLE_DUPLICATE"


def test_different_channel_or_date_is_new():
    service = DuplicateDetectionService()
    a = report("MEITUAN_DELIVERY", "2026-09-02", "14:00", "2000.00")
    b = report("TAOBAO_FLASH", "2026-09-02", "20:00", "4800.00")
    c = report("MEITUAN_DELIVERY", "2026-09-03", "20:00", "4800.00")
    assert service.classify(b, a) == "NEW"
    assert service.classify(c, a) == "NEW"


def client_for(monkeypatch, tmp_path):
    db = tmp_path / "dup-api.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    return TestClient(api_app.app), db


def login_store(client, monkeypatch):
    import mini.auth as auth_module
    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeAuthProvider("dup-user"))
    token = client.post("/api/mini/v1/auth/wechat", json={"code": "x"}).json()["token"]
    store = client.post(
        "/api/mini/v1/store",
        headers={"Authorization": f"Bearer {token}"},
        json={"name": "重复检测店", "category_code": "MILK_TEA"},
    ).json()["store"]
    return token, store


def provider(amount):
    return FakeRecognitionProvider({
        "platform": "MEITUAN_DELIVERY", "page_type": "DAILY_REPORT",
        "fields": {
            "BUSINESS_DATE": {"value": "2026-09-02", "confidence": 0.99},
            "GROSS_SALES": {"value": amount, "confidence": 0.99},
            "CUSTOMER_PAID": {"value": amount, "confidence": 0.99},
            "ORDER_COUNT": {"value": "20", "confidence": 0.99},
        },
    })


def test_second_ambiguous_daily_image_requires_explicit_replace_decision(monkeypatch, tmp_path):
    import mini.upload_routes as upload_routes
    client, db = client_for(monkeypatch, tmp_path)
    with client:
        token, store = login_store(client, monkeypatch)
        headers = {"Authorization": f"Bearer {token}"}
        monkeypatch.setattr(upload_routes, "get_recognition_provider", lambda: provider("2000.00"))
        first = client.post("/api/mini/v1/uploads/image", headers=headers, files={"file": ("a.png", b"a", "image/png")}).json()
        assert client.post(f"/api/mini/v1/uploads/{first['id']}/confirm", headers=headers).status_code == 200

        monkeypatch.setattr(upload_routes, "get_recognition_provider", lambda: provider("4800.00"))
        second = client.post("/api/mini/v1/uploads/image", headers=headers, files={"file": ("b.png", b"b", "image/png")}).json()
        conflict = client.post(f"/api/mini/v1/uploads/{second['id']}/confirm", headers=headers)
        assert conflict.status_code == 409, conflict.text
        assert conflict.json()["detail"]["classification"] == "POSSIBLE_DUPLICATE"
        assert conflict.json()["detail"]["choices"] == ["REPLACE_EXISTING"]

        resolved = client.post(
            f"/api/mini/v1/uploads/{second['id']}/duplicate-decision",
            headers=headers,
            json={"decision": "REPLACE_EXISTING"},
        )
        assert resolved.status_code == 200, resolved.text
    with sqlite3.connect(db) as con:
        value = con.execute(
            """SELECT s.gross_sales FROM daily_channel_sales s JOIN channels c ON c.id=s.channel_id
               WHERE s.store_id=? AND c.code='MEITUAN_DELIVERY' AND s.business_date='2026-09-02'""",
            (store["id"],),
        ).fetchone()[0]
        count = con.execute(
            """SELECT COUNT(*) FROM daily_channel_sales s JOIN channels c ON c.id=s.channel_id
               WHERE s.store_id=? AND c.code='MEITUAN_DELIVERY' AND s.business_date='2026-09-02'""",
            (store["id"],),
        ).fetchone()[0]
    assert value == "4800.00"
    assert count == 1
