from __future__ import annotations

import sys
from pathlib import Path

from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db
from tests.test_settlement_payment_import_v2 import payment_csv, settlement_csv


def migrated_db(tmp_path: Path) -> Path:
    from db import migrate_database

    db = tmp_path / "recon-summary.db"
    create_v04_db(db)
    migrate_database(db)
    return db


def test_missing_payment_is_worded_as_not_reconciled_not_platform_underpayment(tmp_path):
    from data_foundation import import_settlements
    from services.reconciliation_summary import ReconciliationSummaryService

    db = migrated_db(tmp_path)
    import_settlements(
        db,
        1,
        "s.csv",
        settlement_csv(expected="1000.00", ref="S-ONLY"),
        "MEITUAN_SETTLEMENT",
    )

    summary = ReconciliationSummaryService(db).today(1, "2026-08-28")

    assert summary.status == "DIFFERENCE"
    assert summary.difference == "1000.00"
    assert "没对上" in summary.user_message
    assert "少给" not in summary.user_message


def test_exact_match_is_ok(tmp_path):
    from data_foundation import import_payments, import_settlements
    from services.reconciliation_summary import ReconciliationSummaryService

    db = migrated_db(tmp_path)
    import_settlements(db, 1, "s.csv", settlement_csv(expected="1000.00"), "MEITUAN_SETTLEMENT")
    import_payments(db, 1, "p.csv", payment_csv(amount="1000.00"), "BANK_STATEMENT")

    summary = ReconciliationSummaryService(db).today(1, "2026-08-28")

    assert summary.status == "OK"
    assert summary.difference == "0.00"
    assert summary.user_message == "暂时没发现问题"


def test_no_reconciliation_evidence_is_insufficient_data(tmp_path):
    from services.reconciliation_summary import ReconciliationSummaryService

    db = migrated_db(tmp_path)
    summary = ReconciliationSummaryService(db).today(1, "2026-09-02")

    assert summary.status == "INSUFFICIENT_DATA"
    assert "还缺" in summary.user_message


def test_as_of_summary_keeps_older_unresolved_settlement_visible(tmp_path):
    from data_foundation import import_settlements
    from services.reconciliation_summary import ReconciliationSummaryService

    db = migrated_db(tmp_path)
    import_settlements(db, 1, "s.csv", settlement_csv(expected="1000.00"), "MEITUAN_SETTLEMENT")

    summary = ReconciliationSummaryService(db).today(1, "2026-09-02")
    assert summary.status == "DIFFERENCE"
    assert summary.difference == "1000.00"


def test_reconciliation_api_returns_headline_state(tmp_path, monkeypatch):
    import app as app_module
    import mini.auth as auth_module
    from mini.auth import WechatIdentity
    from data_foundation import import_settlements

    class FakeProvider:
        def exchange_code(self, code: str):
            return WechatIdentity(openid=f"test:{code}", unionid=None)

    db = tmp_path / "api.db"
    create_v04_db(db)
    monkeypatch.setattr(app_module, "DB_PATH", db)
    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeProvider())
    client = TestClient(app_module.app)
    with client:
        login = client.post("/api/mini/v1/auth/wechat", json={"code": "owner-r"}).json()
        headers = {"Authorization": f"Bearer {login['token']}"}
        store = client.post(
            "/api/mini/v1/store",
            headers=headers,
            json={"name": "测试店", "category_code": "MILK_TEA"},
        ).json()["store"]
        import_settlements(db, int(store["id"]), "s.csv", settlement_csv(expected="500.00"), "MEITUAN_SETTLEMENT")

        r = client.get("/api/mini/v1/reconciliation/today?date=2026-08-28", headers=headers)

    assert r.status_code == 200
    assert r.json()["reconciliation"]["status"] == "DIFFERENCE"
    assert "没对上" in r.json()["reconciliation"]["user_message"]
