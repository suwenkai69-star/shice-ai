from __future__ import annotations

import sqlite3
import sys
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


def migrated_db(tmp_path: Path) -> Path:
    from db_v2 import migrate_database
    db = tmp_path / "money-flow.db"
    create_v04_db(db)
    migrate_database(db)
    return db


def settlement_csv(expected="1000.00", commission="100.00", ref="MT-20260827") -> bytes:
    return (
        "渠道代码,结算周期开始,结算周期结束,结算日期,销售额,顾客实付,佣金,配送费,技术服务费,推广费,商家优惠,退款金额,其他费用,平台补贴,平台应结算,结算单号\n"
        f"MEITUAN_DELIVERY,2026-08-27,2026-08-27,2026-08-28,1500.00,1300.00,{commission},50.00,20.00,30.00,40.00,10.00,5.00,25.00,{expected},{ref}\n"
    ).encode("utf-8")


def payment_csv(amount="1000.00", bank_ref="BANK-001", settlement_ref="MT-20260827") -> bytes:
    return (
        "渠道代码,到账日期,到账金额,到账方式,银行流水号,结算单号,来源\n"
        f"MEITUAN_DELIVERY,2026-08-28,{amount},银行卡,{bank_ref},{settlement_ref},银行流水\n"
    ).encode("utf-8")


def test_settlement_import_persists_fee_breakdown_and_traceability(tmp_path):
    from data_foundation import import_settlements, list_platform_fees, list_settlements

    db = migrated_db(tmp_path)
    result = import_settlements(db, 1, "settlement.csv", settlement_csv(), "MEITUAN_SETTLEMENT")
    assert result.accepted_rows == 1
    assert result.duplicate_rows == 0

    rows = list_settlements(db, 1)
    assert len(rows) == 1
    s = rows[0]
    assert s["settlement_reference"] == "MT-20260827"
    assert s["reported_expected_settlement"] == "1000.00"
    assert s["calculated_expected_settlement"] is None
    assert s["commission_fee"] == "100.00"
    assert s["source_file_id"] is not None
    assert s["raw_import_row_id"] is not None

    fees = list_platform_fees(db, 1)
    fee_types = {f["fee_type"] for f in fees}
    assert fee_types == {"COMMISSION", "DELIVERY", "TECH_SERVICE", "PROMOTION", "MERCHANT_DISCOUNT", "REFUND", "OTHER"}
    assert sum(Decimal(f["amount"]) for f in fees) == Decimal("255.00")


def test_same_settlement_three_uploads_never_duplicate_or_duplicate_fees(tmp_path):
    from data_foundation import import_settlements, list_platform_fees, list_settlements

    db = migrated_db(tmp_path)
    results = [import_settlements(db, 1, "settlement.csv", settlement_csv(), "MEITUAN_SETTLEMENT") for _ in range(3)]
    assert results[0].accepted_rows == 1
    assert results[1].duplicate_rows == 1
    assert results[2].duplicate_rows == 1
    assert len(list_settlements(db, 1)) == 1
    assert len(list_platform_fees(db, 1)) == 7


def test_corrected_settlement_same_reference_updates_in_place(tmp_path):
    from data_foundation import import_settlements, list_platform_fees, list_settlements

    db = migrated_db(tmp_path)
    first = import_settlements(db, 1, "a.csv", settlement_csv(expected="1000.00", commission="100.00"), "MEITUAN_SETTLEMENT")
    second = import_settlements(db, 1, "b.csv", settlement_csv(expected="980.00", commission="120.00"), "MEITUAN_SETTLEMENT")
    assert first.accepted_rows == 1
    assert second.updated_rows == 1
    rows = list_settlements(db, 1)
    assert len(rows) == 1
    assert rows[0]["reported_expected_settlement"] == "980.00"
    fees = list_platform_fees(db, 1)
    assert len(fees) == 7
    commission = next(f for f in fees if f["fee_type"] == "COMMISSION")
    assert commission["amount"] == "120.00"


def test_payment_bank_reference_is_stable_dedup_key(tmp_path):
    from data_foundation import import_payments, list_payments

    db = migrated_db(tmp_path)
    results = [import_payments(db, 1, "bank.csv", payment_csv(), "BANK_STATEMENT") for _ in range(3)]
    assert results[0].accepted_rows == 1
    assert results[1].duplicate_rows == 1
    assert results[2].duplicate_rows == 1
    rows = list_payments(db, 1)
    assert len(rows) == 1
    assert rows[0]["amount"] == "1000.00"
    assert rows[0]["payment_fingerprint"]


def test_corrected_payment_with_same_bank_reference_updates_not_duplicates(tmp_path):
    from data_foundation import import_payments, list_payments

    db = migrated_db(tmp_path)
    import_payments(db, 1, "bank.csv", payment_csv("1000.00"), "BANK_STATEMENT")
    result = import_payments(db, 1, "bank_corrected.csv", payment_csv("1001.00"), "BANK_STATEMENT")
    assert result.updated_rows == 1
    rows = list_payments(db, 1)
    assert len(rows) == 1
    assert rows[0]["amount"] == "1001.00"


def test_payment_without_bank_reference_uses_fallback_fingerprint(tmp_path):
    from data_foundation import import_payments, list_payments

    db = migrated_db(tmp_path)
    data = payment_csv(bank_ref="")
    first = import_payments(db, 1, "bank.csv", data, "BANK_STATEMENT")
    second = import_payments(db, 1, "bank_again.csv", data, "BANK_STATEMENT")
    assert first.accepted_rows == 1
    assert second.duplicate_rows == 1
    assert len(list_payments(db, 1)) == 1


def test_settlement_and_payment_import_batches_retain_rejected_rows(tmp_path):
    from data_foundation import import_payments, import_settlements

    db = migrated_db(tmp_path)
    bad_settlement = b"channel_code,settlement_date\nMEITUAN_DELIVERY,not-a-date\n"
    sr = import_settlements(db, 1, "bad_s.csv", bad_settlement, "MEITUAN_SETTLEMENT")
    bad_payment = b"channel_code,payment_date,amount\nMEITUAN_DELIVERY,2026-08-28,xxx\n"
    pr = import_payments(db, 1, "bad_p.csv", bad_payment, "BANK_STATEMENT")
    assert sr.rejected_rows == 1 and sr.status == "FAILED"
    assert pr.rejected_rows == 1 and pr.status == "FAILED"
    with sqlite3.connect(db) as con:
        count = con.execute("SELECT COUNT(*) FROM raw_import_rows WHERE parse_status='REJECTED'").fetchone()[0]
    assert count == 2

def test_fee_and_refund_signs_are_normalized_to_positive_magnitudes(tmp_path):
    from data_foundation import import_settlements, list_platform_fees, list_settlements

    db = migrated_db(tmp_path)
    data = (
        "渠道代码,结算日期,佣金,退款金额,平台应结算,结算单号\n"
        "MEITUAN_DELIVERY,2026-08-28,-100.00,-10.00,890.00,SIGN-1\n"
    ).encode()
    import_settlements(db, 1, "negative-source.csv", data, "MEITUAN_SETTLEMENT")
    row = list_settlements(db, 1)[0]
    assert row["commission_fee"] == "100.00"
    assert row["refund_amount"] == "10.00"
    fees = {f["fee_type"]: f["amount"] for f in list_platform_fees(db, 1)}
    assert fees["COMMISSION"] == "100.00"
    assert fees["REFUND"] == "10.00"
