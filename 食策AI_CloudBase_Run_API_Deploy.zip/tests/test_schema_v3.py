from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


def table_names(path: Path) -> set[str]:
    with sqlite3.connect(path) as con:
        return {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}


def test_v2_database_migrates_to_schema_v3(tmp_path):
    from db_v2 import migrate_database as migrate_v2
    from db import migrate_database

    db = tmp_path / "mini.db"
    create_v04_db(db)
    assert migrate_v2(db) == 2
    assert migrate_database(db) == 3
    required = {
        "mini_users",
        "store_profiles",
        "daily_store_sales_totals",
        "store_cost_profiles",
        "cost_entries",
        "industry_benchmarks",
        "profit_snapshots",
    }
    assert required.issubset(table_names(db))

    with sqlite3.connect(db) as con:
        version = con.execute("SELECT value FROM schema_meta WHERE key='schema_version'").fetchone()[0]
        channel = con.execute("SELECT name,category FROM channels WHERE code='TAOBAO_FLASH'").fetchone()
    assert version == "3"
    assert channel == ("淘宝闪购", "DELIVERY")


def test_v3_migration_rolls_back_on_injected_failure(tmp_path):
    from db_v2 import get_schema_version, migrate_database as migrate_v2
    from db_v3 import migrate_v2_to_v3

    db = tmp_path / "mini.db"
    create_v04_db(db)
    migrate_v2(db)
    before = table_names(db)

    with pytest.raises(RuntimeError, match="injected v3 migration failure"):
        migrate_v2_to_v3(db, fail_after_statement=4)

    assert get_schema_version(db) == 2
    assert table_names(db) == before


def test_v3_migration_is_idempotent(tmp_path):
    from db import migrate_database

    db = tmp_path / "mini.db"
    create_v04_db(db)
    assert migrate_database(db) == 3
    assert migrate_database(db) == 3
    with sqlite3.connect(db) as con:
        count = con.execute("SELECT COUNT(*) FROM channels WHERE code='TAOBAO_FLASH'").fetchone()[0]
    assert count == 1


def test_v3_refuses_future_schema(tmp_path):
    from db import migrate_database

    db = tmp_path / "future.db"
    create_v04_db(db)
    assert migrate_database(db) == 3
    with sqlite3.connect(db) as con:
        con.execute("UPDATE schema_meta SET value='4' WHERE key='schema_version'")
        con.commit()

    with pytest.raises(RuntimeError, match="newer schema version 4"):
        migrate_database(db)
