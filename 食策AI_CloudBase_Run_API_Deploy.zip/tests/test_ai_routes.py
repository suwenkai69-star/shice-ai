from __future__ import annotations

import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


class FakeTextProvider:
    def __init__(self):
        self.calls = []

    def generate(self, system: str, user: str) -> str:
        self.calls.append((system, user))
        return "这是基于已确认经营数据生成的测试回答。"


@pytest.fixture
def ai_client(tmp_path, monkeypatch):
    import app as app_module
    import mini.auth as auth_module
    import ai.provider as provider_module
    from mini.auth import WechatIdentity

    class FakeAuthProvider:
        def exchange_code(self, code: str):
            return WechatIdentity(openid=f"test:{code}", unionid=None)

    db = tmp_path / "ai-api.db"
    create_v04_db(db)
    monkeypatch.setattr(app_module, "DB_PATH", db)
    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeAuthProvider())
    fake = FakeTextProvider()
    monkeypatch.setattr(provider_module, "get_text_provider", lambda: fake)
    client = TestClient(app_module.app)
    with client:
        login = client.post("/api/mini/v1/auth/wechat", json={"code": "ai-owner"}).json()
        headers = {"Authorization": f"Bearer {login['token']}"}
        store = client.post(
            "/api/mini/v1/store", headers=headers,
            json={"name": "AI测试店", "category_code": "MILK_TEA"},
        ).json()["store"]
        yield client, headers, int(store["id"]), db, fake


def test_ai_chat_returns_missing_data_without_calling_model(ai_client):
    client, headers, store_id, db, fake = ai_client

    r = client.post(
        "/api/mini/v1/ai/chat",
        headers=headers,
        json={"question": "我今天人工是不是太高？", "date": "2026-09-02"},
    )

    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "NEEDS_DATA"
    assert "人工" in body["missing_data"]
    assert body["next_action"]["type"] == "ADD_LABOR_DATA"
    assert fake.calls == []


def test_ai_chat_uses_structured_context_when_sufficient(ai_client):
    from repositories.mini_sales_repository import MiniSalesRepository

    client, headers, store_id, db, fake = ai_client
    MiniSalesRepository(db).upsert_store_total(store_id, "2026-09-02", "1000", "MANUAL", "m1", order_count=20)

    r = client.post(
        "/api/mini/v1/ai/chat",
        headers=headers,
        json={"question": "今天卖得怎么样？", "date": "2026-09-02"},
    )

    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ANSWER"
    assert body["answer"] == "这是基于已确认经营数据生成的测试回答。"
    assert len(fake.calls) == 1
    system, user = fake.calls[0]
    assert "不得编造数字" in system
    assert '"amount": "1000.00"' in user


def test_generate_copy_is_draft_only_and_does_not_execute_action(ai_client):
    from repositories.action_repository import ActionRepository

    client, headers, store_id, db, fake = ai_client
    action = ActionRepository(db).create_action(
        store_id, "2026-09-02", None, "COPY_TEST", "今晚主推双人套餐", "客单价偏低",
        "AOV", "UP", 1,
    )

    r = client.post(
        f"/api/mini/v1/actions/{action['id']}/generate-copy",
        headers=headers,
        json={"output_type": "WECHAT_GROUP"},
    )

    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "DRAFT"
    assert body["output_type"] == "WECHAT_GROUP"
    assert body["auto_published"] is False
    assert ActionRepository(db).get_action(action["id"], store_id)["status"] == "PENDING"
    assert len(fake.calls) == 1


def test_generate_copy_rejects_unsupported_output_type(ai_client):
    from repositories.action_repository import ActionRepository

    client, headers, store_id, db, fake = ai_client
    action = ActionRepository(db).create_action(
        store_id, "2026-09-02", None, "COPY_BAD", "测试", "测试", "AOV", "UP", 1
    )
    r = client.post(
        f"/api/mini/v1/actions/{action['id']}/generate-copy",
        headers=headers,
        json={"output_type": "AUTO_PUBLISH"},
    )
    assert r.status_code == 400
    assert fake.calls == []
