from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from db import migrate_database
from repositories.upload_repository import UploadRepository
from repositories.data_status_repository import DataStatusRepository
from tests.test_schema_v2 import create_v04_db


def table_names(path: Path) -> set[str]:
    with sqlite3.connect(path) as con:
        return {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}


@pytest.fixture()
def v3_db(tmp_path: Path) -> Path:
    db = tmp_path / "mini-ingestion.db"
    create_v04_db(db)
    assert migrate_database(db) == 3
    return db


def test_ingestion_tables_exist(v3_db: Path):
    required = {
        "upload_documents",
        "extraction_jobs",
        "extracted_fields",
        "document_import_links",
        "store_data_sources",
        "daily_data_status",
    }
    assert required.issubset(table_names(v3_db))


def test_upload_document_status_constraint_includes_rejected(v3_db: Path):
    with sqlite3.connect(v3_db) as con:
        ddl = con.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='upload_documents'"
        ).fetchone()[0]
    for status in (
        "UPLOADED",
        "PROCESSING",
        "NEEDS_CONFIRMATION",
        "CONFIRMED",
        "IMPORTED",
        "FAILED",
        "REJECTED",
    ):
        assert status in ddl


def test_upload_repository_keeps_store_scope_and_raw_evidence(v3_db: Path):
    repo = UploadRepository(v3_db)
    doc_id = repo.create_document(
        store_id=1,
        user_id=1,
        document_type="IMAGE",
        original_filename="meituan.png",
        storage_key="private/store-1/meituan.png",
        mime_type="image/png",
        business_date="2026-09-02",
        report_scope="CHANNEL",
    )
    doc = repo.get_document(doc_id, store_id=1)
    assert doc is not None
    assert doc["store_id"] == 1
    assert doc["status"] == "UPLOADED"
    assert doc["storage_key"] == "private/store-1/meituan.png"
    assert repo.get_document(doc_id, store_id=999) is None


def test_data_status_repository_upserts_one_row_per_store_day(v3_db: Path):
    repo = DataStatusRepository(v3_db)
    repo.upsert_daily_status(
        store_id=1,
        business_date="2026-09-02",
        expected_source_count=3,
        received_source_count=2,
        user_declared_complete=False,
        completeness_level="PARTIAL",
        as_of_time=123,
    )
    repo.upsert_daily_status(
        store_id=1,
        business_date="2026-09-02",
        expected_source_count=3,
        received_source_count=3,
        user_declared_complete=True,
        completeness_level="COMPLETE",
        as_of_time=456,
    )
    row = repo.get_daily_status(1, "2026-09-02")
    assert row["received_source_count"] == 3
    assert row["user_declared_complete"] == 1
    with sqlite3.connect(v3_db) as con:
        count = con.execute(
            "SELECT COUNT(*) FROM daily_data_status WHERE store_id=1 AND business_date='2026-09-02'"
        ).fetchone()[0]
    assert count == 1
