from __future__ import annotations

from fastapi.testclient import TestClient


def test_cloud_cron_endpoint_requires_shared_secret(monkeypatch):
    import app as api_app

    monkeypatch.setenv('CRON_SECRET', 'cron-secret-test')
    client = TestClient(api_app.app)
    response = client.get('/api/mini/v1/internal/reminders/dispatch')
    assert response.status_code == 401


def test_cloud_cron_endpoint_dispatches_against_runtime_database(monkeypatch):
    import app as api_app
    import mini.reminder_routes as reminder_routes

    monkeypatch.setenv('CRON_SECRET', 'cron-secret-test')
    seen = {}

    class FakeService:
        def __init__(self, database, provider):
            seen['database'] = database
            seen['provider'] = provider

        def dispatch_due(self, now):
            seen['now'] = now
            from notifications.provider import SendResult
            return [SendResult(reminder_id=1, status='SENT')]

    fake_db = object()
    monkeypatch.setattr(api_app.app.state, 'database', fake_db, raising=False)
    monkeypatch.setattr(reminder_routes, 'ReminderService', FakeService)
    monkeypatch.setattr(reminder_routes, 'get_database', lambda: fake_db)

    client = TestClient(api_app.app)
    response = client.get(
        '/api/mini/v1/internal/reminders/dispatch',
        headers={'Authorization': 'Bearer cron-secret-test'},
    )
    assert response.status_code == 200, response.text
    assert response.json()['counts'] == {'SENT': 1, 'FAILED': 0, 'SKIPPED': 0}
    assert seen['database'] is fake_db
    assert isinstance(seen['now'], int)


def test_production_route_allowlist_includes_internal_reminder_dispatch():
    import app as api_app
    assert api_app.production_route_allowed('/api/mini/v1/internal/reminders/dispatch')
