from __future__ import annotations

from datetime import datetime, timezone

from persistence.database import Database
from tests.test_schema_v2 import create_v04_db


def test_today_aggregator_passes_database_object_to_verification_engine(monkeypatch, tmp_path):
    """Cloud services must not collapse a PostgreSQL Database back to sqlite_path=None."""
    from db import migrate_database
    import services.today_aggregator as today_module

    path = tmp_path / "today-target.db"
    create_v04_db(path)
    migrate_database(path)
    database = Database.sqlite(path)
    seen = {}

    class RecordingVerificationEngine:
        def __init__(self, target):
            seen["target"] = target

        def verify(self, action_id: int, verification_date: str):  # pragma: no cover - no candidate in this fixture
            raise AssertionError("unexpected verification candidate")

    monkeypatch.setattr(today_module, "VerificationEngine", RecordingVerificationEngine)

    today_module.TodayAggregator(database).build(
        1,
        "2026-09-02",
        datetime(2026, 9, 2, 10, 0, tzinfo=timezone.utc),
    )

    assert seen["target"] is database
    database.dispose()
