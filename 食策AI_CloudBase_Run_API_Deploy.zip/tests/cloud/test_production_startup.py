from __future__ import annotations

from pathlib import Path

import pytest


def test_init_runtime_uses_postgres_schema_check_and_system_seed_without_local_init(monkeypatch, tmp_path):
    import app as api_app

    class FakeDB:
        backend = "postgresql"

    fake = FakeDB()
    calls = []
    monkeypatch.setattr(api_app, "build_runtime_database", lambda _path: fake)
    monkeypatch.setattr(api_app, "init_sqlite_local", lambda _path: calls.append("local"))
    monkeypatch.setattr(api_app, "init_postgres_production", lambda db: calls.append(("postgres", db)))
    result = api_app.init_runtime()
    assert result is fake
    assert calls == [("postgres", fake)]
    assert api_app.app.state.database is fake


def test_init_postgres_production_checks_schema_and_seeds_system_data_only(monkeypatch, tmp_path):
    import app as api_app

    class FakeDB:
        backend = "postgresql"

    fake = FakeDB()
    calls = []
    monkeypatch.setattr(api_app, "assert_cloud_schema", lambda db: calls.append(("schema", db)))
    monkeypatch.setattr(api_app, "seed_system_data", lambda db, path: calls.append(("seed", db, path)))
    monkeypatch.setattr(api_app, "recover_interrupted_jobs", lambda *_: (_ for _ in ()).throw(AssertionError("must not recover cloud files")))
    api_app.init_postgres_production(fake)
    assert calls[0] == ("schema", fake)
    assert calls[1][0:2] == ("seed", fake)
    assert calls[1][2].name == "benchmark_seed.json"


def test_production_route_allowlist_is_health_and_mini_only():
    import app as api_app

    allowed = ["/api/health", "/api/mini/v1/today", "/api/mini/v1/uploads/file"]
    blocked = ["/", "/static/index.html", "/api/state", "/api/session", "/api/v2/channels", "/api/backup"]
    assert all(api_app.production_route_allowed(path) for path in allowed)
    assert all(not api_app.production_route_allowed(path) for path in blocked)


def test_local_init_still_creates_demo_store(monkeypatch, tmp_path):
    import app as api_app

    db = tmp_path / "local.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_sqlite_local(db)
    import sqlite3
    with sqlite3.connect(db) as con:
        assert con.execute("SELECT name FROM stores WHERE id=1").fetchone()[0] == "永民手作"
        assert con.execute("SELECT COUNT(*) FROM app_state WHERE store_id=1").fetchone()[0] == 1


def test_health_payload_does_not_expose_database_secrets(monkeypatch):
    import app as api_app

    class FakeDB:
        backend = "postgresql"

    monkeypatch.setattr(api_app.app.state, "database", FakeDB(), raising=False)
    payload = api_app.health()
    assert payload["status"] == "ok"
    assert payload["schema_version"] == 3
    assert payload["cloud_schema_version"] == 1
    assert payload["database_backend"] == "postgresql"
    forbidden = ("host", "database_url", "password", "username", "user")
    assert not any(key in payload for key in forbidden)
