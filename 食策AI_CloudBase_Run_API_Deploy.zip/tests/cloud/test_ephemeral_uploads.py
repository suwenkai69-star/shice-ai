from __future__ import annotations

import sqlite3
from fastapi.testclient import TestClient

import app as api_app
from recognition.providers.fake import FakeRecognitionProvider
from tests.test_mini_auth_api import FakeAuthProvider

SALES_CSV = b"business_date,channel_code,gross_sales,order_count\n2026-09-02,MEITUAN_DELIVERY,3860.00,72\n"


def client_for(monkeypatch, tmp_path):
    db = tmp_path / "ephemeral.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    return TestClient(api_app.app), db


def login_store(client, monkeypatch):
    import mini.auth as auth_module
    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeAuthProvider("ephemeral-user"))
    token = client.post("/api/mini/v1/auth/wechat", json={"code": "x"}).json()["token"]
    store = client.post(
        "/api/mini/v1/store",
        headers={"Authorization": f"Bearer {token}"},
        json={"name": "临时上传测试店", "category_code": "MILK_TEA"},
    ).json()["store"]
    return token, store


def test_upload_routes_do_not_persist_raw_files_or_background_recognition():
    from pathlib import Path
    text = (Path(__file__).resolve().parents[2] / "mini/upload_routes.py").read_text(encoding="utf-8")
    for forbidden in ("mini_uploads", "write_bytes", "BackgroundTasks", "_store_raw", "_run_recognition"):
        assert forbidden not in text


def test_file_upload_persists_structured_draft_not_raw_bytes(monkeypatch, tmp_path):
    client, db = client_for(monkeypatch, tmp_path)
    with client:
        token, store = login_store(client, monkeypatch)
        headers = {"Authorization": f"Bearer {token}"}
        uploaded = client.post(
            "/api/mini/v1/uploads/file",
            headers=headers,
            files={"file": ("sales.csv", SALES_CSV, "text/csv")},
        )
        assert uploaded.status_code == 200, uploaded.text
        doc_id = uploaded.json()["id"]
        detail = client.get(f"/api/mini/v1/uploads/{doc_id}", headers=headers)
        assert detail.status_code == 200
        assert detail.json()["preview"]["data_type"] == "SALES"
        confirmed = client.post(f"/api/mini/v1/uploads/{doc_id}/confirm", headers=headers)
        assert confirmed.status_code == 200, confirmed.text

    with sqlite3.connect(db) as con:
        con.row_factory = sqlite3.Row
        doc = con.execute("SELECT * FROM upload_documents WHERE id=?", (doc_id,)).fetchone()
        draft = con.execute("SELECT * FROM upload_drafts WHERE document_id=?", (doc_id,)).fetchone()
        assert doc["storage_policy"] == "EPHEMERAL"
        assert doc["storage_key"] is None
        assert doc["content_hash"]
        assert doc["size_bytes"] == len(SALES_CSV)
        assert doc["processed_at"] is not None
        assert draft is not None
        assert draft["draft_type"] == "FILE"
        assert draft["canonical_payload_json"]
        sale = con.execute("SELECT gross_sales FROM daily_channel_sales WHERE store_id=?", (store["id"],)).fetchone()
        assert sale[0] == "3860.00"


def test_image_upload_is_recognized_synchronously_without_storage_key(monkeypatch, tmp_path):
    import mini.upload_routes as upload_routes
    provider = FakeRecognitionProvider({
        "platform": "MEITUAN_DELIVERY",
        "page_type": "DAILY_REPORT",
        "fields": {
            "BUSINESS_DATE": {"value": "2026-09-02", "confidence": 0.99},
            "GROSS_SALES": {"value": "3860.00", "confidence": 0.98},
            "ORDER_COUNT": {"value": "72", "confidence": 0.96},
        },
    })
    monkeypatch.setattr(upload_routes, "get_recognition_provider", lambda: provider)
    client, db = client_for(monkeypatch, tmp_path)
    image_bytes = b"fake-png-ephemeral"
    with client:
        token, _ = login_store(client, monkeypatch)
        uploaded = client.post(
            "/api/mini/v1/uploads/image",
            headers={"Authorization": f"Bearer {token}"},
            files={"file": ("meituan.png", image_bytes, "image/png")},
        )
        assert uploaded.status_code == 200, uploaded.text
        assert uploaded.json()["status"] == "NEEDS_CONFIRMATION"
        doc_id = uploaded.json()["id"]
    with sqlite3.connect(db) as con:
        con.row_factory = sqlite3.Row
        doc = con.execute("SELECT * FROM upload_documents WHERE id=?", (doc_id,)).fetchone()
        assert doc["storage_policy"] == "EPHEMERAL"
        assert doc["storage_key"] is None
        assert doc["content_hash"]
        assert doc["size_bytes"] == len(image_bytes)
        assert doc["processed_at"] is not None
