from pathlib import Path
import sqlite3

from persistence.schema import CLOUD_SCHEMA_VERSION, required_cloud_tables
from persistence.migrations import initial_migration_sha256, load_initial_migration_sql


def test_required_cloud_tables_exclude_legacy_demo_state():
    tables = required_cloud_tables()
    assert CLOUD_SCHEMA_VERSION == 1
    assert 'app_state' not in tables
    assert 'uploads' not in tables
    for name in {
        'users','stores','channels','import_files','import_batches','raw_import_rows',
        'daily_channel_sales','settlements','platform_fees','payments','reconciliation_matches',
        'mini_users','store_profiles','daily_store_sales_totals','store_cost_profiles',
        'cost_entries','industry_benchmarks','profit_snapshots','upload_documents',
        'upload_drafts','extraction_jobs','extracted_fields','document_import_links',
        'store_data_sources','daily_data_status','anomaly_events','action_items',
        'action_executions','action_verifications','reminders','ai_conversations','ai_messages'
    }:
        assert name in tables


def test_initial_migration_is_stable_and_contains_no_demo_tables():
    sql = load_initial_migration_sql()
    assert 'CREATE TABLE' in sql
    assert 'app_state' not in sql
    assert 'CREATE TABLE uploads' not in sql
    assert 'cloud_schema_version' in sql
    assert len(initial_migration_sha256()) == 64


def test_postgres_create_table_order_respects_foreign_key_dependencies():
    import re

    sql = load_initial_migration_sql()
    create_positions = {
        m.group(1): m.start()
        for m in re.finditer(r'CREATE TABLE(?: IF NOT EXISTS)?\s+([a-z_]+)\s*\(', sql, re.I)
    }
    assert create_positions

    for child, child_pos in create_positions.items():
        # Limit scanning to this CREATE TABLE statement so later statements do not leak in.
        next_positions = [p for p in create_positions.values() if p > child_pos]
        end = min(next_positions) if next_positions else len(sql)
        block = sql[child_pos:end]
        for parent in re.findall(r'REFERENCES\s+([a-z_]+)\s*\(', block, re.I):
            if parent == child:
                continue
            assert parent in create_positions, f'{child} references missing table {parent}'
            assert create_positions[parent] < child_pos, (
                f'{child} is created before referenced parent table {parent}'
            )
