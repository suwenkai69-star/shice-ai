from pathlib import Path
import pytest

from persistence.config import PersistenceConfigError, load_persistence_settings


def test_local_without_database_url_uses_sqlite(monkeypatch, tmp_path):
    monkeypatch.delenv('DATABASE_URL', raising=False)
    monkeypatch.delenv('VERCEL', raising=False)
    monkeypatch.setenv('SHICE_ENV', 'local')
    settings = load_persistence_settings(tmp_path / 'local.db')
    assert settings.backend == 'sqlite'
    assert settings.sqlite_path == tmp_path / 'local.db'


def test_production_without_database_url_fails_closed(monkeypatch, tmp_path):
    monkeypatch.delenv('DATABASE_URL', raising=False)
    monkeypatch.delenv('VERCEL', raising=False)
    monkeypatch.setenv('SHICE_ENV', 'production')
    with pytest.raises(PersistenceConfigError, match='DATABASE_URL'):
        load_persistence_settings(tmp_path / 'ignored.db')


def test_vercel_without_database_url_fails_closed(monkeypatch, tmp_path):
    monkeypatch.delenv('DATABASE_URL', raising=False)
    monkeypatch.setenv('SHICE_ENV', 'local')
    monkeypatch.setenv('VERCEL', '1')
    with pytest.raises(PersistenceConfigError, match='DATABASE_URL'):
        load_persistence_settings(tmp_path / 'ignored.db')


def test_postgres_url_selects_postgres(monkeypatch, tmp_path):
    monkeypatch.setenv('SHICE_ENV', 'production')
    monkeypatch.setenv('DATABASE_URL', 'postgresql+psycopg://user:pass@example.invalid/db')
    settings = load_persistence_settings(tmp_path / 'ignored.db')
    assert settings.backend == 'postgresql'
