from __future__ import annotations

from repositories.action_repository import ActionRepository
from repositories.mini_cost_repository import MiniCostRepository
from repositories.mini_sales_repository import MiniSalesRepository
from repositories.mini_store_repository import MiniStoreRepository
from repositories.upload_repository import UploadRepository


def _owner_store(db, suffix: str):
    stores = MiniStoreRepository(db)
    mini_user = stores.create_or_get_user(f"pg-contract:{suffix}")
    store = stores.create_store(int(mini_user["user_id"]), f"PG合同店-{suffix}", "MILK_TEA")
    return mini_user, store


def test_core_repositories_round_trip_on_postgresql(postgres_contract_database, contract_suffix):
    db = postgres_contract_database
    user, store = _owner_store(db, contract_suffix)
    sid = int(store["id"])
    uid = int(user["user_id"])

    total = MiniSalesRepository(db).upsert_store_total(
        sid, "2026-09-06", "8420.00", "PG_CONTRACT", contract_suffix, order_count=163
    )
    assert total["gross_sales"] == "8420.00"
    assert int(total["order_count"]) == 163

    costs = MiniCostRepository(db)
    profile = costs.save_profile(
        sid,
        {
            "food_cost_mode": "ACTUAL_RATE",
            "food_cost_value": "0.32",
            "labor_cost_mode": "ACTUAL_MONTHLY",
            "monthly_labor_actual": "18000",
            "rent_mode": "ACTUAL_MONTHLY",
            "monthly_rent": "9000",
            "operating_days_per_month": 30,
        },
    )
    assert profile["food_cost_mode"] == "ACTUAL_RATE"
    entry = costs.add_cost_entry(
        sid,
        business_date="2026-09-06",
        cost_type="MARKETING",
        amount="88.00",
        source_type="PG_CONTRACT",
        basis="ACTUAL",
    )
    assert entry["amount"] == "88.00"

    uploads = UploadRepository(db)
    doc_id = uploads.create_document(
        store_id=sid,
        user_id=uid,
        document_type="FILE",
        original_filename="contract.csv",
        storage_key=None,
        mime_type="text/csv",
        storage_policy="EPHEMERAL",
        content_hash="abc123",
        size_bytes=123,
        status="NEEDS_CONFIRMATION",
    )
    draft = uploads.save_draft(
        doc_id,
        draft_type="FILE",
        preview={"data_type": "SALES"},
        canonical_payload=[{"business_date": "2026-09-06", "gross_sales": "100"}],
    )
    assert int(draft["document_id"]) == doc_id
    assert uploads.get_document(doc_id, store_id=sid)["storage_key"] is None

    actions = ActionRepository(db)
    action = actions.create_action(
        sid,
        "2026-09-06",
        None,
        "PG_CONTRACT",
        "核对今天的数据",
        "PostgreSQL contract",
        "SALES",
        "UP",
        1,
    )
    executed = actions.mark_executed(int(action["id"]), sid, executed_at=1234567890, note="contract")
    assert executed["status"] == "WAITING_VERIFICATION"
    assert actions.get_execution(int(action["id"]))["execution_note"] == "contract"
