from pathlib import Path
import sqlite3

from db import migrate_database
from tests.test_schema_v2 import create_v04_db
from persistence.database import Database
from persistence.seed import seed_system_data


def test_seed_is_idempotent_and_never_creates_business_users(tmp_path):
    path = tmp_path / 'seed.db'
    create_v04_db(path)
    migrate_database(path)
    with sqlite3.connect(path) as con:
        con.execute('DELETE FROM uploads')
        con.execute('DELETE FROM app_state')
        con.execute('DELETE FROM stores')
        con.execute('DELETE FROM users')
        con.execute('DELETE FROM industry_benchmarks')
        con.commit()
    db = Database.sqlite(path)
    seed_path = Path(__file__).resolve().parents[2] / 'data/benchmarks/benchmark_seed.json'
    first = seed_system_data(db, seed_path)
    second = seed_system_data(db, seed_path)
    assert first.channel_count == second.channel_count == 10
    assert first.seed_sha256 == second.seed_sha256
    with db.connect() as con:
        assert con.exec_driver_sql('SELECT COUNT(*) FROM users').scalar_one() == 0
        assert con.exec_driver_sql('SELECT COUNT(*) FROM stores').scalar_one() == 0
        assert con.exec_driver_sql("SELECT COUNT(*) FROM industry_benchmarks WHERE review_status <> 'APPROVED'").scalar_one() == 0
    db.dispose()
