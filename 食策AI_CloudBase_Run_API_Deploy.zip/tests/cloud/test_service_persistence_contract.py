from pathlib import Path

FILES = [
    'services/benchmark_service.py','services/completeness_service.py','services/cost_resolver.py',
    'services/manual_ingestion.py','services/mini_import_adapter.py','services/profit_engine.py',
    'services/verification_engine.py','services/reconciliation_summary.py','mini/issue_routes.py',
]


def test_cloud_used_services_have_no_direct_sqlite_access():
    root = Path(__file__).resolve().parents[2]
    failures = {}
    for rel in FILES:
        text = (root / rel).read_text(encoding='utf-8')
        hits = [needle for needle in ('import sqlite3','sqlite3.connect','PRAGMA') if needle in text]
        if hits:
            failures[rel] = hits
    assert failures == {}
