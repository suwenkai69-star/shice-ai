from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_vercel_config_packages_fastapi_and_excludes_local_only_artifacts():
    config_path = ROOT / "vercel.json"
    assert config_path.exists(), "vercel.json must exist for cloud deployment"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    assert config.get("$schema") == "https://openapi.vercel.sh/vercel.json"
    fn = config["functions"]["app.py"]
    assert int(fn["maxDuration"]) >= 60
    excluded = fn["excludeFiles"]
    for required in (
        "tests/**",
        "samples/**",
        "data/*.db",
        "data/mini_uploads/**",
        "static/**",
        "__pycache__/**",
    ):
        assert required in excluded


def test_vercelignore_excludes_secrets_databases_caches_and_test_uploads():
    ignore_path = ROOT / ".vercelignore"
    assert ignore_path.exists(), ".vercelignore must exist"
    ignored = {
        line.strip()
        for line in ignore_path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    }
    required = {
        ".env",
        ".env.*",
        "data/*.db",
        "data/mini_uploads/",
        ".pytest_cache/",
        "__pycache__/",
        "tests/",
        "samples/",
        "static/",
    }
    assert required.issubset(ignored)


def test_deployment_config_contains_no_secret_values():
    text = "\n".join(
        path.read_text(encoding="utf-8")
        for path in (ROOT / "vercel.json", ROOT / ".vercelignore")
        if path.exists()
    )
    forbidden_fragments = (
        "postgresql://",
        "postgresql+psycopg://",
        "sk-",
        "MINI_TOKEN_SECRET=",
        "WECHAT_SECRET=",
        "CRON_SECRET=",
        "OPENAI_API_KEY=",
    )
    assert not any(fragment in text for fragment in forbidden_fragments)


def test_vercel_cron_dispatches_reminders_hourly_without_inline_secret():
    config = json.loads((ROOT / "vercel.json").read_text(encoding="utf-8"))
    assert config.get("crons") == [
        {"path": "/api/mini/v1/internal/reminders/dispatch", "schedule": "0 * * * *"}
    ]
    text = (ROOT / "vercel.json").read_text(encoding="utf-8")
    assert "CRON_SECRET=" not in text
