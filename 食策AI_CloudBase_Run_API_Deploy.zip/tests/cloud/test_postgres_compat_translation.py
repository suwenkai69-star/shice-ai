from __future__ import annotations

from persistence.database import Database


class FakeMappings:
    def __init__(self, rows):
        self.rows = list(rows)

    def fetchone(self):
        return self.rows.pop(0) if self.rows else None

    def all(self):
        rows, self.rows = self.rows, []
        return rows


class FakeResult:
    def __init__(self, rows=None, rowcount=1):
        self._rows = list(rows or [])
        self.returns_rows = bool(rows)
        self.rowcount = rowcount
        self.lastrowid = None

    def mappings(self):
        return FakeMappings(self._rows)

    def scalar(self):
        if not self._rows:
            return None
        return next(iter(self._rows[0].values()))


class FakeTransaction:
    is_active = True

    def commit(self):
        self.is_active = False

    def rollback(self):
        self.is_active = False


class FakeConnection:
    def __init__(self):
        self.calls = []

    def begin(self):
        return FakeTransaction()

    def execute(self, statement, params):
        sql = str(statement)
        self.calls.append((sql, dict(params)))
        if sql.lstrip().upper().startswith("INSERT") and "RETURNING id" in sql:
            return FakeResult([{"id": 42}])
        return FakeResult(rowcount=1)

    def close(self):
        pass


class FakeEngine:
    def __init__(self):
        self.connection = FakeConnection()

    def connect(self):
        return self.connection

    def dispose(self):
        pass


def test_postgres_compat_translates_insert_or_ignore_and_returns_identity():
    engine = FakeEngine()
    db = Database(engine, "postgresql")

    with db.compat_connect() as con:
        result = con.execute(
            "INSERT OR IGNORE INTO import_files(store_id,file_name,file_hash,file_size,created_at) VALUES(?,?,?,?,?)",
            (7, "x.csv", "abc", 12, 99),
        )
        assert result.lastrowid == 42

    sql, params = engine.connection.calls[0]
    assert "INSERT OR IGNORE" not in sql
    assert "ON CONFLICT DO NOTHING" in sql
    assert sql.rstrip().endswith("RETURNING id")
    assert params == {"p0": 7, "p1": "x.csv", "p2": "abc", "p3": 12, "p4": 99}


def test_postgres_compat_does_not_add_identity_returning_to_natural_key_table():
    engine = FakeEngine()
    db = Database(engine, "postgresql")

    with db.compat_connect() as con:
        con.execute(
            "INSERT INTO store_profiles(store_id,category_code,created_at,updated_at) VALUES(?,?,?,?)",
            (7, "MILK_TEA", 1, 1),
        )

    sql, _ = engine.connection.calls[0]
    assert "RETURNING id" not in sql
