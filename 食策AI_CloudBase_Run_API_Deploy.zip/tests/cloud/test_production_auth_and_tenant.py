from __future__ import annotations

from pathlib import Path

import pytest


def test_production_auth_fails_closed_without_wechat_credentials(monkeypatch):
    from mini.auth import AuthConfigurationError, get_auth_provider

    monkeypatch.setenv("VERCEL", "1")
    monkeypatch.delenv("WECHAT_APPID", raising=False)
    monkeypatch.delenv("WECHAT_SECRET", raising=False)
    with pytest.raises(AuthConfigurationError):
        get_auth_provider()


def test_production_token_fails_closed_without_secret(monkeypatch):
    from mini.auth import AuthConfigurationError, TokenService

    monkeypatch.setenv("SHICE_ENV", "production")
    monkeypatch.delenv("MINI_TOKEN_SECRET", raising=False)
    with pytest.raises(AuthConfigurationError):
        TokenService()


def test_local_mode_keeps_explicit_dev_auth(monkeypatch):
    from mini.auth import DevAuthProvider, get_auth_provider

    monkeypatch.setenv("SHICE_ENV", "local")
    monkeypatch.delenv("VERCEL", raising=False)
    monkeypatch.delenv("WECHAT_APPID", raising=False)
    monkeypatch.delenv("WECHAT_SECRET", raising=False)
    assert isinstance(get_auth_provider(), DevAuthProvider)


def test_mini_routes_use_runtime_database_dependency_not_raw_db_path():
    root = Path(__file__).resolve().parents[2] / "mini"
    route_files = [
        "routes.py", "action_routes.py", "ai_routes.py", "data_status_routes.py",
        "issue_routes.py", "manual_routes.py", "profit_routes.py", "reconciliation_routes.py",
        "today_routes.py", "trend_routes.py", "upload_routes.py",
    ]
    failures = {}
    for name in route_files:
        text = (root / name).read_text(encoding="utf-8")
        if "get_db_path()" in text or "_db_path()" in text:
            failures[name] = "raw sqlite path dependency"
    assert failures == {}
