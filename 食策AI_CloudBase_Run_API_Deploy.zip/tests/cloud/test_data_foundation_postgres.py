from __future__ import annotations

from data_foundation import import_daily_sales, import_payments, list_daily_sales, list_payments
from repositories.mini_store_repository import MiniStoreRepository


def _store(db, suffix: str) -> int:
    repo = MiniStoreRepository(db)
    user = repo.create_or_get_user(f"pg-r1:{suffix}")
    return int(repo.create_store(int(user["user_id"]), f"R1合同店-{suffix}", "MILK_TEA")["id"])


def test_r1_sales_and_payment_imports_execute_on_postgresql(postgres_contract_database, contract_suffix):
    db = postgres_contract_database
    sid = _store(db, contract_suffix)

    sales_v1 = (
        "business_date,channel_code,gross_sales,customer_paid,order_count\n"
        "2026-09-06,MEITUAN_DELIVERY,1000.00,900.00,20\n"
    ).encode()
    first = import_daily_sales(db, sid, f"sales-{contract_suffix}-1.csv", sales_v1, "PG_CONTRACT")
    assert first.accepted_rows == 1

    sales_v2 = (
        "business_date,channel_code,gross_sales,customer_paid,order_count\n"
        "2026-09-06,MEITUAN_DELIVERY,1100.00,990.00,22\n"
    ).encode()
    second = import_daily_sales(db, sid, f"sales-{contract_suffix}-2.csv", sales_v2, "PG_CONTRACT")
    assert second.accepted_rows == 1
    assert second.updated_rows == 1

    rows = list_daily_sales(db, sid, "2026-09-06", "2026-09-06")
    meituan = [row for row in rows if row["channel_code"] == "MEITUAN_DELIVERY"]
    assert len(meituan) == 1
    assert meituan[0]["gross_sales"] == "1100.00"

    payment_csv = (
        "channel_code,payment_date,amount,payment_method,bank_reference\n"
        f"MEITUAN_DELIVERY,2026-09-06,876.50,BANK,PG-{contract_suffix}\n"
    ).encode()
    payment = import_payments(db, sid, f"payment-{contract_suffix}.csv", payment_csv, "PG_CONTRACT")
    assert payment.accepted_rows == 1
    saved = list_payments(db, sid)
    assert saved[-1]["amount"] == "876.50"
    assert saved[-1]["bank_reference"] == f"PG-{contract_suffix}"
