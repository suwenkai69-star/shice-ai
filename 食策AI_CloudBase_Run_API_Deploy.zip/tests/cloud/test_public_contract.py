from __future__ import annotations

import os

import httpx
import pytest


def _base_url() -> str:
    base = os.getenv("SHICE_PUBLIC_BASE_URL", "").strip().rstrip("/")
    if not base:
        pytest.skip("set SHICE_PUBLIC_BASE_URL to run public HTTPS smoke tests")
    if not base.startswith("https://"):
        pytest.fail("SHICE_PUBLIC_BASE_URL must be HTTPS")
    return base


def test_public_health_reports_postgresql_backend():
    base = _base_url()
    response = httpx.get(f"{base}/api/health", timeout=20.0)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["status"] == "ok"
    assert body["database_backend"] == "postgresql"
    assert body["cloud_schema_version"] == 1
    assert body["mini_api_version"] == "v1"


def test_public_production_blocks_legacy_routes():
    base = _base_url()
    for path in ("/api/state", "/api/v2/channels", "/api/session"):
        response = httpx.get(f"{base}{path}", timeout=20.0)
        assert response.status_code == 404, (path, response.status_code, response.text)


def test_public_protected_route_requires_authentication():
    base = _base_url()
    response = httpx.get(f"{base}/api/mini/v1/store", timeout=20.0)
    assert response.status_code == 401, response.text
