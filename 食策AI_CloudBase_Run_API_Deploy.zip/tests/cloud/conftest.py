from __future__ import annotations

import os
import uuid
from pathlib import Path

import pytest

from persistence.database import Database
from persistence.migrations import assert_cloud_schema
from persistence.seed import seed_system_data


@pytest.fixture(scope="session")
def postgres_test_url() -> str:
    """Return the explicitly-authorized writable PostgreSQL contract URL.

    The write guard is deliberate: these tests create business rows and must never
    run merely because a production DATABASE_URL happens to be present.
    """
    if os.getenv("SHICE_POSTGRES_CONTRACT", "").strip() != "1":
        pytest.skip("set SHICE_POSTGRES_CONTRACT=1 to run live PostgreSQL write contracts")
    url = os.getenv("DATABASE_URL", "").strip()
    if not url:
        pytest.fail("DATABASE_URL is required when SHICE_POSTGRES_CONTRACT=1")
    if not url.startswith(("postgresql://", "postgresql+psycopg://")):
        pytest.fail("PostgreSQL contract requires a postgresql DATABASE_URL")
    try:
        import psycopg  # noqa: F401
    except ModuleNotFoundError:
        pytest.fail("psycopg is required for live PostgreSQL contract execution")
    return url


@pytest.fixture(scope="session")
def postgres_contract_database(postgres_test_url: str) -> Database:
    db = Database.postgres(postgres_test_url)
    assert_cloud_schema(db)
    seed_system_data(db, Path(__file__).resolve().parents[2] / "data/benchmarks/benchmark_seed.json")
    yield db
    db.dispose()


@pytest.fixture
def contract_suffix() -> str:
    return uuid.uuid4().hex[:12]
