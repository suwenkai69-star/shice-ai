from __future__ import annotations

from fastapi.testclient import TestClient

from mini.auth import WechatIdentity
from persistence.database import Database
from recognition.providers.fake import FakeRecognitionProvider


class AcceptanceAuthProvider:
    def __init__(self, suffix: str):
        self.suffix = suffix

    def exchange_code(self, code: str) -> WechatIdentity:
        return WechatIdentity(openid=f"pg-accept:{self.suffix}:{code}", unionid=None)


def test_complete_mini_v1_story_persists_across_fresh_postgres_engine(postgres_test_url, contract_suffix, monkeypatch):
    import app as api_app
    import mini.auth as auth_module
    import mini.upload_routes as upload_routes

    monkeypatch.setenv("SHICE_ENV", "test")
    monkeypatch.delenv("VERCEL", raising=False)
    monkeypatch.setenv("MINI_TOKEN_SECRET", f"accept-secret-{contract_suffix}")
    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: AcceptanceAuthProvider(contract_suffix))
    monkeypatch.setattr(
        upload_routes,
        "get_recognition_provider",
        lambda: FakeRecognitionProvider(
            {
                "platform": "MEITUAN_DELIVERY",
                "page_type": "DAILY_REPORT",
                "fields": {
                    "BUSINESS_DATE": {"value": "2026-09-07", "confidence": 0.99},
                    "GROSS_SALES": {"value": "1260.00", "confidence": 0.98},
                    "ORDER_COUNT": {"value": "30", "confidence": 0.96},
                },
            }
        ),
    )

    db1 = Database.postgres(postgres_test_url)
    api_app.app.state.database = db1
    client = TestClient(api_app.app)

    login = client.post("/api/mini/v1/auth/wechat", json={"code": "owner"})
    assert login.status_code == 200, login.text
    token = login.json()["token"]
    user_id = int(login.json()["user"]["id"])
    headers = {"Authorization": f"Bearer {token}"}

    created = client.post(
        "/api/mini/v1/store",
        headers=headers,
        json={"name": f"Postgres验收店-{contract_suffix}", "category_code": "MILK_TEA"},
    )
    assert created.status_code == 200, created.text
    store_id = int(created.json()["store"]["id"])

    sales = client.post(
        "/api/mini/v1/manual/sales",
        headers=headers,
        json={"business_date": "2026-09-06", "scope": "WHOLE_STORE", "gross_sales": "8420", "order_count": 163},
    )
    assert sales.status_code == 200, sales.text

    for cost_type, amount in (("FOOD", "2200"), ("LABOR", "1300"), ("RENT", "300"), ("UTILITY", "180")):
        r = client.post(
            "/api/mini/v1/manual/cost",
            headers=headers,
            json={"business_date": "2026-09-06", "cost_type": cost_type, "amount": amount, "basis": "ACTUAL"},
        )
        assert r.status_code == 200, r.text

    today = client.get("/api/mini/v1/today?date=2026-09-06", headers=headers)
    assert today.status_code == 200, today.text
    assert today.json()["sales"]["amount"] == "8420.00"

    csv_upload = client.post(
        "/api/mini/v1/uploads/file",
        headers=headers,
        files={
            "file": (
                "channel.csv",
                b"business_date,channel_code,gross_sales,order_count\n2026-09-06,MEITUAN_DELIVERY,3860.00,72\n",
                "text/csv",
            )
        },
    )
    assert csv_upload.status_code == 200, csv_upload.text
    csv_id = int(csv_upload.json()["id"])
    csv_confirm = client.post(f"/api/mini/v1/uploads/{csv_id}/confirm", headers=headers)
    assert csv_confirm.status_code == 200, csv_confirm.text

    image_upload = client.post(
        "/api/mini/v1/uploads/image",
        headers=headers,
        files={"file": ("report.png", b"fake-png-contract", "image/png")},
    )
    assert image_upload.status_code == 200, image_upload.text
    image_id = int(image_upload.json()["id"])
    patch = client.patch(
        f"/api/mini/v1/uploads/{image_id}/fields",
        headers=headers,
        json={"fields": [{"field_code": "GROSS_SALES", "confirmed_value": "1280.00", "excluded": False}]},
    )
    assert patch.status_code == 200, patch.text
    image_confirm = client.post(f"/api/mini/v1/uploads/{image_id}/confirm", headers=headers)
    assert image_confirm.status_code == 200, image_confirm.text

    payment = client.post(
        "/api/mini/v1/manual/payment",
        headers=headers,
        json={
            "payment_date": "2026-09-06",
            "channel_code": "MEITUAN_DELIVERY",
            "amount": "321.00",
            "payment_method": "BANK",
            "bank_reference": f"ACCEPT-{contract_suffix}",
        },
    )
    assert payment.status_code == 200, payment.text

    reconciliation = client.get("/api/mini/v1/reconciliation/today?date=2026-09-06", headers=headers)
    assert reconciliation.status_code == 200, reconciliation.text
    assert reconciliation.json()["reconciliation"]["status"] == "DIFFERENCE"

    actions = client.get("/api/mini/v1/actions?date=2026-09-06", headers=headers)
    assert actions.status_code == 200, actions.text
    assert actions.json()["actions"]
    action_id = int(actions.json()["actions"][0]["id"])
    executed = client.post(
        f"/api/mini/v1/actions/{action_id}/execute",
        headers=headers,
        json={"note": "PostgreSQL acceptance"},
    )
    assert executed.status_code == 200, executed.text

    next_day = client.get("/api/mini/v1/today?date=2026-09-07", headers=headers)
    assert next_day.status_code == 200, next_day.text
    assert next_day.json()["yesterday_verification"] is not None

    db1.dispose()

    db2 = Database.postgres(postgres_test_url)
    api_app.app.state.database = db2
    fresh_client = TestClient(api_app.app)
    fresh_store = fresh_client.get("/api/mini/v1/store", headers=headers)
    assert fresh_store.status_code == 200, fresh_store.text
    assert int(fresh_store.json()["store"]["id"]) == store_id
    fresh_today = fresh_client.get("/api/mini/v1/today?date=2026-09-06", headers=headers)
    assert fresh_today.status_code == 200, fresh_today.text
    assert fresh_today.json()["sales"]["amount"] == "8420.00"

    with db2.connect() as con:
        persisted = con.exec_driver_sql(
            "SELECT COUNT(*) FROM users WHERE id=%s" % user_id
        ).scalar_one()
    assert int(persisted) == 1
    db2.dispose()
