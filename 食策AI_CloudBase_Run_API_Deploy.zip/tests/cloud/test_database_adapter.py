from sqlalchemy import text
from persistence.database import Database, coerce_database


def test_sqlite_transaction_rolls_back(tmp_path):
    db = Database.sqlite(tmp_path / 'adapter.db')
    with db.begin() as con:
        con.execute(text('CREATE TABLE sample(id INTEGER PRIMARY KEY, value TEXT NOT NULL)'))
    try:
        with db.begin() as con:
            con.execute(text('INSERT INTO sample(id,value) VALUES(:id,:value)'), {'id': 1, 'value': 'x'})
            raise RuntimeError('boom')
    except RuntimeError:
        pass
    with db.connect() as con:
        assert con.execute(text('SELECT COUNT(*) FROM sample')).scalar_one() == 0
    db.dispose()


def test_coerce_path_returns_sqlite_database(tmp_path):
    db = coerce_database(tmp_path / 'x.db')
    assert db.backend == 'sqlite'
    db.dispose()
