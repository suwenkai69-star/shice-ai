from __future__ import annotations

from fastapi.testclient import TestClient

from mini.auth import WechatIdentity
from repositories.action_repository import ActionRepository


class CodeAuthProvider:
    def exchange_code(self, code: str) -> WechatIdentity:
        return WechatIdentity(openid=f"tenant:{code}", unionid=None)


def _login_and_store(client: TestClient, code: str, name: str):
    login = client.post("/api/mini/v1/auth/wechat", json={"code": code})
    assert login.status_code == 200, login.text
    token = login.json()["token"]
    headers = {"Authorization": f"Bearer {token}"}
    created = client.post(
        "/api/mini/v1/store",
        headers=headers,
        json={"name": name, "category_code": "MILK_TEA"},
    )
    assert created.status_code == 200, created.text
    return headers, created.json()["store"]


def test_postgresql_api_tenant_isolation(postgres_contract_database, contract_suffix, monkeypatch):
    import app as api_app
    import mini.auth as auth_module

    monkeypatch.setenv("SHICE_ENV", "test")
    monkeypatch.delenv("VERCEL", raising=False)
    monkeypatch.setenv("MINI_TOKEN_SECRET", f"tenant-secret-{contract_suffix}")
    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: CodeAuthProvider())
    monkeypatch.setattr(api_app.app.state, "database", postgres_contract_database, raising=False)

    client = TestClient(api_app.app)
    a_headers, a_store = _login_and_store(client, f"a-{contract_suffix}", f"A店-{contract_suffix}")
    b_headers, b_store = _login_and_store(client, f"b-{contract_suffix}", f"B店-{contract_suffix}")
    assert int(a_store["id"]) != int(b_store["id"])

    a_sales = client.post(
        "/api/mini/v1/manual/sales",
        headers=a_headers,
        json={"business_date": "2026-09-06", "scope": "WHOLE_STORE", "gross_sales": "2000", "order_count": 40},
    )
    assert a_sales.status_code == 200, a_sales.text

    a_today = client.get("/api/mini/v1/today?date=2026-09-06", headers=a_headers)
    b_today = client.get("/api/mini/v1/today?date=2026-09-06", headers=b_headers)
    assert a_today.status_code == b_today.status_code == 200
    assert a_today.json()["sales"]["amount"] == "2000.00"
    assert b_today.json()["sales"]["amount"] is None

    uploaded = client.post(
        "/api/mini/v1/uploads/file",
        headers=a_headers,
        files={
            "file": (
                "a-sales.csv",
                b"business_date,channel_code,gross_sales,order_count\n2026-09-06,MEITUAN_DELIVERY,500,10\n",
                "text/csv",
            )
        },
    )
    assert uploaded.status_code == 200, uploaded.text
    doc_id = int(uploaded.json()["id"])
    assert client.get(f"/api/mini/v1/uploads/{doc_id}", headers=b_headers).status_code == 404

    action = ActionRepository(postgres_contract_database).create_action(
        int(a_store["id"]),
        "2026-09-06",
        None,
        "TENANT_TEST",
        "A店待办",
        "只属于A店",
        "SALES",
        "UP",
        1,
    )
    action_id = int(action["id"])
    assert client.get(f"/api/mini/v1/actions/{action_id}", headers=a_headers).status_code == 200
    assert client.get(f"/api/mini/v1/actions/{action_id}", headers=b_headers).status_code == 404
