from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MINI = ROOT / "miniprogram"


def read(rel: str) -> str:
    return (MINI / rel).read_text("utf-8")


def test_welcome_has_two_simple_choices():
    text = read("pages/welcome/index.wxml")
    assert "开始管理我的店" in text
    assert "先看看食策AI能做什么" in text


def test_onboarding_only_requires_store_name_and_category():
    text = read("pages/onboarding/index.wxml")
    assert "门店名称" in text
    assert "主营" in text
    for forbidden in ("房租", "员工人数", "城市", "手机号"):
        assert forbidden not in text


def test_today_copy_is_plain_language_and_estimate_is_range():
    wxml = read("pages/today/index.wxml")
    js = read("pages/today/index.js")
    assert "今天生意怎么样" in wxml
    assert "今天估计赚" in wxml
    assert "今天还算不了赚多少钱" in wxml
    assert "今天最值得处理" in wxml
    assert ".slice(0, 3)" in js
    for jargon in ("EBITDA", "Gross Sales", "Reconciliation", "Labor Cost Rate"):
        assert jargon not in wxml


def test_upload_has_four_entry_methods_and_native_apis():
    wxml = read("pages/upload/index.wxml")
    js = read("pages/upload/index.js")
    for label in ("拍照", "选截图", "选文件", "手动填写"):
        assert label in wxml
    assert "wx.chooseMedia" in js
    assert "wx.chooseMessageFile" in js
    assert "/uploads/image" in js
    assert "/uploads/file" in js


def test_upload_confirmation_requires_explicit_confirm_and_shows_low_confidence():
    wxml = read("pages/upload-confirm/index.wxml")
    js = read("pages/upload-confirm/index.js")
    assert "确认没问题" in wxml
    assert "需要确认" in wxml
    assert "修改" in wxml
    assert "/confirm" in js
    assert "更新之前的数据" in wxml
    assert "这是另一份数据" in wxml


def test_actions_have_required_user_controls_and_reminder_permission_order():
    detail = read("pages/action-detail/index.wxml")
    js = read("pages/action-detail/index.js")
    for label in ("我已经做完", "暂不做", "明天提醒"):
        assert label in detail
    assert "wx.requestSubscribeMessage" in js
    assert "/remind" in js
    assert js.index("wx.requestSubscribeMessage") < js.index("/remind")
    assert "生成宣传图" not in detail


def test_actions_page_has_three_status_sections():
    text = read("pages/actions/index.wxml")
    assert "今天建议做" in text
    assert "等待验证" in text
    assert "已完成" in text


def test_profile_and_cost_flow_use_progressive_disclosure():
    profile = read("pages/profile/index.wxml")
    cost = read("pages/cost-profile/index.wxml")
    js = read("pages/cost-profile/index.js")
    assert "让结果更准" in profile
    assert "利润准确度" in profile
    assert "你知道每月实际人工支出吗" in cost
    assert "不知道，帮我估" in cost
    assert "showCityForLabor" in js


def test_chat_needs_data_is_first_class_and_actionable():
    wxml = read("pages/chat/index.wxml")
    js = read("pages/chat/index.js")
    assert "NEEDS_DATA" in js
    assert "补数据" in wxml
    assert "/ai/chat" in js


def test_demo_is_explicitly_read_only():
    js = read("pages/demo/index.js")
    wxml = read("pages/demo/index.wxml")
    assert "readOnly: true" in js
    assert "演示" in wxml
