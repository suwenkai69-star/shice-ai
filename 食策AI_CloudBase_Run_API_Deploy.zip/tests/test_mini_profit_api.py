from __future__ import annotations

import sys
from pathlib import Path

from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import app as api_app
from tests.test_mini_auth_api import FakeAuthProvider


def client_for(monkeypatch, tmp_path):
    db = tmp_path / "mini-profit-api.db"
    monkeypatch.setattr(api_app, "DB_PATH", db)
    api_app.init_db()
    return TestClient(api_app.app), db


def login_and_store(client, monkeypatch):
    import mini.auth as auth_module
    monkeypatch.setattr(auth_module, "get_auth_provider", lambda: FakeAuthProvider("profit-user"))
    token = client.post("/api/mini/v1/auth/wechat", json={"code": "x"}).json()["token"]
    created = client.post(
        "/api/mini/v1/store",
        headers={"Authorization": f"Bearer {token}"},
        json={"name": "利润测试店", "category_code": "MILK_TEA"},
    )
    return token, created.json()["store"]


def test_profit_api_returns_unavailable_without_sales(monkeypatch, tmp_path):
    client, _ = client_for(monkeypatch, tmp_path)
    with client:
        token, _ = login_and_store(client, monkeypatch)
        r = client.get(
            "/api/mini/v1/profit/today?business_date=2026-09-02",
            headers={"Authorization": f"Bearer {token}"},
        )
    assert r.status_code == 200
    assert r.json()["profit"]["status"] == "UNAVAILABLE"
    assert "营业额" in r.json()["profit"]["missing_data"]


def test_profit_profile_patch_round_trip(monkeypatch, tmp_path):
    client, _ = client_for(monkeypatch, tmp_path)
    with client:
        token, _ = login_and_store(client, monkeypatch)
        headers = {"Authorization": f"Bearer {token}"}
        patched = client.patch(
            "/api/mini/v1/profit/profile",
            headers=headers,
            json={"food_cost_mode": "USER_ESTIMATE", "food_cost_value": "0.35"},
        )
        fetched = client.get("/api/mini/v1/profit/profile", headers=headers)
    assert patched.status_code == 200
    assert fetched.json()["profile"]["food_cost_value"] == "0.35"
