from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_schema_v2 import create_v04_db


@pytest.fixture
def v3_db(tmp_path):
    from db import migrate_database

    db = tmp_path / "actions.db"
    create_v04_db(db)
    migrate_database(db)
    return db


def test_phase4_tables_are_created_additively(v3_db):
    from db import migrate_database

    migrate_database(v3_db)
    with sqlite3.connect(v3_db) as con:
        names = {row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {
        "action_items", "action_executions", "action_verifications", "reminders",
        "ai_conversations", "ai_messages",
    } <= names


def test_action_status_constraint_contains_exact_v1_states(v3_db):
    with sqlite3.connect(v3_db) as con:
        sql = con.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='action_items'"
        ).fetchone()[0]
    for value in ("PENDING", "EXECUTED", "SKIPPED", "REMIND", "WAITING_VERIFICATION", "VERIFIED"):
        assert f"'{value}'" in sql
    with pytest.raises(sqlite3.IntegrityError):
        with sqlite3.connect(v3_db) as con:
            con.execute(
                """INSERT INTO action_items(
                    store_id,business_date,action_type,title,reason,expected_metric,expected_direction,
                    priority,status,created_at,updated_at
                ) VALUES(1,'2026-09-02','TEST','x','x','AOV','UP',1,'AUTO_DONE',1,1)"""
            )


def test_action_repository_create_execute_and_skip_are_store_scoped(v3_db):
    from repositories.action_repository import ActionRepository

    repo = ActionRepository(v3_db)
    action = repo.create_action(
        1, "2026-09-02", None, "AOV_RECOVERY", "提高客单价", "客单价偏低", "AOV", "UP", 1
    )
    assert action["status"] == "PENDING"

    executed = repo.mark_executed(int(action["id"]), 1, executed_at=123456, note="已调整")
    assert executed["status"] == "WAITING_VERIFICATION"
    assert executed["execution_note"] == "已调整"

    with pytest.raises(KeyError):
        repo.mark_skipped(int(action["id"]), 2)


def test_action_repository_schedule_reminder_does_not_mark_executed(v3_db):
    from repositories.action_repository import ActionRepository

    repo = ActionRepository(v3_db)
    action = repo.create_action(
        1, "2026-09-02", None, "CHECK_CASH", "核对到账", "有款项暂未对上", "RECONCILIATION_DIFF", "DOWN", 1
    )
    reminder = repo.schedule_reminder(int(action["id"]), 1, 1, 999999)
    current = repo.get_action(int(action["id"]), 1)

    assert reminder["status"] == "PENDING"
    assert current["status"] == "REMIND"
    assert current["status"] != "EXECUTED"
