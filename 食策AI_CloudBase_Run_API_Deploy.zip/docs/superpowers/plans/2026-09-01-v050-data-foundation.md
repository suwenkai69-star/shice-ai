# 食策AI V0.5.0 Data Foundation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Safely upgrade the existing V0.4 FastAPI + SQLite prototype with an additive, traceable, idempotent Schema V2 for multi-channel sales, settlements, payments, platform fees, and reconciliation while preserving V0.4 behavior.

**Architecture:** Keep `app.py` as the V0.4 entry point. Add `db_v2.py` for transactional migrations/schema/Decimal helpers and `data_foundation.py` for import, deduplication, calculation, reconciliation, and compatibility services. Add `/api/v2/*` endpoints as thin adapters; keep legacy state and front end intact.

**Tech Stack:** Python 3, FastAPI, SQLite, `Decimal`, pytest/httpx/TestClient, existing static HTML/JS.

**Spec:** `docs/superpowers/specs/2026-09-01-v050-data-foundation-design.md`

## Global Constraints

- Preserve all V0.4 features, APIs, database contents, demo flow, CSV/JSON upload, and local fallback.
- No UI rewrite, React/Vue migration, GPT integration, BOM, inventory, tax/invoice, platform API/RPA, CRM, login/multi-tenant rewrite, or V0.5.1 work.
- V2 financial arithmetic uses `Decimal`; new monetary persistence uses canonical decimal strings.
- Fee/refund values are positive magnitudes; calculation profiles decide signs.
- Every upload is auditable through batch/raw/file provenance.
- Daily sales, settlements, and payments must be idempotent.

---

### Task 1: Freeze V0.4 regression baseline and add transactional Schema V2 migration

**Files:**
- Create: `tests/test_v04_regression.py`
- Create: `tests/test_schema_v2.py`
- Create: `db_v2.py`
- Modify: `app.py`

**Interfaces:**
- Produces: `migrate_database(db_path, fail_after_statement=None) -> int`, `get_schema_version(db_path) -> int`, `connect_v2(db_path) -> sqlite3.Connection`, `money(value) -> Decimal`, `money_text(value) -> str`.

- [ ] Write passing V0.4 smoke tests before production changes: init DB, state roundtrip, CSV business upload normalization, `/api/state`, static index existence.
- [ ] Run baseline tests and record PASS.
- [ ] Write failing tests for V0.4->V2 migration, repeat migration, rollback injection, required tables/columns/indexes/channel seed, and Decimal behavior.
- [ ] Run new tests and verify they fail because V2 does not exist.
- [ ] Implement `db_v2.py` migration in one explicit SQLite transaction; extend `stores` in place, create schema metadata and V2 tables, seed standard channels idempotently.
- [ ] Wire `init_db()` to call the migration after legacy V0.4 initialization commits.
- [ ] Run tests until green and commit.

### Task 2: Implement import provenance and idempotent daily channel sales

**Files:**
- Create: `tests/test_sales_import_v2.py`
- Create: `data_foundation.py`
- Modify: `db_v2.py`

**Interfaces:**
- Produces: `ImportResult`, `import_daily_sales(db_path, store_id, filename, data, source_type, channel_code=None)`, `list_import_batches(db_path, store_id)`, `list_daily_sales(db_path, store_id, start=None, end=None, channel_code=None)`.

- [ ] Write failing tests for file/batch/raw row creation, unknown fields, accepted/rejected/duplicate counts, sales upsert, same-file three-upload no-double-count, and traceability chain.
- [ ] Run tests to verify RED.
- [ ] Implement file identity/hash, import batch lifecycle, raw row retention, header-name parser, validation, channel resolution, canonical Decimal persistence, and daily sales upsert.
- [ ] Run tests to GREEN; refactor only after green; commit.

### Task 3: Implement settlements, platform fees, and payments with stable deduplication

**Files:**
- Create: `tests/test_settlement_payment_import_v2.py`
- Modify: `data_foundation.py`

**Interfaces:**
- Produces: `import_settlements(...)`, `import_payments(...)`, `list_settlements(...)`, `list_payments(...)`, `list_platform_fees(...)`.

- [ ] Write failing tests for settlement fields, reported vs calculated amount coexistence, fee rows, stable settlement fingerprint, payment fingerprint, reliable bank-reference dedup, and three-upload no-double-count behavior.
- [ ] Run tests to RED.
- [ ] Implement minimal importers and dedup/upsert semantics without platform-specific parsers.
- [ ] Run tests to GREEN and commit.

### Task 4: Centralize calculation profiles and reconciliation

**Files:**
- Create: `tests/test_calculation_reconciliation_v2.py`
- Modify: `data_foundation.py`

**Interfaces:**
- Produces: `calculate_channel_net_revenue(values, profile) -> Decimal | None`, `calculate_expected_settlement(values, profile) -> Decimal | None`, `create_reconciliation_match(...)`, `get_reconciliation(db_path, store_id, tolerance='1.00')`.

- [ ] Write failing tests proving subsidy sign is profile-dependent, no-profile returns no fabricated calculated amount, MATCHED 1000/1000, SMALL_DIFFERENCE 1000/990 under configured tolerance, missing payment, missing settlement, one settlement/multiple payments, and multiple settlements/one payment via match table.
- [ ] Run tests to RED.
- [ ] Implement calculation profile registry and many-to-many reconciliation aggregation using Decimal only.
- [ ] Run tests to GREEN and commit.

### Task 5: Add V2 APIs and legacy compatibility adapter without breaking V0.4 routes

**Files:**
- Create: `tests/test_api_v2.py`
- Create: `tests/test_legacy_compatibility_v2.py`
- Modify: `app.py`
- Modify: `data_foundation.py`

**Interfaces:**
- Produces V2 routes: `/api/v2/channels`, `/api/v2/sales/daily`, `/api/v2/import/sales`, `/api/v2/settlements`, `/api/v2/import/settlements`, `/api/v2/payments`, `/api/v2/import/payments`, `/api/v2/reconciliation`, `/api/v2/import-batches`.
- Produces: `legacy_business_adapter(db_path, store_id, legacy_business) -> dict | None`.

- [ ] Write failing HTTP tests for all V2 routes and legacy adapter behavior.
- [ ] Run tests to RED.
- [ ] Add thin FastAPI endpoints using data-foundation services; do not remove/rename old routes.
- [ ] Implement compatibility adapter that only replaces provable revenue/order fields and retains legacy-only values; never fabricates missing profit/cost fields.
- [ ] Run V2 + V0.4 regression tests to GREEN and commit.

### Task 6: Gate review, documentation, packaging

**Files:**
- Create: `V0.5.0_GATE_REVIEW.md`
- Modify: `README.md`
- Create/update: output archive outside source tree.

**Interfaces:**
- Produces final audit report and distributable source archive.

- [ ] Run full pytest suite.
- [ ] Run migration against an untouched copy of the original V0.4 database and verify legacy rows survive.
- [ ] Run repeated-upload tests three times and compare aggregate totals.
- [ ] Run traceability query from normalized sale back to raw row/batch/file.
- [ ] Run reconciliation scenarios including many-to-many match records.
- [ ] Start FastAPI on an ephemeral/local test port and hit `/api/health`, `/api/state`, and key `/api/v2/*` routes.
- [ ] Confirm `static/index.html` is unchanged unless a minimal compatibility fix was strictly required.
- [ ] Write gate report: baseline, modified files, DB changes, migration, money semantics, deduplication, traceability, compatibility, APIs, tests, known limitations, risks, recommendation; explicitly stop before V0.5.1.
- [ ] Create `食策AI_V0.5.0_Data_Foundation.zip` and verify archive contents.
