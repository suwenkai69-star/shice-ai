# 食策AI Mini V1 Cloud PostgreSQL Migration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Keep the current SQLite Mini V1 RC fully usable while adding a production-safe Neon PostgreSQL persistence path, EPHEMERAL upload confirmation flow, and a Vercel HTTPS deployment that persists real Mini V1 data across instances.

**Architecture:** Existing Mini V1 business Services remain the single source of truth. A SQLAlchemy Core persistence adapter accepts either the existing SQLite path or a runtime PostgreSQL engine; repositories and Data Foundation are migrated onto that adapter without duplicating business rules. Vercel production uses Neon PostgreSQL and never falls back to local SQLite or persistent local uploads.

**Tech Stack:** Python 3.13, FastAPI, SQLAlchemy 2.x Core, Psycopg 3, SQLite for local/regression, Neon PostgreSQL for cloud, pytest, httpx, openpyxl, Vercel Python Functions, native WeChat Mini Program.

**Spec:** `docs/superpowers/specs/2026-09-02-shice-ai-mini-v1-cloud-postgres-design.md`

## Global Constraints

- The immutable source baseline is `食策AI_Mini_V1_RC.zip`; implementation happens in a new `食策AI_Mini_V1_Cloud_Postgres_Development/` directory.
- Baseline before cloud changes is `210 passed, 2 warnings`; the two warnings are the existing FastAPI `on_event` deprecation warnings and must not be hidden.
- `DATABASE_URL` empty in local/test mode means SQLite. `DATABASE_URL` with `postgresql://` or `postgresql+psycopg://` means PostgreSQL.
- `SHICE_ENV=production` or `VERCEL=1` with missing `DATABASE_URL` must fail startup; production must never create a temporary SQLite fallback.
- Production starts from an empty business database. Only schema, stable channel seed, system configuration, and `review_status=APPROVED` benchmark rows may be seeded.
- Demo users, Demo stores, legacy `app_state`, test transactions, local upload history, and test Actions must never be seeded into production PostgreSQL.
- Raw image/CSV/XLSX bytes are EPHEMERAL in cloud. PostgreSQL stores metadata, hashes, structured drafts, extracted fields, corrections, model/template provenance, and final import lineage only.
- File confirmation must work after raw bytes are gone. Image confirmation must work after the image bytes are gone.
- Cloud image recognition runs inside the upload request for V1; no critical workflow may rely on FastAPI `BackgroundTasks` surviving after response completion.
- Shared/migrated SQL uses named parameters through SQLAlchemy Core/Text. Do not add new SQLite `?` placeholders, `INSERT OR IGNORE`, `lastrowid`, or SQLite-only SQL to cloud-capable paths.
- Existing money semantics remain Decimal-in-business-layer with persisted decimal text for this migration. Do not change financial semantics while changing the database.
- R1 invariants must remain true on PostgreSQL: import lineage, raw-row auditability, idempotency, incomplete correction fail-closed, channel conflict rejection, cross-channel reconciliation rejection, no fabricated daily allocation of period fees, and separation of revenue from settlement semantics.
- Mini V1 remains single-store owner mode. All protected reads/writes derive the user from the Bearer token and the store from that user's ownership; client-provided store IDs are never trusted as authorization.
- Production without WeChat credentials must not silently enable `DevAuthProvider`. Production without `MINI_TOKEN_SECRET` must fail startup.
- Production without a recognition/text AI provider returns a stable unavailable state; Fake providers are test-only.
- Production exposes only `/api/health` and `/api/mini/v1/**`; legacy Web, `/api/state`, `/api/v2/**`, backup/restore/reset/sample/static routes remain local-only and must not touch ephemeral SQLite in Vercel.
- Secrets (`DATABASE_URL`, `WECHAT_SECRET`, `MINI_TOKEN_SECRET`, AI keys) never appear in source, Mini Program config, API responses, or logs.
- Do not change the Mini Program release base URL until public Vercel acceptance passes against PostgreSQL.
- WeChat DevTools/real-device Gate remains `PENDING` until AppID, legal domains, login, upload, and subscription message flows are tested externally.
- The RC contains no `.git` metadata. Do not fabricate repository history. Use Gate snapshots and SHA-256 artifacts instead of fake commits.

---

## File Structure Locked by This Plan

Create:

```text
persistence/
  __init__.py
  config.py
  database.py
  schema.py
  seed.py
  data_foundation_repository.py
  postgres/
    0001_mini_v1_initial.sql
    0002_upload_drafts.sql

tests/cloud/
  conftest.py
  test_persistence_config.py
  test_database_adapter.py
  test_postgres_schema_contract.py
  test_seed_contract.py
  test_repository_contracts.py
  test_data_foundation_postgres.py
  test_ephemeral_uploads.py
  test_tenant_isolation.py
  test_postgres_acceptance.py
  test_production_startup.py
  test_public_contract.py

vercel.json
```

Modify in focused steps:

```text
requirements.txt
db_v3.py
app.py
mini/deps.py
mini/auth.py
mini/routes.py
mini/upload_routes.py
mini/issue_routes.py
repositories/mini_store_repository.py
repositories/mini_sales_repository.py
repositories/mini_cost_repository.py
repositories/upload_repository.py
repositories/data_status_repository.py
repositories/insight_repository.py
repositories/action_repository.py
data_foundation.py
recognition/service.py
services/benchmark_service.py
services/completeness_service.py
services/cost_resolver.py
services/manual_ingestion.py
services/mini_import_adapter.py
services/profit_engine.py
services/verification_engine.py
services/reconciliation_summary.py
```

The legacy Web state functions in `app.py` stay SQLite-only and are not moved to PostgreSQL.

---

### Task 1: Create the isolated cloud workspace and lock the SQLite baseline

**Files:**
- Create working copy: `/mnt/data/食策AI_Mini_V1_Cloud_Postgres_Development/`
- Create: `docs/superpowers/gates/2026-09-02-cloud-postgres-baseline.md`
- Test: existing `tests/`

**Interfaces:**
- Consumes: immutable `食策AI_Mini_V1_RC.zip`.
- Produces: isolated executable source tree whose baseline behavior is proven before cloud edits.

- [ ] **Step 1: Extract the RC into a new development directory**

```bash
rm -rf /mnt/data/食策AI_Mini_V1_Cloud_Postgres_Development
mkdir -p /mnt/data/食策AI_Mini_V1_Cloud_Postgres_Development
unzip -q /mnt/data/食策AI_Mini_V1_RC.zip -d /mnt/data/食策AI_Mini_V1_Cloud_Postgres_Development
```

Normalize the nested extracted directory so the project root contains `app.py`, `db.py`, `repositories/`, `services/`, `tests/`, and `miniprogram/` directly.

- [ ] **Step 2: Run the full baseline test suite**

Run:

```bash
pytest -q
```

Expected: exactly `210 passed` and the existing two FastAPI `on_event` deprecation warnings, with zero failures.

- [ ] **Step 3: Verify syntax baseline**

```bash
python -m compileall -q .
find miniprogram -name '*.js' -print0 | xargs -0 -n1 node --check
```

Expected: exit code 0 for both commands.

- [ ] **Step 4: Write the baseline Gate**

`docs/superpowers/gates/2026-09-02-cloud-postgres-baseline.md` records the exact commands, counts, warning count, source ZIP SHA-256, and the fact that the source RC is immutable.

- [ ] **Step 5: Snapshot checkpoint**

Create `食策AI_Mini_V1_Cloud_Postgres_Baseline.zip` plus SHA-256 before any production code changes.

---

### Task 2: Add persistence configuration and the SQLAlchemy database adapter

**Files:**
- Create: `persistence/__init__.py`
- Create: `persistence/config.py`
- Create: `persistence/database.py`
- Modify: `requirements.txt`
- Test: `tests/cloud/test_persistence_config.py`
- Test: `tests/cloud/test_database_adapter.py`

**Interfaces:**
- Produces: `PersistenceSettings`, `Database`, `DatabaseTarget`, `coerce_database()`, `build_runtime_database()`.
- Later tasks must accept `DatabaseTarget = Database | str | Path` rather than assuming `Path`.

- [ ] **Step 1: Write failing configuration tests**

```python
from pathlib import Path
import pytest

from persistence.config import PersistenceConfigError, load_persistence_settings


def test_local_without_database_url_uses_sqlite(monkeypatch, tmp_path):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.setenv("SHICE_ENV", "local")
    settings = load_persistence_settings(tmp_path / "local.db")
    assert settings.backend == "sqlite"
    assert settings.sqlite_path == tmp_path / "local.db"


def test_production_without_database_url_fails_closed(monkeypatch, tmp_path):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.setenv("SHICE_ENV", "production")
    with pytest.raises(PersistenceConfigError, match="DATABASE_URL"):
        load_persistence_settings(tmp_path / "ignored.db")


def test_postgres_url_selects_postgres(monkeypatch, tmp_path):
    monkeypatch.setenv("SHICE_ENV", "production")
    monkeypatch.setenv("DATABASE_URL", "postgresql+psycopg://user:pass@example.invalid/db")
    settings = load_persistence_settings(tmp_path / "ignored.db")
    assert settings.backend == "postgresql"
```

- [ ] **Step 2: Run the new tests and verify RED**

```bash
pytest tests/cloud/test_persistence_config.py -q
```

Expected: import/module failures because `persistence.config` does not exist.

- [ ] **Step 3: Implement runtime configuration**

`persistence/config.py` exposes:

```python
@dataclass(frozen=True)
class PersistenceSettings:
    environment: str
    backend: Literal["sqlite", "postgresql"]
    sqlite_path: Path
    database_url: str | None

class PersistenceConfigError(RuntimeError):
    pass

# public function: load_persistence_settings(sqlite_path: str | Path) -> PersistenceSettings
```

Rules are exactly the Global Constraints above. Accept both `postgresql://` and `postgresql+psycopg://`; normalize bare `postgresql://` to the Psycopg SQLAlchemy URL only inside the backend builder, never by editing the secret.

- [ ] **Step 4: Write failing adapter tests**

```python
from sqlalchemy import text
from persistence.database import Database


def test_sqlite_transaction_rolls_back(tmp_path):
    db = Database.sqlite(tmp_path / "adapter.db")
    with db.begin() as con:
        con.execute(text("CREATE TABLE sample(id INTEGER PRIMARY KEY, value TEXT NOT NULL)"))
    try:
        with db.begin() as con:
            con.execute(text("INSERT INTO sample(id,value) VALUES(:id,:value)"), {"id": 1, "value": "x"})
            raise RuntimeError("boom")
    except RuntimeError:
        pass
    with db.connect() as con:
        assert con.execute(text("SELECT COUNT(*) FROM sample")).scalar_one() == 0
```

- [ ] **Step 5: Run adapter tests and verify RED**

```bash
pytest tests/cloud/test_database_adapter.py -q
```

Expected: fail because `Database` is missing.

- [ ] **Step 6: Implement the adapter**

`persistence/database.py` exposes:

The exact public API is:

- `DatabaseTarget = Database | str | Path`
- `Database.sqlite(path: str | Path) -> Database`
- `Database.postgres(url: str) -> Database`
- `Database.backend -> str`
- `Database.begin() -> ContextManager[Connection]`
- `Database.connect() -> ContextManager[Connection]`
- `Database.dispose() -> None`
- `coerce_database(target: DatabaseTarget) -> Database`
- `build_runtime_database(sqlite_path: str | Path) -> Database`

SQLite engine must enable foreign keys on connect. PostgreSQL engine uses Psycopg 3 and `NullPool` for serverless-safe short-lived connection behavior.

- [ ] **Step 7: Add dependencies**

Append to `requirements.txt`:

```text
SQLAlchemy>=2.0,<3
psycopg[binary]>=3.2,<4
```

- [ ] **Step 8: Verify GREEN and full SQLite regression**

```bash
pytest tests/cloud/test_persistence_config.py tests/cloud/test_database_adapter.py -q
pytest -q
```

Expected: cloud adapter tests pass and the existing SQLite suite remains green.

---

### Task 3: Define the cloud schema and SQLite-compatible upload draft additions

**Files:**
- Create: `persistence/schema.py`
- Create: `persistence/postgres/0001_mini_v1_initial.sql`
- Create: `persistence/postgres/0002_upload_drafts.sql`
- Modify: `db_v3.py`
- Test: `tests/cloud/test_postgres_schema_contract.py`
- Test: existing `tests/test_schema_v3.py`, `tests/test_ingestion_schema.py`

**Interfaces:**
- Produces: `CLOUD_SCHEMA_VERSION = 1`, `required_cloud_tables()`, PostgreSQL initial migration SQL, additive local SQLite upload-draft schema.
- Consumes: exact table/field semantics in `db_v2.py` and `db_v3.py`.

- [ ] **Step 1: Write the schema-contract test before DDL**

```python
from persistence.schema import required_cloud_tables


def test_required_cloud_tables_exclude_legacy_demo_state():
    tables = required_cloud_tables()
    assert "app_state" not in tables
    assert "uploads" not in tables
    for name in {
        "users", "stores", "channels", "import_files", "import_batches", "raw_import_rows",
        "daily_channel_sales", "settlements", "platform_fees", "payments", "reconciliation_matches",
        "mini_users", "store_profiles", "daily_store_sales_totals", "store_cost_profiles",
        "cost_entries", "industry_benchmarks", "profit_snapshots", "upload_documents",
        "upload_drafts", "extraction_jobs", "extracted_fields", "document_import_links",
        "store_data_sources", "daily_data_status", "anomaly_events", "action_items",
        "action_executions", "action_verifications", "reminders", "ai_conversations", "ai_messages"
    }:
        assert name in tables
```

- [ ] **Step 2: Verify RED**

```bash
pytest tests/cloud/test_postgres_schema_contract.py -q
```

Expected: missing `persistence.schema` or missing required table definitions.

- [ ] **Step 3: Implement schema metadata constants**

`persistence/schema.py` defines the exact required table set, stable standard channel codes, `CLOUD_SCHEMA_VERSION = 1`, and the approved upload statuses. It does not contain business calculations.

- [ ] **Step 4: Author PostgreSQL initial DDL**

`0001_mini_v1_initial.sql` creates from scratch the cloud tables listed in the schema-contract test, preserving existing text-money and integer-millisecond semantics. PostgreSQL identity columns replace SQLite `AUTOINCREMENT`. Existing uniqueness/check/foreign-key semantics from `db_v2.py` and `db_v3.py` are preserved. `schema_meta` stores both:

```text
schema_version = 3
cloud_schema_version = 1
```

The cloud `users` table contains `id`, `name`, `role`. The cloud `stores` table contains `id`, `user_id`, `name`, `type`, `store_type`, `timezone`, `currency`, `created_at`, `updated_at` so Mini repositories do not depend on the legacy initializer.

- [ ] **Step 5: Author the upload-draft migration contract**

`0002_upload_drafts.sql` adds/creates these cloud fields and table:

```text
upload_documents.storage_policy
upload_documents.content_hash
upload_documents.size_bytes
upload_documents.processed_at
upload_drafts.id
upload_drafts.document_id UNIQUE
upload_drafts.draft_type
upload_drafts.preview_json
upload_drafts.canonical_payload_json
upload_drafts.payload_hash
upload_drafts.created_at
upload_drafts.updated_at
```

`storage_key` remains nullable. Cloud documents use `storage_policy='EPHEMERAL'` and `storage_key=NULL`.

- [ ] **Step 6: Add the same additive fields/table to SQLite V3**

Extend `ensure_v3_additive_schema()` in `db_v3.py` without changing `schema_version=3`. Existing local databases gain the new nullable/default-compatible upload fields and `upload_drafts` table idempotently.

- [ ] **Step 7: Verify local schema compatibility**

```bash
pytest tests/test_schema_v3.py tests/test_ingestion_schema.py tests/cloud/test_postgres_schema_contract.py -q
pytest -q
```

Expected: all pass; no existing SQLite table is dropped or rebuilt.

---

### Task 4: Add deterministic system seed logic with no Demo contamination

**Files:**
- Create: `persistence/seed.py`
- Modify: `services/benchmark_service.py`
- Test: `tests/cloud/test_seed_contract.py`
- Data: `data/benchmarks/benchmark_seed.json`

**Interfaces:**
- Produces: `SeedResult(channel_count: int, benchmark_count: int, seed_sha256: str)`.
- Produces: `seed_system_data(db: Database, benchmark_seed_path: Path) -> SeedResult`.
- The function is idempotent and never creates users/stores/app_state.

- [ ] **Step 1: Write failing seed tests**

Use a temporary SQLite V3 database created with the existing `migrate_database()` plus the new additive draft schema, wrap it with `Database.sqlite()`, and assert:

```python
from sqlalchemy import text

result1 = seed_system_data(db, benchmark_seed_path)
result2 = seed_system_data(db, benchmark_seed_path)
assert result1.channel_count == result2.channel_count == 10
with db.connect() as con:
    assert con.execute(text("SELECT COUNT(*) FROM users")).scalar_one() == 0
    assert con.execute(text("SELECT COUNT(*) FROM stores")).scalar_one() == 0
    assert con.execute(text("SELECT COUNT(*) FROM industry_benchmarks WHERE review_status <> 'APPROVED'" )).scalar_one() == 0
```

The standard channel set must include `TAOBAO_FLASH` while retaining the prior nine stable codes.

- [ ] **Step 2: Verify RED**

```bash
pytest tests/cloud/test_seed_contract.py -q
```

Expected: missing `seed_system_data`.

- [ ] **Step 3: Implement channel seed using named SQL**

Use PostgreSQL/SQLite-compatible conflict handling with `ON CONFLICT(code) DO UPDATE` or explicit select/update semantics through SQLAlchemy; do not use `INSERT OR IGNORE`.

- [ ] **Step 4: Filter Benchmark seed**

Only input rows with `review_status == "APPROVED"` may be inserted. Compute a SHA-256 of the normalized approved seed payload and record it in `schema_meta` under `benchmark_seed_sha256` so cold starts are idempotent.

- [ ] **Step 5: Verify GREEN**

```bash
pytest tests/cloud/test_seed_contract.py tests/test_benchmark_service.py -q
pytest -q
```

---

### Task 5: Add cloud migration manifest and schema validation helpers

**Files:**
- Create: `persistence/migrations.py`
- Test: `tests/cloud/test_postgres_schema_contract.py`

**Interfaces:**
- Consumes: `persistence/postgres/0001_mini_v1_initial.sql` and `0002_upload_drafts.sql`.
- Produces: `load_initial_migration_sql() -> str`, `initial_migration_sha256() -> str`, `assert_cloud_schema(db: Database) -> None`.

- [ ] **Step 1: Write failing migration-helper tests**

```python
from persistence.migrations import initial_migration_sha256, load_initial_migration_sql


def test_initial_migration_is_stable_and_contains_no_demo_tables():
    sql = load_initial_migration_sql()
    assert "CREATE TABLE" in sql
    assert "app_state" not in sql
    assert "CREATE TABLE uploads" not in sql
    assert len(initial_migration_sha256()) == 64
```

- [ ] **Step 2: Verify RED**

```bash
pytest tests/cloud/test_postgres_schema_contract.py -q
```

Expected: missing migration helper functions.

- [ ] **Step 3: Implement deterministic migration loading**

`load_initial_migration_sql()` reads the two migration files in numeric order and joins them with a newline. `initial_migration_sha256()` hashes the exact UTF-8 migration text so the same SQL can be verified before Neon application.

- [ ] **Step 4: Implement runtime cloud schema validation**

`assert_cloud_schema(db)` reads `schema_meta` through SQLAlchemy named SQL and requires both `schema_version='3'` and `cloud_schema_version='1'`. Missing/mismatched values raise a dedicated `CloudSchemaError` that `app.py` maps to production startup failure rather than auto-mutating the database.

- [ ] **Step 5: Verify GREEN**

```bash
pytest tests/cloud/test_postgres_schema_contract.py -q
pytest -q
```

---

### Task 6: Migrate Mini repositories to `DatabaseTarget` without changing their public behavior

**Files:**
- Modify: `repositories/mini_store_repository.py`
- Modify: `repositories/mini_sales_repository.py`
- Modify: `repositories/mini_cost_repository.py`
- Modify: `repositories/data_status_repository.py`
- Modify: `repositories/upload_repository.py`
- Test: `tests/cloud/test_repository_contracts.py`
- Existing tests: `tests/test_mini_repositories.py`, `tests/test_revenue_resolver.py`, `tests/test_benchmark_service.py`, `tests/test_file_upload_pipeline.py`

**Interfaces:**
- Every repository constructor becomes `__init__(self, database: DatabaseTarget)`.
- Repository return values remain plain `dict` / `list[dict]` with the same key names.
- `UploadRepository` additionally produces/consumes structured drafts.

- [ ] **Step 1: Write a reusable contract fixture**

`tests/cloud/test_repository_contracts.py` defines repository behavior functions that accept a `Database` and cover user/store creation, store-total upsert, cost profile, data status, document creation, draft round-trip, and store-scope rejection.

Example:

```python
def assert_store_repo_contract(db):
    repo = MiniStoreRepository(db)
    user = repo.create_or_get_user("contract-openid")
    store = repo.create_store(user["user_id"], "测试店", "MILK_TEA")
    assert repo.get_current_store(user["user_id"])["id"] == store["id"]
```

- [ ] **Step 2: Run contracts against SQLite and verify current migration path fails**

The new tests should fail before repository constructors/SQL are migrated because they pass a `Database` object rather than a filesystem path.

- [ ] **Step 3: Migrate `MiniStoreRepository`**

Replace `_connect()` and `lastrowid` with `Database.begin()` and insert statements that return the new identity through `RETURNING id`. Preserve single-store checks and category validation exactly.

- [ ] **Step 4: Migrate sales/cost/status repositories**

Use named SQL and backend-neutral booleans represented consistently as `0/1` at the public dict boundary where existing Services expect integers.

- [ ] **Step 5: Extend `UploadRepository`**

Add these exact public methods:

- `save_draft(document_id: int, *, draft_type: str, preview: dict, canonical_payload: dict) -> dict`
- `get_draft(document_id: int, *, store_id: int) -> dict | None`
- `delete_draft(document_id: int, *, store_id: int) -> None`

`create_document()` accepts `storage_policy`, `content_hash`, `size_bytes`, and `processed_at`. All document/job/field queries keep store ownership checks at or before the API boundary.

- [ ] **Step 6: Verify repository contracts and old tests**

```bash
pytest tests/cloud/test_repository_contracts.py tests/test_mini_repositories.py tests/test_revenue_resolver.py tests/test_benchmark_service.py tests/test_file_upload_pipeline.py -q
pytest -q
```

---

### Task 7: Migrate insight/action repositories and remove route-level SQLite access

**Files:**
- Modify: `repositories/insight_repository.py`
- Modify: `repositories/action_repository.py`
- Modify: `mini/issue_routes.py`
- Test: `tests/cloud/test_repository_contracts.py`
- Existing tests: `tests/test_anomaly_persistence.py`, `tests/test_action_engine.py`, `tests/test_reminder_service.py`, `tests/test_verification_engine.py`

**Interfaces:**
- `InsightRepository(DatabaseTarget)` and `ActionRepository(DatabaseTarget)` retain current method names.
- Add `InsightRepository.get_anomaly(anomaly_id: int, store_id: int) -> dict | None` so `mini/issue_routes.py` no longer opens sqlite directly.

- [ ] **Step 1: Add a failing owner-scoped anomaly lookup test**

```python
assert repo.get_anomaly(anomaly_id, store_a) is not None
assert repo.get_anomaly(anomaly_id, store_b) is None
```

- [ ] **Step 2: Migrate insight repository SQL to named parameters**

Preserve `replace_anomalies()` identity semantics and Top-3 inputs. PostgreSQL upsert behavior must use the same anomaly identity fields as SQLite's `uq_anomaly_identity`.

- [ ] **Step 3: Migrate action repository**

Replace SQLite-specific insert-ignore and lastrowid behavior with explicit conflict handling / `RETURNING id`. Preserve one execution per action, one verification per date, and reminder status transitions.

- [ ] **Step 4: Remove sqlite import from issue route**

`mini/issue_routes.py` must resolve the issue through `InsightRepository(get_database())` and return 404 when the authenticated store does not own it.

- [ ] **Step 5: Verify**

```bash
pytest tests/test_anomaly_persistence.py tests/test_action_engine.py tests/test_reminder_service.py tests/test_verification_engine.py tests/cloud/test_repository_contracts.py -q
pytest -q
```

---

### Task 8: Extract Data Foundation persistence while preserving all R1 business rules

**Files:**
- Create: `persistence/data_foundation_repository.py`
- Modify: `data_foundation.py`
- Test: `tests/cloud/test_data_foundation_postgres.py`
- Existing tests: `tests/test_sales_import_v2.py`, `tests/test_settlement_payment_import_v2.py`, `tests/test_data_integrity_r1.py`, `tests/test_calculation_reconciliation_v2.py`

**Interfaces:**
- Existing public function names remain usable: `import_daily_sales`, `import_settlements`, `import_payments`, `get_reconciliation`, list functions, calculation functions.
- Their first argument becomes `DatabaseTarget` while Path input stays valid.
- Backup/restore helpers remain explicitly SQLite-local and are not called by Mini PostgreSQL routes.

- [ ] **Step 1: Write PostgreSQL-neutral Data Foundation contract tests using the same public functions**

The test cases must reproduce these R1 behaviors independently of dialect:

```text
same sales import twice -> no double accumulation
incomplete sales correction -> rejected, prior normalized row preserved
incomplete settlement correction -> rejected, prior fee detail preserved
period settlement fee -> platform_fees.business_date remains NULL
explicit channel conflict -> raw row audited, normalized row rejected
cross-channel reconciliation -> rejected
malformed/empty file -> FAILED import batch exists
revenue and expected settlement -> distinct calculations
```

- [ ] **Step 2: Verify RED with `Database` target**

Current functions expect paths / sqlite connections, so the new contract tests must fail before refactor.

- [ ] **Step 3: Move database-only helpers into `DataFoundationRepository`**

The new repository owns import-file lookup, batch lifecycle, raw-row insert, normalized upsert, settlement fee replacement, payment upsert, reconciliation match persistence, and list queries. Parsing, normalization, fingerprints, Decimal calculations, and fail-closed business decisions remain in `data_foundation.py`.

- [ ] **Step 4: Replace identity retrieval and conflict SQL**

Every inserted ID is obtained with `RETURNING id`. Every idempotency decision is explicit; no cloud-capable code uses `INSERT OR IGNORE` or `lastrowid`.

- [ ] **Step 5: Keep local backup/restore isolated**

`export_full_backup`, `restore_full_backup`, and SQLite snapshot helpers explicitly require a filesystem SQLite path and raise a clear unsupported error if passed a PostgreSQL `Database`. Mini cloud routes do not expose these legacy functions.

- [ ] **Step 6: Verify full R1 regression**

```bash
pytest tests/test_sales_import_v2.py tests/test_settlement_payment_import_v2.py tests/test_data_integrity_r1.py tests/test_calculation_reconciliation_v2.py tests/cloud/test_data_foundation_postgres.py -q
pytest -q
```

---

### Task 9: Remove direct SQLite access from cloud-used Services

**Files:**
- Modify: `services/benchmark_service.py`
- Modify: `services/completeness_service.py`
- Modify: `services/cost_resolver.py`
- Modify: `services/manual_ingestion.py`
- Modify: `services/mini_import_adapter.py`
- Modify: `services/profit_engine.py`
- Modify: `services/verification_engine.py`
- Modify: `services/reconciliation_summary.py`
- Modify as needed: `services/anomaly_engine.py`, `services/today_aggregator.py`, `services/trend_service.py`, `services/ai_context_service.py`
- Test: existing service/API suites.

**Interfaces:**
- Cloud-used Service constructors accept `DatabaseTarget` and pass the same `Database` object to downstream repositories/services.
- No listed cloud-used Service imports `sqlite3` after this task.

- [ ] **Step 1: Add a static contract test**

Create an assertion that these production files do not contain `import sqlite3`, `sqlite3.connect`, or `PRAGMA`.

- [ ] **Step 2: Verify RED**

The static test must fail against the current RC, proving it detects the direct SQLite dependencies.

- [ ] **Step 3: Migrate each direct query to an owning repository**

Examples:

```text
ProfitEngine snapshot insert -> MiniCost/Profit persistence helper
VerificationEngine direct lookup -> ActionRepository
CompletenessService historical source query -> DataStatusRepository
ManualIngestion direct payment/channel query -> Data Foundation repository/public function
MiniImportAdapter import-link/source lookup -> UploadRepository/Data Foundation public interface
```

Do not move formulas or decision rules into the persistence layer.

- [ ] **Step 4: Preserve one transaction per business write**

Manual import, confirmed document import, action execution, and verification save must not become a sequence of independently committed partial writes. Where multiple repositories participate, pass an existing SQLAlchemy `Connection`/unit-of-work through repository methods rather than opening nested unrelated transactions.

- [ ] **Step 5: Verify all service behavior**

```bash
pytest tests/test_profit_engine.py tests/test_completeness_service.py tests/test_manual_ingestion_api.py tests/test_verification_engine.py tests/test_today_api.py tests/test_ai_context.py -q
pytest -q
```

---

### Task 10: Implement the EPHEMERAL upload pipeline

**Files:**
- Modify: `mini/upload_routes.py`
- Modify: `recognition/service.py`
- Modify: `services/mini_import_adapter.py`
- Modify: `repositories/upload_repository.py`
- Modify: `services/file_preview.py` only if limits require a shared guard
- Create: `tests/cloud/test_ephemeral_uploads.py`
- Existing tests: `tests/test_file_upload_pipeline.py`, `tests/test_image_confirm_api.py`, `tests/test_recognition_service.py`, `tests/test_openai_recognition_provider.py`

**Interfaces:**
- Add `RecognitionService.create_draft_from_bytes(document_id: int, image_bytes: bytes) -> dict`.
- File upload stores structured `upload_drafts`; confirmation reads the draft, never the raw file.
- Cloud image upload returns `NEEDS_CONFIRMATION` in the same request when recognition succeeds.

- [ ] **Step 1: Write failing file EPHEMERAL test**

```python
response = client.post(
    "/api/mini/v1/uploads/file",
    files={"file": ("sales.csv", b"business_date,gross_sales\n2026-09-02,100\n", "text/csv")},
    headers=auth,
)
doc_id = response.json()["id"]
assert response.json()["status"] == "NEEDS_CONFIRMATION"
assert UploadRepository(db).get_document(doc_id, store_id=store_id)["storage_key"] is None
assert UploadRepository(db).get_draft(doc_id, store_id=store_id) is not None
confirm = client.post(f"/api/mini/v1/uploads/{doc_id}/confirm", headers=auth)
assert confirm.json()["status"] == "IMPORTED"
```

The test must delete/ignore any original byte source before confirmation to prove confirmation is independent from raw files.

- [ ] **Step 2: Write failing image EPHEMERAL test**

Inject the existing deterministic recognition stub. Upload image bytes and assert the API returns a confirmable document without any stored path. After discarding the input bytes, patch a field and confirm import successfully.

- [ ] **Step 3: Add a single upload-limit configuration**

In `mini/upload_routes.py` or a focused config module define:

```python
MAX_IMAGE_BYTES = 10 * 1024 * 1024
MAX_FILE_BYTES = 10 * 1024 * 1024
MAX_XLSX_ROWS = 50_000
ALLOWED_FILE_SUFFIXES = {".csv", ".xlsx"}
```

Requests exceeding these limits fail with stable codes/messages before expensive parsing/recognition.

- [ ] **Step 4: Refactor file upload**

For FILE: read bounded bytes -> validate suffix/MIME -> compute SHA-256 -> parse once -> persist `upload_documents` metadata with `EPHEMERAL` -> persist canonical `upload_drafts` -> discard bytes -> return preview.

- [ ] **Step 5: Refactor image upload**

Remove `BackgroundTasks`, `_store_raw()`, and `_run_recognition()`. Create document metadata first, call `RecognitionService.create_draft_from_bytes()` synchronously, persist extraction job/fields, set `processed_at`, discard bytes, and return the actual recognition status.

- [ ] **Step 6: Refactor upload GET and confirmation**

GET FILE preview reads `upload_drafts.preview_json`. `MiniImportAdapter` reads `canonical_payload_json` for FILE and confirmed `extracted_fields` for IMAGE. Neither path requires `storage_key`.

- [ ] **Step 7: Verify no cloud persistent raw uploads**

Static test asserts cloud upload route no longer writes `mini_uploads/`, calls `write_bytes`, or reads `storage_key` for confirmation.

- [ ] **Step 8: Verify**

```bash
pytest tests/cloud/test_ephemeral_uploads.py tests/test_file_upload_pipeline.py tests/test_image_confirm_api.py tests/test_recognition_service.py tests/test_openai_recognition_provider.py -q
pytest -q
```

---

### Task 11: Harden production authentication and tenant boundaries

**Files:**
- Modify: `mini/auth.py`
- Modify: `mini/deps.py`
- Modify: `mini/routes.py`
- Modify protected routes only where an ID lookup lacks store scope
- Create: `tests/cloud/test_tenant_isolation.py`
- Create: `tests/cloud/test_production_startup.py`

**Interfaces:**
- `get_auth_provider()` refuses Dev auth in production.
- `TokenService()` refuses the default development secret in production.
- `mini.deps.get_database()` returns the app runtime Database.
- `current_store()` derives store ownership from authenticated `user_id`.

- [ ] **Step 1: Write failing production auth tests**

```python
monkeypatch.setenv("SHICE_ENV", "production")
monkeypatch.delenv("WECHAT_APPID", raising=False)
monkeypatch.delenv("WECHAT_SECRET", raising=False)
with pytest.raises(AuthError):
    get_auth_provider()

monkeypatch.delenv("MINI_TOKEN_SECRET", raising=False)
with pytest.raises(AuthError):
    TokenService()
```

- [ ] **Step 2: Write tenant isolation API tests**

Create owner A/store A and owner B/store B. With A's token, attempting to read/patch/confirm B's document, issue, action, profit context, or other ID-addressable resource must return 404/403 without revealing B's data.

- [ ] **Step 3: Implement production auth fail-closed behavior**

Local/test keeps `DevAuthProvider`; production requires configured WeChat credentials. The token secret default remains local-only.

- [ ] **Step 4: Replace `get_db_path()` as the cloud dependency**

Keep `get_db_path()` only for legacy/local compatibility. Add:

```python
def get_database() -> Database:
    import app as app_module
    return app_module.app.state.database
```

Cloud-used Mini routes/services receive `get_database()` instead of assuming a filesystem path.

- [ ] **Step 5: Verify**

```bash
pytest tests/cloud/test_tenant_isolation.py tests/cloud/test_production_startup.py tests/test_mini_auth_api.py tests/test_mini_v1_acceptance_api.py -q
pytest -q
```

---

### Task 12: Split local SQLite startup from PostgreSQL production startup

**Files:**
- Modify: `app.py`
- Modify: `persistence/seed.py`
- Create: `tests/cloud/test_production_startup.py`

**Interfaces:**
- `app.state.database` is initialized once per process.
- Local SQLite startup preserves legacy Demo/Web behavior.
- PostgreSQL startup validates cloud schema and seeds only system data.

- [ ] **Step 1: Write startup-mode tests**

Local mode asserts Demo store behavior remains available for legacy Web. Production/Postgres mode asserts no Demo user/store/app_state initialization is invoked and schema mismatch raises `DATABASE_MIGRATION_REQUIRED`/startup error.

- [ ] **Step 2: Implement explicit startup functions**

Add these exact startup functions:

- `init_sqlite_local(db_path: Path) -> None`
- `init_postgres_production(db: Database) -> None`
- `init_runtime() -> Database`

`init_runtime()` builds `app.state.database`. PostgreSQL path checks `cloud_schema_version == 1`, runs idempotent system seed, and does not call `recover_interrupted_jobs()` because cloud uploads no longer rely on local files/background recovery.

- [ ] **Step 3: Add a production route guard and local-only static mount**

When running production/PostgreSQL, only `/api/health` and `/api/mini/v1/**` are routable. Requests to legacy Web/API routes such as `/`, `/static/**`, `/api/state`, `/api/session`, `/api/sample/**`, `/api/upload/**`, `/api/v2/**`, `/api/backup`, `/api/reset`, and `/api/restore` return 404 without opening SQLite. Mount `StaticFiles` and serve `static/index.html` only in local SQLite mode so the Vercel bundle can omit legacy static assets safely.

- [ ] **Step 4: Extend health response**

`/api/health` must expose non-secret operational fields only:

```json
{
  "status": "ok",
  "version": "0.5.0-R1+MiniV1",
  "schema_version": 3,
  "cloud_schema_version": 1,
  "database_backend": "postgresql"
}
```

Do not include host, database name, user, URL, or credentials.

- [ ] **Step 5: Verify local and production startup tests**

```bash
pytest tests/cloud/test_production_startup.py tests/test_v04_regression.py tests/test_legacy_compatibility_v2.py tests/test_api_v2.py -q
pytest -q
```

---

### Task 13: Create Neon, prepare the migration on a temporary branch, and run the real PostgreSQL contract suite

**Files:**
- Create: `tests/cloud/conftest.py`
- Create/complete: `tests/cloud/test_postgres_schema_contract.py`
- Create/complete: `tests/cloud/test_repository_contracts.py`
- Create/complete: `tests/cloud/test_data_foundation_postgres.py`
- Create: `tests/cloud/test_postgres_acceptance.py`
- Gate: `docs/superpowers/gates/2026-09-02-cloud-postgres-temporary-branch-gate.md`

**Interfaces:**
- Consumes: reviewed migration text from `load_initial_migration_sql()`.
- Produces: Neon project ID, exact migration ID, temporary branch ID, temporary connection string kept only in process environment, and PostgreSQL contract evidence.

- [ ] **Step 1: Create a Neon project named `shice-ai-mini-v1`**

Use the Neon project creation action. Record only the returned project ID/default database name in the Gate document; do not record connection strings.

- [ ] **Step 2: Prepare the initial schema migration through Neon**

Submit the exact `load_initial_migration_sql()` text through `prepare_database_migration`. This creates a temporary branch and applies the schema there, not to main.

- [ ] **Step 3: Verify the temporary migration branch immediately**

Using the exact temporary branch ID returned by the migration tool, run read-only Neon SQL checks:

```sql
SELECT value FROM schema_meta WHERE key='cloud_schema_version';
SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY table_name;
SELECT COUNT(*) FROM users;
SELECT COUNT(*) FROM stores;
```

Expected: cloud schema version `1`, every required table present, and zero users/stores before system seed.

- [ ] **Step 4: Obtain the temporary-branch connection string and run system seed**

Get a connection string for that exact temporary branch and place it only in `DATABASE_URL` for the current test process. Run:

```bash
SHICE_ENV=test DATABASE_URL="$NEON_TEST_URL" python -c "from pathlib import Path; from persistence.database import build_runtime_database; from persistence.seed import seed_system_data; db=build_runtime_database(Path('data/unused-cloud.db')); seed_system_data(db, Path('data/benchmarks/benchmark_seed.json')); db.dispose()"
```

Then verify ten stable channels, only approved benchmark records, and still zero business users/stores.

- [ ] **Step 5: Run schema/seed contracts**

```bash
SHICE_ENV=test DATABASE_URL="$NEON_TEST_URL" pytest \
  tests/cloud/test_postgres_schema_contract.py \
  tests/cloud/test_seed_contract.py -q
```

- [ ] **Step 6: Run repository, R1, upload, and tenant contracts on PostgreSQL**

```bash
SHICE_ENV=test DATABASE_URL="$NEON_TEST_URL" pytest \
  tests/cloud/test_repository_contracts.py \
  tests/cloud/test_data_foundation_postgres.py \
  tests/cloud/test_ephemeral_uploads.py \
  tests/cloud/test_tenant_isolation.py -q
```

- [ ] **Step 7: Run a complete Mini V1 PostgreSQL story**

`test_postgres_acceptance.py` performs:

```text
production-style auth provider stub
→ create user/store
→ manual sales
→ cost profile
→ Today
→ CSV upload draft/confirm
→ image provider-stub upload/field correction/confirm
→ reconciliation read
→ generate/execute Action
→ verification on next business date
→ dispose Database engine
→ create a new engine against the same Neon temporary branch
→ read store/Today again and prove persisted state remains
```

- [ ] **Step 8: Run the complete SQLite regression again**

```bash
unset DATABASE_URL
SHICE_ENV=test pytest -q
```

Expected: no SQLite regression failures.

- [ ] **Step 9: Write the temporary-branch Gate and stop for migration approval**

Record exact PostgreSQL test counts, SQLite test counts, warning counts, migration SHA-256, and any deliberately pending external provider tests. Do not write connection strings.

Per Neon migration workflow, now report to the user the exact **Migration ID**, **Temporary Branch Name**, **Temporary Branch ID**, and **Migration Result**, and ask whether to apply that exact migration to the Neon main branch. Do not call `complete_database_migration` until the user explicitly approves.

---

### Task 14: Apply the approved schema to Neon main and verify an empty production database

**Files:**
- Gate: `docs/superpowers/gates/2026-09-02-neon-main-gate.md`

**Interfaces:**
- Consumes: user-approved migration ID from Task 13.
- Produces: production Neon main branch with empty business data and system seeds only.

- [ ] **Step 1: Complete the approved Neon migration**

Call `complete_database_migration` with the exact returned migration ID, SQL, project ID, temporary branch ID, parent branch ID, and `applyChanges=True`.

- [ ] **Step 2: Obtain the Neon main connection string and run the same system seed**

Keep the connection string only in the current process environment. Run `seed_system_data()` once against main, using the reviewed benchmark seed.

- [ ] **Step 3: Verify main schema and clean seed state**

Run read-only checks for cloud schema version, required tables, ten stable channel codes, approved benchmark count, and zero users/stores before first real login.

- [ ] **Step 4: Retain the Neon main connection string only for deployment configuration**

Do not write it into the project tree or Gate markdown.

- [ ] **Step 5: Record main Gate without secrets**

State that the main schema matches the approved migration and that Demo/test business rows are absent.

---

### Task 15: Add Vercel packaging and deploy the PostgreSQL FastAPI application

**Files:**
- Create: `vercel.json`
- Modify: `requirements.txt` if Vercel runtime requires no further package changes
- Test: `tests/cloud/test_public_contract.py`
- Gate: `docs/superpowers/gates/2026-09-02-vercel-cloud-gate.md`

**Interfaces:**
- Vercel production receives `DATABASE_URL`, `SHICE_ENV=production`, `MINI_TOKEN_SECRET`, and configured provider credentials as server-side environment variables.
- Public API entry remains the single FastAPI `app` in `app.py`.

- [ ] **Step 1: Add Vercel configuration**

`vercel.json` must route the FastAPI application, set a reasonable Python function duration for synchronous recognition, and exclude `tests/**`, `samples/**`, local SQLite data, local upload folders, and legacy static assets from the cloud function bundle when they are not needed by Mini API execution.

- [ ] **Step 2: Add a packaging/static test**

Assert the deploy bundle configuration does not contain `data/shice_ai.db`, `mini_uploads`, test fixtures, or any secret string.

- [ ] **Step 3: Deploy a preview first**

Use the Vercel deployment action with the cloud development source, targeting preview. Inject deployment environment secrets only through the supported Vercel environment mechanism; if the connector cannot set persistent environment variables, stop and request the one-time Vercel Environment Variables UI action rather than embedding secrets in files.

- [ ] **Step 4: Poll deployment status and inspect failures**

Wait for deployment success. If build fails, use build logs; if runtime fails, use runtime error/log tools. Follow systematic debugging and do not patch blindly.

- [ ] **Step 5: Run public HTTPS acceptance against preview**

`tests/cloud/test_public_contract.py` accepts `SHICE_PUBLIC_BASE_URL` and tests:

```text
GET /api/health -> 200, database_backend=postgresql
GET /api/state and GET /api/v2/channels -> 404 in production
unauthenticated protected route -> 401
production dev-code login -> rejected
configured test/real auth path -> creates persisted user
create store
manual sales/cost
Today
file draft/confirm
provider availability boundary
Action
new HTTP session -> same store/data still exists
```

Do not run destructive reset/backup endpoints against production cloud state.

- [ ] **Step 6: Promote/publish only after preview acceptance passes**

Deploy/publish the same verified code to production and repeat health + minimal persistence smoke tests.

- [ ] **Step 7: Write Vercel Gate**

Record deployment ID, public base URL, health result, PostgreSQL persistence proof, and pending WeChat external tests. Never record secrets.

---

### Task 16: Point the Mini Program release configuration to the verified HTTPS API and produce the cloud RC

**Files:**
- Modify: `miniprogram/config.js`
- Modify: `README_MINI_V1.md`
- Create: `docs/superpowers/gates/2026-09-02-cloud-final-gate.md`
- Create artifacts: `食策AI_Mini_V1_Cloud_RC.zip`, SHA-256 file

**Interfaces:**
- Consumes: production Vercel URL only after Task 15 public acceptance passes.
- Produces: cloud RC ready for WeChat DevTools/domain configuration.

- [ ] **Step 1: Write a failing release-config contract**

The static test must require an HTTPS release base URL and reject localhost, `127.0.0.1`, preview-only temporary URLs, or empty release config.

- [ ] **Step 2: Update `miniprogram/config.js`**

Set only the verified production HTTPS API base URL. No database/provider secret enters the Mini Program.

- [ ] **Step 3: Run final automated verification**

```bash
pytest -q
python -m compileall -q .
find miniprogram -name '*.js' -print0 | xargs -0 -n1 node --check
```

Run the PostgreSQL contract/acceptance subset once more against Neon main or a fresh disposable branch with the same schema, and run a production public smoke test.

- [ ] **Step 4: Final requirements audit**

Explicitly verify:

```text
SQLite local still works
PostgreSQL cloud persists data
production cannot fallback to SQLite
no Demo production seed
no raw upload persistence
file/image confirmation independent from raw bytes
R1 contracts evidenced on PostgreSQL
tenant isolation evidenced
secrets absent from source and responses
public HTTPS health/API evidenced
WeChat DevTools/real-device Gate still marked PENDING if not executed
```

- [ ] **Step 5: Package cloud RC**

Create the clean ZIP without `.env`, local DB files, caches, test upload artifacts, or secrets. Generate SHA-256 and final Gate.

---

## Execution Checkpoints

Execution must stop for user approval at these points even if every test is green:

1. **Neon migration temporary branch Gate:** before applying initial schema to Neon main.
2. **Vercel secret configuration blocker:** if the connected deployment tool cannot securely set required environment variables, request the one-time external configuration instead of embedding secrets.
3. **Mini release URL Gate:** do not change `miniprogram/config.js` until public PostgreSQL acceptance passes.
4. **WeChat final Gate:** automated cloud RC is not equivalent to WeChat release PASS; DevTools/real-device validation remains separate.

## Definition of Done

Cloud migration is complete only when all of the following have fresh evidence:

- The original RC ZIP is unchanged.
- Local SQLite full regression is green after the refactor.
- PostgreSQL contract tests pass on a real Neon branch.
- Neon main contains schema/system seed but no Demo/test business data before first real use.
- A Vercel production HTTPS deployment reads/writes Neon successfully across fresh HTTP sessions/instances.
- File/image confirmation no longer needs persisted raw uploads.
- Production auth/secrets fail closed.
- Tenant isolation tests pass.
- Mini release config points only to the verified production HTTPS API.
- Final cloud RC ZIP and SHA-256 are produced.
- WeChat DevTools/real-device status is reported accurately as PASS or PENDING, never inferred from backend tests.
