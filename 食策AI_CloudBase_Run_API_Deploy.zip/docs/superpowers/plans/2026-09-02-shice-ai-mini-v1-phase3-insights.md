# 食策AI Mini V1 Phase 3 — Today, Trends, Anomaly & Reconciliation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 交付老板首页一次聚合查询、7日简要趋势、可信的 Top 3 异常和简化对账表达。

**Architecture:** 先由结构化服务计算，再由 Today Aggregator 组合；前端不拼多个财务口径。异常使用规则评分且把 severity 与 confidence 分离，对账继续复用 R1 reconciliation，不把“暂未对上”说成平台少打款。

**Tech Stack:** Python, FastAPI, SQLite, Decimal, pytest.

**Spec:** `docs/superpowers/specs/2026-09-02-shice-ai-mini-v1-design.md`

## Global Constraints
- `/api/mini/v1/today` 是首页唯一聚合入口。
- 首页最多返回 3 个 `top_issues`。
- 数据未齐时必须返回 `as_of` 与 completeness 状态。
- 低可信数据不能生成确定性警报。
- 对账结论只来自现有 settlement/payment/reconciliation 证据。

---

### Task 1: Anomaly schema and baseline service

**Files:**
- Modify: `db_v3.py`
- Create: `repositories/insight_repository.py`
- Create: `services/baseline_service.py`
- Test: `tests/test_baseline_service.py`

**Interfaces:**
- Table: `anomaly_events`
- `BaselineService.get(metric_code, store_id, business_date) -> Baseline`

- [ ] **Step 1: Write failing baseline-priority tests**

```python
def test_store_30d_baseline_beats_industry_when_enough_history(v3_db):
    seed_metric_history(v3_db, days=30, metric="AOV")
    seed_approved_benchmark(v3_db, metric="AOV")
    b = BaselineService(v3_db).get("AOV", 1, "2026-09-02")
    assert b.source in {"STORE_7D", "STORE_14D", "STORE_30D"}
```

- [ ] **Step 2: Implement baseline order**

```text
STORE_7D (enough comparable days) → STORE_14D → STORE_30D → LOCAL_CATEGORY → NATIONAL_CATEGORY
```

History uses median/robust range rather than a single raw prior day; minimum sample sizes are versioned.

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_baseline_service.py -q
```

---

### Task 2: Anomaly Engine and Top-3 prioritization

**Files:**
- Create: `services/anomaly_engine.py`
- Create: `mini/issue_routes.py`
- Test: `tests/test_anomaly_engine.py`

**Interfaces:**
- `AnomalyEngine.detect(store_id, business_date) -> list[Anomaly]`
- `AnomalyEngine.top_issues(store_id: int, business_date: str, limit: int = 3) -> list[Anomaly]`
- Endpoints: `GET /issues/today`, `GET /issues/<built-in function id>`

- [ ] **Step 1: Write failing ranking tests**

```python
def test_top_issues_never_returns_more_than_three(v3_db):
    issues = AnomalyEngine(v3_db).top_issues(1, "2026-09-02")
    assert len(issues) <= 3


def test_high_severity_low_confidence_does_not_outrank_reliable_cash_difference(v3_db):
    seed_anomaly_inputs(v3_db)
    top = AnomalyEngine(v3_db).top_issues(1, "2026-09-02")
    assert top[0].anomaly_type == "RECONCILIATION_DIFFERENCE"
```

- [ ] **Step 2: Implement `Priority Score` components explicitly**

Use normalized discrete factors, not a black-box model:

```text
impact 1..5 × severity 1..5 × confidence 0.25/0.5/0.75/1.0 × persistence 1..3 × actionability 1..3
```

Add deduplication by root-cause group so three variants of the same issue cannot fill all slots.

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_anomaly_engine.py -q
```

---

### Task 3: Simplified reconciliation service

**Files:**
- Create: `services/reconciliation_summary.py`
- Create: `mini/reconciliation_routes.py`
- Test: `tests/test_reconciliation_summary.py`

**Interfaces:**
- `ReconciliationSummaryService.today(store_id, business_date) -> ReconciliationSummary`
- Endpoints: `GET /reconciliation/today`, `GET /reconciliation/<built-in function id>`

- [ ] **Step 1: Write evidence-language tests**

```python
def test_unmatched_is_worded_as_not_reconciled_not_platform_underpayment(v3_db):
    summary = service.today(1, "2026-09-02")
    assert summary.status == "DIFFERENCE"
    assert "没对上" in summary.user_message
    assert "少给" not in summary.user_message
```

- [ ] **Step 2: Implement three headline states**

```text
OK → 暂时没发现问题
DIFFERENCE → 还有 ¥X 暂时没对上
INSUFFICIENT_DATA → 还缺平台结算/到账数据
```

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_reconciliation_summary.py tests/test_calculation_reconciliation_v2.py -q
```

---

### Task 4: 7-day trend service

**Files:**
- Create: `services/trend_service.py`
- Create: `mini/trend_routes.py`
- Test: `tests/test_trend_service.py`

**Interfaces:**
- `TrendService.get(store_id, end_date, days=7) -> TrendSummary`
- `GET /api/mini/v1/trends?days=7`

- [ ] **Step 1: Write failing tests for missing days and percentage safety**

```python
def test_trend_does_not_invent_zero_for_missing_day(v3_db):
    seed_sales(v3_db, dates=["2026-09-01", "2026-09-02"])
    trend = TrendService(v3_db).get(1, "2026-09-02", 7)
    assert trend.observed_days == 2
    assert trend.missing_days == 5
```

- [ ] **Step 2: Implement concise trend metrics**

V1 exposes sales, AOV when order_count is available, profit status/range, and one most notable issue. No fake percentage when comparison denominator is zero or sample is insufficient.

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_trend_service.py -q
```

---

### Task 5: Today Aggregator and single-call API

**Files:**
- Create: `services/today_aggregator.py`
- Create: `mini/today_routes.py`
- Modify: `mini/routes.py`
- Test: `tests/test_today_api.py`

**Interfaces:**
- `TodayAggregator.build(store_id, business_date, now) -> TodayResponse`
- `GET /api/mini/v1/today`

- [ ] **Step 1: Write failing homepage contract test**

```python
def test_today_response_contains_only_aggregated_home_contract(client, auth_headers):
    r = client.get("/api/mini/v1/today?date=2026-09-02", headers=auth_headers)
    body = r.json()
    assert {"date","as_of","sales","profit","data_status","top_issues",
            "reconciliation","pending_actions","yesterday_verification"} <= body.keys()
    assert len(body["top_issues"]) <= 3
```

- [ ] **Step 2: Implement aggregator without duplicating business logic**

Aggregator calls RevenueResolver, ProfitEngine, CompletenessService, AnomalyEngine, ReconciliationSummaryService and ActionRepository; it does not recalculate finance itself.

- [ ] **Step 3: Run Phase-3 + full regression**

```bash
python -m pytest tests/test_baseline_service.py tests/test_anomaly_engine.py tests/test_reconciliation_summary.py tests/test_trend_service.py tests/test_today_api.py -q
python -m pytest -q
```

- [ ] **Step 4: Phase-3 Gate report**

Create `docs/superpowers/gates/2026-09-02-mini-v1-phase3-gate.md` with fixture-backed homepage examples for complete and incomplete days.
