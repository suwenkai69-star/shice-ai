# 食策AI Mini V1 Phase 1 — Core Foundation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 建立 Mini V1 的 Schema V3、repository 边界、微信认证/单店绑定、收入覆盖语义，以及可审计的成本/Benchmark/利润区间引擎。

**Architecture:** 新建 `db.py` 作为迁移编排器，保留 `db_v2.py` 的 V2 兼容职责；Mini 新能力写入独立 package，不把逻辑继续堆进 `app.py`。Revenue Resolver 先解决整店总额与渠道数据重叠，再由 Profit Engine 按真实数据→本店历史→当地/行业基准的优先级计算经营利润区间。

**Tech Stack:** Python, FastAPI, SQLite, Decimal, pytest, Pydantic.

**Spec:** `docs/superpowers/specs/2026-09-02-shice-ai-mini-v1-design.md`

## Global Constraints

- 不修改 R1 已确认的 V2 财务语义。
- Schema V3 必须能从 V2 原地升级，失败时事务回滚。
- `db_v2.migrate_database()` 继续只负责到 V2；新 `db.migrate_database()` 编排 V2→V3。
- V3 追加 `TAOBAO_FLASH` 渠道但保留 `MEITUAN_FLASH`；不得通过重命名破坏历史渠道。
- `category_code` 固定为 `MILK_TEA / COFFEE / FAST_FOOD_SNACK / CHINESE_DINING / HOTPOT / BBQ / BAKERY_DESSERT / BAR_LEISURE / OTHER_FOOD`。
- 任何业务查询必须带 `store_id`；前端单店不等于后端省略隔离键。
- 没有真实营业额时 Profit Engine 必须返回 `UNAVAILABLE`。
- Benchmark 必须有来源、日期、区域与审核状态；未审核记录不得参与估算。
- 结算周期费用不按单日伪分摊。

---

### Task 1: Schema V3 migration orchestrator and core tables

**Files:**
- Create: `db.py`
- Create: `db_v3.py`
- Modify: `app.py:1-75`
- Test: `tests/test_schema_v3.py`

**Interfaces:**
- Produces: `db.migrate_database(db_path: str | Path) -> int`
- Produces: `db_v3.migrate_v2_to_v3(db_path: str | Path, fail_after_statement: int | None = None) -> int`
- Consumes: `db_v2.get_schema_version`, `db_v2.migrate_database`

- [ ] **Step 1: Write failing migration tests**

```python
from tests.test_schema_v2 import create_v04_db


def test_v2_database_migrates_to_schema_v3(tmp_path):
    from db_v2 import migrate_database as migrate_v2
    from db import migrate_database
    db = tmp_path / "mini.db"
    create_v04_db(db)
    assert migrate_v2(db) == 2
    assert migrate_database(db) == 3
    required = {
        "mini_users", "store_profiles", "daily_store_sales_totals",
        "store_cost_profiles", "cost_entries", "industry_benchmarks",
        "profit_snapshots",
    }
    with sqlite3.connect(db) as con:
        names = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert required.issubset(names)


def test_v3_migration_rolls_back_on_injected_failure(tmp_path):
    from db_v2 import migrate_database as migrate_v2
    from db_v3 import migrate_v2_to_v3
    db = tmp_path / "mini.db"
    create_v04_db(db)
    migrate_v2(db)
    with pytest.raises(RuntimeError, match="injected v3 migration failure"):
        migrate_v2_to_v3(db, fail_after_statement=4)
    assert get_schema_version(db) == 2
```

- [ ] **Step 2: Run the targeted tests and verify failure**

```bash
python -m pytest tests/test_schema_v3.py -q
```

Expected: FAIL because `db.py`, `db_v3.py`, and V3 tables do not exist.

- [ ] **Step 3: Implement V3 migration with explicit tables and checks**

`db.py` must expose only the orchestrator:

```python
def migrate_database(db_path):
    version = get_schema_version(db_path)
    if version < 2:
        migrate_v2(db_path)
        version = get_schema_version(db_path)
    if version == 2:
        return migrate_v2_to_v3(db_path)
    if version == 3:
        return 3
    raise RuntimeError(f"database has newer schema version {version}; refusing downgrade to 3")
```

`db_v3.py` creates the exact Phase-1 tables with foreign keys to `stores(id)`, `schema_meta.schema_version=3`, millisecond timestamps, seeds `TAOBAO_FLASH / 淘宝闪购 / DELIVERY` with `INSERT OR IGNORE`, and applies these minimum uniqueness rules:

```sql
UNIQUE(wechat_openid)
UNIQUE(store_id)
UNIQUE(store_id, business_date)              -- daily_store_sales_totals
UNIQUE(category_code, region_level, region_code, metric_code, valid_from)
```

`industry_benchmarks` must include `review_status TEXT CHECK(review_status IN ('DRAFT','APPROVED','REJECTED'))`.

- [ ] **Step 4: Switch app startup to the orchestrator**

In `app.py`, replace `from db_v2 import migrate_database` with `from db import migrate_database`; do not change V2 endpoint behavior.

- [ ] **Step 5: Update the additive-channel API expectation and run migration + full R1 regression**

`tests/test_api_v2.py` must stop asserting an exact channel count of 9 after application-level V3 migration. Assert that the original 9 R1 codes remain present and `TAOBAO_FLASH` is additionally present. `tests/test_schema_v2.py` continues to test pure V2 migration in isolation and still expects the original 9 channels.

```bash
python -m pytest tests/test_schema_v3.py tests/test_schema_v2.py tests/test_data_integrity_r1.py tests/test_api_v2.py -q
```

Expected: all PASS; no original channel code is removed or renamed.

- [ ] **Step 6: Checkpoint**

```bash
git status --short 2>/dev/null || true
```

If running in the canonical Git repository:

```bash
git add db.py db_v3.py app.py tests/test_schema_v3.py
git commit -m "feat: add mini schema v3 foundation"
```

Do not initialize Git in an extracted delivery snapshot.

---

### Task 2: Repository boundary and store isolation

**Files:**
- Create: `repositories/__init__.py`
- Create: `repositories/mini_store_repository.py`
- Create: `repositories/mini_sales_repository.py`
- Create: `repositories/mini_cost_repository.py`
- Test: `tests/test_mini_repositories.py`

**Interfaces:**
- Produces: `MiniStoreRepository(db_path)`
- Produces: `MiniSalesRepository(db_path)`
- Produces: `MiniCostRepository(db_path)`
- Every read/write method consumes an explicit `store_id: int` unless it resolves ownership by `user_id`.

- [ ] **Step 1: Write failing isolation tests**

```python
def test_sales_repository_never_crosses_store_boundary(v3_db):
    repo = MiniSalesRepository(v3_db)
    repo.upsert_store_total(1, "2026-09-02", "1000.00", "ACTUAL", "MANUAL")
    repo.upsert_store_total(2, "2026-09-02", "2000.00", "ACTUAL", "MANUAL")
    assert repo.get_store_total(1, "2026-09-02")["gross_sales"] == "1000.00"
    assert repo.get_store_total(2, "2026-09-02")["gross_sales"] == "2000.00"
```

- [ ] **Step 2: Run and verify failure**

```bash
python -m pytest tests/test_mini_repositories.py -q
```

- [ ] **Step 3: Implement focused repository methods**

Required signatures (implement these exact names and types):

- `MiniStoreRepository.create_or_get_user(openid: str, unionid: str | None = None) -> dict`
- `MiniStoreRepository.bind_store(user_id: int, store_id: int) -> None`
- `MiniStoreRepository.get_current_store(user_id: int) -> dict | None`
- `MiniStoreRepository.create_store(user_id: int, name: str, category_code: str) -> dict`
- `MiniSalesRepository.upsert_store_total(store_id: int, business_date: str, gross_sales: str, source_kind: str, source_ref: str | None) -> dict`
- `MiniSalesRepository.get_store_total(store_id: int, business_date: str) -> dict | None`
- `MiniSalesRepository.list_channel_sales(store_id: int, business_date: str) -> list[dict]`
- `MiniCostRepository.get_profile(store_id: int) -> dict | None`
- `MiniCostRepository.save_profile(store_id: int, values: dict) -> dict`
- `MiniCostRepository.list_cost_entries(store_id: int, start: str, end: str) -> list[dict]`
- `MiniCostRepository.list_approved_benchmarks(category_code: str, metric_code: str, region_codes: list[str]) -> list[dict]`

- [ ] **Step 4: Run repository tests**

```bash
python -m pytest tests/test_mini_repositories.py -q
```

Expected: PASS.

- [ ] **Step 5: Checkpoint / commit if Git exists**

```bash
git add repositories tests/test_mini_repositories.py && git commit -m "feat: add mini repositories"
```

---

### Task 3: Mini auth provider, token service, and single-store onboarding API

**Files:**
- Create: `mini/__init__.py`
- Create: `mini/auth.py`
- Create: `mini/models.py`
- Create: `mini/routes.py`
- Modify: `app.py:20-45,229-240`
- Modify: `requirements.txt`
- Test: `tests/test_mini_auth_api.py`

**Interfaces:**
- Produces: `AuthProvider.exchange_code(code: str) -> WechatIdentity`
- Produces: `TokenService.issue(user_id: int) -> str`
- Produces: `TokenService.verify(token: str) -> int`
- Produces endpoints: `POST /api/mini/v1/auth/wechat`, `POST/GET/PATCH /api/mini/v1/store`

- [ ] **Step 1: Write failing API tests using an injected fake provider**

```python
def test_wechat_login_and_store_onboarding(client, monkeypatch):
    monkeypatch.setattr("mini.auth.get_auth_provider", lambda: FakeAuthProvider("openid-1"))
    login = client.post("/api/mini/v1/auth/wechat", json={"code": "wx-code"})
    token = login.json()["token"]
    created = client.post(
        "/api/mini/v1/store",
        headers={"Authorization": f"Bearer {token}"},
        json={"name": "老王奶茶", "category_code": "MILK_TEA"},
    )
    assert created.status_code == 200
    assert created.json()["store"]["name"] == "老王奶茶"
```

Also test: invalid/missing token → 401; user A cannot read user B store.

- [ ] **Step 2: Run and verify failure**

```bash
python -m pytest tests/test_mini_auth_api.py -q
```

- [ ] **Step 3: Implement authentication contracts**

Use signed HMAC tokens with `MINI_TOKEN_SECRET` and timestamped payload; do not store WeChat `session_key` in API responses. `AuthProvider` has two explicit implementations:

```python
class DevAuthProvider(AuthProvider):
    def exchange_code(self, code: str) -> WechatIdentity:
        if not code.startswith("dev-"):
            raise AuthError("invalid dev code")
        return WechatIdentity(openid=f"dev:{code}", unionid=None)

class WechatAuthProvider(AuthProvider):
    def exchange_code(self, code: str) -> WechatIdentity:
        response = self.client.get(self.endpoint, params={
            "appid": self.appid, "secret": self.secret, "js_code": code,
            "grant_type": "authorization_code",
        })
        payload = response.json()
        if response.status_code != 200 or payload.get("errcode"):
            raise AuthError(payload.get("errmsg") or "wechat code exchange failed")
        return WechatIdentity(openid=payload["openid"], unionid=payload.get("unionid"))
```

Add `httpx>=0.27` to `requirements.txt` for the WeChat server exchange.

- [ ] **Step 4: Mount the Mini router without moving legacy endpoints**

```python
from mini.routes import router as mini_router
app.include_router(mini_router, prefix="/api/mini/v1")
```

- [ ] **Step 5: Run auth/API + legacy regression**

```bash
python -m pytest tests/test_mini_auth_api.py tests/test_api_v2.py tests/test_v04_regression.py -q
```

Expected: PASS.

- [ ] **Step 6: Checkpoint / commit if Git exists**

```bash
git add mini repositories app.py requirements.txt tests/test_mini_auth_api.py && git commit -m "feat: add mini auth and onboarding"
```

---

### Task 4: Revenue Resolver and whole-store/channel overlap semantics

**Files:**
- Create: `services/__init__.py`
- Create: `services/revenue_resolver.py`
- Test: `tests/test_revenue_resolver.py`

**Interfaces:**
- Produces: `RevenueResolver.resolve(store_id: int, business_date: str) -> RevenueResult`
- `RevenueResult` fields: `amount: Decimal | None`, `source: str`, `coverage: str`, `warnings: list[str]`

- [ ] **Step 1: Write failing coverage tests**

```python
def test_whole_store_total_wins_over_overlapping_payment_channels(v3_db):
    # POS/整店总额 1000，微信 600 + 支付宝 400 只是支付拆分，不能得到 2000。
    seed_store_total(v3_db, 1, "2026-09-02", "1000.00")
    seed_channel_sale(v3_db, 1, "2026-09-02", "WECHAT_PAY", "600.00")
    seed_channel_sale(v3_db, 1, "2026-09-02", "ALIPAY", "400.00")
    result = RevenueResolver(v3_db).resolve(1, "2026-09-02")
    assert result.amount == Decimal("1000.00")
    assert result.coverage == "WHOLE_STORE_TOTAL"


def test_channel_sum_is_used_when_no_whole_store_total(v3_db):
    seed_channel_sale(v3_db, 1, "2026-09-02", "MEITUAN_DELIVERY", "700.00")
    seed_channel_sale(v3_db, 1, "2026-09-02", "DOUYIN_LOCAL", "300.00")
    assert RevenueResolver(v3_db).resolve(1, "2026-09-02").amount == Decimal("1000.00")
```

- [ ] **Step 2: Run and verify failure**

```bash
python -m pytest tests/test_revenue_resolver.py -q
```

- [ ] **Step 3: Implement deterministic resolver rules**

Rules in order:

```text
1. Confirmed whole-store total exists → use it as total revenue.
2. Otherwise sum non-overlapping sales channels.
3. Payment channels WECHAT_PAY/ALIPAY/CASH are not automatically added on top of a confirmed whole-store total.
4. If coverage metadata is ambiguous, return warning and do not silently add both scopes.
```

The resolver must not use settlement/payment amounts as sales revenue.

- [ ] **Step 4: Run targeted + V2 calculation tests**

```bash
python -m pytest tests/test_revenue_resolver.py tests/test_calculation_reconciliation_v2.py -q
```

- [ ] **Step 5: Checkpoint / commit if Git exists**

```bash
git add services/revenue_resolver.py tests/test_revenue_resolver.py && git commit -m "feat: resolve whole-store revenue safely"
```

---

### Task 5: Benchmark repository, approval gate, and auditable seed format

**Files:**
- Create: `services/benchmark_service.py`
- Create: `data/benchmarks/benchmark_seed.schema.json`
- Create: `data/benchmarks/benchmark_seed.json`
- Test: `tests/test_benchmark_service.py`

**Interfaces:**
- Produces: `BenchmarkService.find_range(category_code, metric_code, city_code=None) -> BenchmarkRange | None`
- `BenchmarkRange`: `low: Decimal`, `mid: Decimal`, `high: Decimal`, `source_name`, `source_url`, `source_date`, `confidence_level`, `benchmark_id`

- [ ] **Step 1: Write failing gate tests**

```python
def test_unapproved_benchmark_is_never_used(v3_db):
    insert_benchmark(v3_db, review_status="DRAFT", metric_code="FOOD_COST_RATE")
    assert BenchmarkService(v3_db).find_range("MILK_TEA", "FOOD_COST_RATE", "URUMQI") is None


def test_local_approved_benchmark_beats_national(v3_db):
    insert_benchmark(v3_db, region_level="COUNTRY", region_code="CN", low="0.35", high="0.45", review_status="APPROVED")
    insert_benchmark(v3_db, region_level="CITY", region_code="URUMQI", low="0.38", high="0.42", review_status="APPROVED")
    result = BenchmarkService(v3_db).find_range("MILK_TEA", "FOOD_COST_RATE", "URUMQI")
    assert result.low == Decimal("0.38")
```

- [ ] **Step 2: Run and verify failure**

```bash
python -m pytest tests/test_benchmark_service.py -q
```

- [ ] **Step 3: Implement benchmark priority and seed validation**

Priority:

```text
APPROVED city → APPROVED province → APPROVED country → None
```

Seed JSON exact record shape:

```json
{
  "category_code": "MILK_TEA",
  "region_level": "COUNTRY",
  "region_code": "CN",
  "metric_code": "FOOD_COST_RATE",
  "low_value": "0.38",
  "mid_value": "0.42",
  "high_value": "0.45",
  "unit": "RATE",
  "source_name": "source title",
  "source_url": "https://example.org/research-source",
  "source_date": "2026-01-01",
  "confidence_level": "MEDIUM",
  "review_status": "APPROVED",
  "valid_from": "2026-01-01"
}
```

Production import rejects records without source URL/date or with `review_status != APPROVED`.

- [ ] **Step 4: Populate the first production seed only from reviewed sources**

Research output must cover the V1 category codes that have defensible public data. For any category/metric without a defensible source, omit the benchmark rather than inventing a number; Profit Engine will expose the missing input. The seed file must include source metadata for every row and no uncited magic numbers.

- [ ] **Step 5: Run benchmark tests and JSON validation**

```bash
python -m pytest tests/test_benchmark_service.py -q
python -m json.tool data/benchmarks/benchmark_seed.json >/dev/null
```

- [ ] **Step 6: Checkpoint / commit if Git exists**

```bash
git add services/benchmark_service.py data/benchmarks tests/test_benchmark_service.py && git commit -m "feat: add audited benchmark service"
```

---

### Task 6: Cost profile and Profit Engine

**Files:**
- Create: `services/cost_resolver.py`
- Create: `services/profit_engine.py`
- Create: `mini/profit_routes.py`
- Modify: `mini/routes.py`
- Test: `tests/test_profit_engine.py`
- Test: `tests/test_mini_profit_api.py`

**Interfaces:**
- Produces: `CostResolver.resolve(store_id, business_date, cost_type) -> CostRange`
- Produces: `ProfitEngine.calculate(store_id, business_date) -> ProfitResult`
- Endpoints: `GET /profit/today`, `GET /profit/profile`, `PATCH /profit/profile`

- [ ] **Step 1: Write failing profit tests**

```python
def test_profit_unavailable_without_real_revenue(v3_db):
    result = ProfitEngine(v3_db).calculate(1, "2026-09-02")
    assert result.status == "UNAVAILABLE"
    assert "营业额" in result.missing_data


def test_profit_returns_range_when_some_costs_are_benchmarks(v3_db):
    seed_store_total(v3_db, 1, "2026-09-02", "10000.00")
    seed_actual_cost(v3_db, 1, "2026-09-02", "MARKETING", "500.00")
    seed_approved_rate_benchmark(v3_db, "MILK_TEA", "FOOD_COST_RATE", "0.38", "0.45")
    result = ProfitEngine(v3_db).calculate(1, "2026-09-02")
    assert result.status == "ESTIMATED_RANGE"
    assert result.profit_low < result.profit_high
    assert any(x.source == "INDUSTRY_BENCHMARK" for x in result.components)
```

Also test actual costs override benchmark, store history overrides industry when enough valid history exists, and weekly settlement fee with `business_date=NULL` is not assigned to today.

- [ ] **Step 2: Run and verify failure**

```bash
python -m pytest tests/test_profit_engine.py tests/test_mini_profit_api.py -q
```

- [ ] **Step 3: Implement cost-source priority**

For each cost type, use:

```text
ACTUAL → STORE_HISTORY → LOCAL_BENCHMARK → INDUSTRY_BENCHMARK → UNKNOWN
```

Special rules:
- Food: actual consumed-cost entry or user cost-rate profile; purchase amount alone is not automatically consumption cost.
- Labor: actual monthly labor, otherwise city/category benchmark × full-time count + hourly benchmark × part-time hours.
- Rent: actual monthly rent allocated by configured operating-day rule; otherwise approved rent-to-sales benchmark.
- Platform: use daily attributable actual fees only; settlement-period fee without day attribution stays outside today profit.
- Owner labor: tracked separately and not forced into headline operating profit.

- [ ] **Step 4: Implement ProfitResult with explicit provenance**

```python
@dataclass(frozen=True)
class ProfitComponent:
    code: str
    low: Decimal
    high: Decimal
    source: str
    source_ref: str | None

@dataclass(frozen=True)
class ProfitResult:
    status: Literal["ACTUAL_BASED", "ESTIMATED_RANGE", "UNAVAILABLE"]
    revenue: Decimal | None
    profit_low: Decimal | None
    profit_high: Decimal | None
    components: Sequence[ProfitComponent]
    missing_data: Sequence[str]
```

- [ ] **Step 5: Expose plain-language Mini Profit API**

Response must contain canonical numeric strings and user-facing source labels, e.g. `实际数据 / 根据本店历史估算 / 根据同类店参考 / 暂时没有数据`.

- [ ] **Step 6: Run full Phase-1 tests**

```bash
python -m pytest tests/test_schema_v3.py tests/test_mini_repositories.py tests/test_mini_auth_api.py tests/test_revenue_resolver.py tests/test_benchmark_service.py tests/test_profit_engine.py tests/test_mini_profit_api.py -q
python -m pytest -q
```

Expected: all PASS.

- [ ] **Step 7: Phase-1 Gate report**

Create `docs/superpowers/gates/2026-09-02-mini-v1-phase1-gate.md` containing exact test counts, migration smoke result, and unresolved external dependencies. Do not mark browser/OCR/UI work as PASS because it is not in Phase 1.

- [ ] **Step 8: Checkpoint / commit if Git exists**

```bash
git add services mini repositories tests data/benchmarks docs/superpowers/gates requirements.txt && git commit -m "feat: complete mini v1 core foundation"
```
