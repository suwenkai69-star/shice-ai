# 食策AI V0.5.0-R1 Data Integrity Fix Implementation Plan

> **For agentic workers:** Execute task-by-task with test-first verification.

**Goal:** 修复 V0.5.0 Data Foundation 已确认的数据完整性、备份/恢复、渠道一致性、输入兼容和最小版本信息问题，不增加 V0.5.1 功能。

**Architecture:** 保留 FastAPI + SQLite + 现有静态前端。修复集中在 `data_foundation.py` 的导入/计算/追溯逻辑、`db_v2.py` 的迁移备份、`app.py` 的状态同步与全量备份/重置/恢复；前端只做版本信息、底部门店演示卡和服务端备份/恢复入口的最小校正。

**Tech Stack:** Python 3.13, FastAPI, SQLite, pytest, vanilla HTML/JS.

## Global Constraints
- 不做 UI 大改。
- 不重构 AI。
- 不碰税务、BOM、库存、平台 API、RPA。
- V0.4 旧接口和 localStorage fallback 必须保留。
- 可计算财务金额继续使用 Decimal。

### Task 1: Import safety and parser compatibility
**Files:** `data_foundation.py`, `tests/test_data_integrity_r1.py`
- [x] 写失败测试：partial update、空文件、坏 JSON、GB18030、非补零日期、渠道冲突。
- [ ] 导入入口先建立可审计 batch，再解析文件；解析失败/0 行为 FAILED。
- [ ] CSV 支持 UTF-8 BOM / UTF-8 / GB18030；日期标准化常见年月日格式。
- [ ] API 指定渠道与文件渠道冲突时拒绝该行。
- [ ] partial update 只覆盖明确提供且非空的字段。

### Task 2: Settlement fee and calculation semantics
**Files:** `data_foundation.py`, `tests/test_data_integrity_r1.py`
- [x] 写失败测试：费用 business_date 不伪造、partial settlement 不清空费用、channel net revenue 与 settlement 分离。
- [ ] 结算级费用默认 `business_date=NULL`。
- [ ] partial settlement 更新费用采用 merge，不删除未提供费用。
- [ ] `calculate_channel_net_revenue` 使用独立 revenue profile，不再调用 settlement calculator。

### Task 3: Reconciliation channel safety
**Files:** `data_foundation.py`, `tests/test_data_integrity_r1.py`
- [x] 写失败测试：跨渠道手工匹配必须拒绝。
- [ ] 匹配同时验证 store 和 channel。

### Task 4: Migration backup freshness and store-type sync
**Files:** `db_v2.py`, `app.py`, `tests/test_data_integrity_r1.py`
- [x] 写失败测试：stale canonical backup、type/store_type 同步。
- [ ] V0.4→V2 每次真正迁移前刷新 canonical backup，并生成 timestamped backup。
- [ ] `save_state()` 同步写 `type` 和 `store_type`。

### Task 5: Full backup/reset/restore consistency
**Files:** `data_foundation.py`, `app.py`, `static/index.html`, `tests/test_data_integrity_r1.py`
- [x] 写失败测试：server backup 包含 V2；reset 清 V2；restore 可恢复。
- [ ] 增加 per-store 全量 JSON snapshot/restore/reset helper。
- [ ] `/api/backup` 输出 full backup；新增 `/api/restore`；`/api/reset` 清理 legacy + V2 operational data。
- [ ] 前端 server mode 使用后端 full backup/restore；local mode 保留原有 localStorage 备份。

### Task 6: Minimal static metadata correction
**Files:** `static/index.html`, `tests/test_data_integrity_r1.py`
- [x] 写失败测试：V0.5.0-R1 标识、无底部演示门店卡。
- [ ] 仅更新版本文案和报告说明；删除底部 store card；JS 对相关 DOM 改为安全可选。

### Task 7: Full regression and delivery verification
- [ ] 运行 R1 专项测试。
- [ ] 运行完整 pytest。
- [ ] 对真实 V0.4 备份副本做 migration smoke test。
- [ ] 启动 FastAPI smoke test：health/state/v2/backup/reset/restore。
- [ ] 更新 Gate Review，重新生成 SHA256 manifest 和 ZIP。
