# 食策AI Mini V1 Implementation Roadmap

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement each phase plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在不重写 V0.5.0-R1 Data Foundation 的前提下，交付一个原生微信小程序老板版，跑通“上传 → 经营判断 → Top 3 问题 → 行动 → 提醒 → 次日验证”的单店闭环。

**Architecture:** 现有 FastAPI + SQLite Data Foundation 继续作为可信财务底座；新增 Schema V3、Mini API Facade、独立业务服务与原生微信小程序。复杂财务计算和数据可信度判断由规则/服务层完成，AI 只做解释、建议和文字材料生成。

**Tech Stack:** Python 3.13+ compatible code, FastAPI, SQLite, pytest, Pydantic, openpyxl, native WeChat Mini Program (WXML/WXSS/JavaScript), WeChat subscription messages, pluggable recognition provider.

**Spec:** `docs/superpowers/specs/2026-09-02-shice-ai-mini-v1-design.md`

## Global Constraints

- V0.5.0-R1 的 `daily_channel_sales / settlements / platform_fees / payments / reconciliation_matches / import_*` 语义与追溯链必须保留。
- V3 只以 additive 方式新增 `TAOBAO_FLASH`，保留原有 `MEITUAN_FLASH` 和其历史数据。
- 财务金额继续使用 `Decimal`；SQLite 中规范化金额继续保存为 canonical decimal text。
- AI/OCR 识别结果不得直接写正式经营事实，必须经过 Draft → Confirm → Import。
- 没有真实营业额不得输出经营利润。
- 成本估算必须保存来源与区间；未通过 Benchmark Gate 的基准不得参与生产计算。
- 周期结算费用不得伪造成某一天实际费用。
- 整店销售总额与渠道销售不得静默重复相加。
- 不确定是否安全合并的数据更正继续 fail closed。
- 首页最多 3 个重点问题，最多 3 个重点行动。
- 小程序前台为单店体验，正式业务数据仍保留 `store_id`。
- V1 不做平台 API/RPA、自动调价/发券/关活动、图片生成、BOM、库存、税务、发票、多门店前端、复杂权限、PostgreSQL 迁移。
- 当前交付源代码快照没有 `.git`；执行时不得为了满足流程而伪造 Git 历史。如在真实 Git 仓库执行，则按各任务 Commit 步骤提交；否则保留测试输出与打包 SHA256 作为 checkpoint。

---

## Why this is split into phase plans

设计规格覆盖 Schema、认证、利润、上传、OCR、异常、行动、提醒、AI 与原生小程序多个独立子系统。为避免一个超大计划失去可审查性，实施拆成 5 个有明确依赖关系、每个都能独立验收的阶段。

| Phase | Plan | 独立交付物 | 依赖 |
|---|---|---|---|
| 1 | `2026-09-02-shice-ai-mini-v1-phase1-core.md` | Schema V3 + Repository + Auth/Store + Revenue Resolver + Cost/Benchmark/Profit | R1 |
| 2 | `2026-09-02-shice-ai-mini-v1-phase2-ingestion.md` | 手填/CSV/XLSX + OCR Draft/Confirm + 防重复 + 数据完整度 | Phase 1 |
| 3 | `2026-09-02-shice-ai-mini-v1-phase3-insights.md` | Today 聚合 + 7日趋势 + Top 3 异常 + 简化对账 | Phase 1–2 |
| 4 | `2026-09-02-shice-ai-mini-v1-phase4-actions-ai.md` | 行动/执行/验证 + 订阅提醒 + AI Context + 文字执行材料 | Phase 3 |
| 5 | `2026-09-02-shice-ai-mini-v1-phase5-miniprogram-e2e.md` | 原生微信小程序页面 + API 接入 + Demo + E2E/真机试点 Gate | Phase 1–4 |

## Phase gates

- [ ] **Gate 1 — Core correctness:** Schema V2→V3 原地升级、R1 回归全绿；利润无真实营业额时为 UNAVAILABLE；整店/渠道收入无重复计算。
- [ ] **Gate 2 — Ingestion trust:** 任意图片/文件先草稿确认；同日累计更新不会双算；坏文件有可审计失败记录；完整度可自动学习并允许人工结束等待。
- [ ] **Gate 3 — Insight usefulness:** `/api/mini/v1/today` 一次返回老板首页需要的内容；异常最多 3 条；低可信异常不能伪装成确定事实；对账无证据不归责平台。
- [ ] **Gate 4 — Closed loop:** 建议可执行/跳过/提醒；次日返回 IMPROVED / NO_CLEAR_CHANGE / WORSENED / INSUFFICIENT_DATA；AI 数据不足时明确提示缺失项。
- [ ] **Gate 5 — Mini V1 acceptance:** 新用户从微信进入到截图确认、利润区间、Top 3、执行、提醒、次日验证的完整场景可在 DevTools + 真机试点跑通。

## Spec coverage map

- 微信登录、单店、Demo、4 Tab → Phase 1 + Phase 5
- 截图/文件/手填、确认墙、防重复、完整度 → Phase 2
- 真实营业额、成本估算、行业 Benchmark、利润区间 → Phase 1
- Today、7日趋势、Top 3、简化对账 → Phase 3
- 行动、执行材料、提醒、次日验证、AI 追问 → Phase 4
- 原生微信小程序完整交互与错误状态 → Phase 5

## Full-suite command after every phase

```bash
python -m pytest -q
python -m compileall .
```

Expected at every phase boundary: all pre-existing R1 tests remain PASS and all newly added phase tests PASS.
