# 食策AI Mini V1 Phase 4 — Actions, Verification, Reminder & AI Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 把“发现问题”变成可执行闭环：建议、执行记录、微信订阅提醒、次日指标验证，以及只基于结构化门店上下文的 AI 解释/文字材料。

**Architecture:** Action Engine 只消费结构化 anomaly/metric，不让 LLM 自由决定财务事实；Verification Engine 比较预先声明的目标指标，只描述“执行后相关指标变化”而不宣称因果。AI Context Service 先做 Sufficiency Gate，再把事实/估算/缺失项交给可替换文本模型。

**Tech Stack:** Python, FastAPI, SQLite, pytest, httpx, pluggable text-model provider, WeChat subscription message provider.

**Spec:** `docs/superpowers/specs/2026-09-02-shice-ai-mini-v1-design.md`

## Global Constraints
- 高风险动作只能提供步骤，未经用户确认不得自动执行第三方操作。
- `EXECUTED` 只能由用户明确“我已经做完”产生。
- 效果验证不声称因果。
- AI 不做核心算账，不把用户闲聊当结构化事实。
- 数据不足时 AI 必须返回缺失项和补数入口。

---

### Task 1: Action/verification/reminder schema and repositories

**Files:**
- Modify: `db_v3.py`
- Create: `repositories/action_repository.py`
- Test: `tests/test_action_schema.py`

**Interfaces:**
- Tables: `action_items`, `action_executions`, `action_verifications`, `reminders`, `ai_conversations`, `ai_messages`

- [ ] **Step 1: Write failing schema/state tests**

```python
def test_action_status_constraint(v3_db):
    allowed = {"PENDING","EXECUTED","SKIPPED","REMIND","WAITING_VERIFICATION","VERIFIED"}
    assert read_check_values(v3_db, "action_items", "status") == allowed
```

- [ ] **Step 2: Implement tables and repository methods**

Required repository signatures:

- `create_action(store_id: int, business_date: str, anomaly_id: int, action_type: str, title: str, reason: str, expected_metric: str, expected_direction: str, priority: int) -> dict`
- `mark_executed(action_id: int, store_id: int, executed_at: int, note: str | None = None) -> dict`
- `mark_skipped(action_id: int, store_id: int) -> dict`
- `schedule_reminder(action_id: int, user_id: int, store_id: int, scheduled_at: int) -> dict`

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_action_schema.py -q
```

---

### Task 2: Rule-based Action Engine and max-3 action policy

**Files:**
- Create: `services/action_engine.py`
- Create: `mini/action_routes.py`
- Test: `tests/test_action_engine.py`

**Interfaces:**
- `ActionEngine.generate(store_id, business_date) -> list[ActionItem]`
- Endpoints: `GET /actions`, `GET /actions/<built-in function id>`, `POST /actions/<built-in function id>/execute`, `/skip`, `/remind`

- [ ] **Step 1: Write failing action tests**

```python
def test_action_engine_returns_at_most_three_and_links_to_issue(v3_db):
    actions = ActionEngine(v3_db).generate(1, "2026-09-02")
    assert len(actions) <= 3
    assert all(a.anomaly_id for a in actions)
```

- [ ] **Step 2: Implement versioned action templates**

Start with deterministic mappings for V1 issue types such as reconciliation difference, low AOV/low-price mix, labor pressure, incomplete data. Unknown issue types may return explanation-only action; never fabricate platform UI steps.

- [ ] **Step 3: Enforce explicit execute semantics**

`POST /execute` records execution; merely opening an action or generating copy never changes status to EXECUTED.

- [ ] **Step 4: Run tests**

```bash
python -m pytest tests/test_action_engine.py -q
```

---

### Task 3: Verification Engine

**Files:**
- Create: `services/verification_engine.py`
- Test: `tests/test_verification_engine.py`

**Interfaces:**
- `VerificationEngine.verify(action_id: int, verification_date: str) -> VerificationResult`

- [ ] **Step 1: Write all four result-state tests**

```python
@pytest.mark.parametrize("before,after,expected", [
    ("28","23","IMPROVED"),
    ("28","27.8","NO_CLEAR_CHANGE"),
    ("28","32","WORSENED"),
    (None,"23","INSUFFICIENT_DATA"),
])
def test_verification_states(before, after, expected, verification_fixture):
    action_id = verification_fixture(expected_metric="LABOR_COST_RATE", expected_direction="DOWN", before=before, after=after)
    result = VerificationEngine(verification_fixture.db).verify(action_id, "2026-09-03")
    assert result.result == expected
```

- [ ] **Step 2: Implement metric-specific direction/tolerance**

Each action stores `expected_metric` and `expected_direction`; verification compares only that metric with versioned tolerance. Explanation wording must use “执行后相关指标…” not “因为这个动作导致…”.

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_verification_engine.py -q
```

---

### Task 4: WeChat subscription reminder provider

**Files:**
- Create: `notifications/provider.py`
- Create: `notifications/wechat.py`
- Create: `services/reminder_service.py`
- Test: `tests/test_reminder_service.py`

**Interfaces:**
- `NotificationProvider.send(reminder) -> SendResult`
- `ReminderService.dispatch_due(now) -> list[SendResult]`

- [ ] **Step 1: Write fake-provider tests**

```python
def test_due_reminder_is_sent_once(v3_db):
    fake = FakeNotificationProvider()
    results = ReminderService(v3_db, fake).dispatch_due(now=FIXED_TIME)
    assert len(results) == 1
    assert fake.sent[0].action_id == 1
    assert reminder_status(v3_db, 1) == "SENT"
```

- [ ] **Step 2: Implement WeChat provider using environment credentials**

Use `WECHAT_APPID`, `WECHAT_SECRET`, `WECHAT_SUBSCRIBE_TEMPLATE_ID`. Failed provider calls persist `FAILED` plus error summary; no infinite retry loop. Retry is a separate explicit scheduler run.

- [ ] **Step 3: Add a CLI/scheduler entrypoint**

Create `jobs/send_due_reminders.py` which exits non-zero on provider/system failure and prints counts for SENT/FAILED/SKIPPED.

- [ ] **Step 4: Run tests**

```bash
python -m pytest tests/test_reminder_service.py -q
```

---

### Task 5: AI Context Service and Sufficiency Gate

**Files:**
- Create: `ai/provider.py`
- Create: `services/ai_context_service.py`
- Create: `services/sufficiency_gate.py`
- Test: `tests/test_ai_context.py`

**Interfaces:**
- `AIContextService.build(store_id, question, business_date) -> AIContext`
- `SufficiencyGate.check(question_type, context) -> SufficiencyResult`

- [ ] **Step 1: Write failing context/sufficiency tests**

```python
def test_labor_question_without_labor_data_is_blocked(v3_db):
    ctx = AIContextService(v3_db).build(1, "我今天人工是不是太高？", "2026-09-02")
    gate = SufficiencyGate().check("LABOR_DIAGNOSIS", ctx)
    assert gate.sufficient is False
    assert "人工" in gate.missing_data
```

- [ ] **Step 2: Implement structured context**

```python
@dataclass(frozen=True)
class AIContext:
    facts: dict
    estimates: dict
    missing_data: Sequence[str]
    anomalies: Sequence[dict]
    recent_actions: Sequence[dict]
```

Never include legacy free-form chat as a financial fact source.

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_ai_context.py -q
```

---

### Task 6: AI chat and text execution-material endpoints

**Files:**
- Create: `ai/text_service.py`
- Create: `mini/ai_routes.py`
- Modify: `mini/action_routes.py`
- Test: `tests/test_ai_routes.py`

**Interfaces:**
- `POST /api/mini/v1/ai/chat`
- `POST /api/mini/v1/actions/<built-in function id>/generate-copy`

- [ ] **Step 1: Write failing provider-independent tests**

```python
def test_ai_chat_returns_missing_data_without_calling_model(client, auth_headers, fake_text_provider):
    r = client.post("/api/mini/v1/ai/chat", headers=auth_headers,
                    json={"question":"我今天人工是不是太高？","date":"2026-09-02"})
    assert r.json()["status"] == "NEEDS_DATA"
    assert fake_text_provider.calls == []
```

- [ ] **Step 2: Implement model provider interface**

The provider contract is the exact method `TextModelProvider.generate(system: str, user: str) -> str`; tests inject a deterministic fake implementation, while production configuration selects the real provider adapter.

Provider input is generated from facts/estimates/missing/anomalies only. Prompt explicitly forbids inventing numbers and asks for plain-language output.

- [ ] **Step 3: Implement copy-generation templates**

V1 supported outputs: `WECHAT_GROUP`, `MOMENTS`, `XIAOHONGSHU`, `DOUYIN_CAPTION`, `ACTIVITY_PLAN`. The response is draft material only; no auto-publish action exists.

- [ ] **Step 4: Run Phase-4 + full regression**

```bash
python -m pytest tests/test_action_schema.py tests/test_action_engine.py tests/test_verification_engine.py tests/test_reminder_service.py tests/test_ai_context.py tests/test_ai_routes.py -q
python -m pytest -q
```

- [ ] **Step 5: Phase-4 Gate report**

Create `docs/superpowers/gates/2026-09-02-mini-v1-phase4-gate.md` including one full fixture story: anomaly → action → executed → reminder → next-day verification.
