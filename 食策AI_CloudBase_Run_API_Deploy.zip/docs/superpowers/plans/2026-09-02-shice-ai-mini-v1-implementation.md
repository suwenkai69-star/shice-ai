# 食策AI Mini V1 Implementation Roadmap

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement each phase plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在不重写 V0.5.0-R1 Data Foundation 的前提下，交付一个原生微信小程序老板版，跑通“上传 → 经营判断 → Top 3 问题 → 行动 → 提醒 → 次日验证”的单店闭环。

**Architecture:** 现有 FastAPI + SQLite Data Foundation 继续作为可信财务底座；新增 Schema V3、Mini API Facade、独立业务服务与原生微信小程序。复杂财务计算和数据可信度判断由规则/服务层完成，AI 只做解释、建议和文字材料生成。

**Tech Stack:** Python 3.13+ compatible code, FastAPI, SQLite, pytest, Pydantic, openpyxl, native WeChat Mini Program (WXML/WXSS/JavaScript), WeChat subscription messages, pluggable recognition provider.

**Spec:** `docs/superpowers/specs/2026-09-02-shice-ai-mini-v1-design.md`

## Global Constraints

- V0.5.0-R1 的 `daily_channel_sales / settlements / platform_fees / payments / reconciliation_matches / import_*` 语义与追溯链必须保留。
- V3 只以 additive 方式新增 `TAOBAO_FLASH`，保留原有 `MEITUAN_FLASH` 和其历史数据。
- 财务金额继续使用 `Decimal`；SQLite 中规范化金额继续保存为 canonical decimal text。
- AI/OCR 识别结果不得直接写正式经营事实，必须经过 Draft → Confirm → Import。
- 没有真实营业额不得输出经营利润。
- 成本估算必须保存来源与区间；未通过 Benchmark Gate 的基准不得参与生产计算。
- 周期结算费用不得伪造成某一天实际费用。
- 整店销售总额与渠道销售不得静默重复相加。
- 不确定是否安全合并的数据更正继续 fail closed。
- 首页最多 3 个重点问题，最多 3 个重点行动。
- 小程序前台为单店体验，正式业务数据仍保留 `store_id`。
- V1 不做平台 API/RPA、自动调价/发券/关活动、图片生成、BOM、库存、税务、发票、多门店前端、复杂权限、PostgreSQL 迁移。
- 当前交付源代码快照没有 `.git`；执行时不得为了满足流程而伪造 Git 历史。如在真实 Git 仓库执行，则按各任务 Commit 步骤提交；否则保留测试输出与打包 SHA256 作为 checkpoint。

---

## Why this is split into phase plans

设计规格覆盖 Schema、认证、利润、上传、OCR、异常、行动、提醒、AI 与原生小程序多个独立子系统。为避免一个超大计划失去可审查性，实施拆成 5 个有明确依赖关系、每个都能独立验收的阶段。

| Phase | Plan | 独立交付物 | 依赖 |
|---|---|---|---|
| 1 | `2026-09-02-shice-ai-mini-v1-phase1-core.md` | Schema V3 + Repository + Auth/Store + Revenue Resolver + Cost/Benchmark/Profit | R1 |
| 2 | `2026-09-02-shice-ai-mini-v1-phase2-ingestion.md` | 手填/CSV/XLSX + OCR Draft/Confirm + 防重复 + 数据完整度 | Phase 1 |
| 3 | `2026-09-02-shice-ai-mini-v1-phase3-insights.md` | Today 聚合 + 7日趋势 + Top 3 异常 + 简化对账 | Phase 1–2 |
| 4 | `2026-09-02-shice-ai-mini-v1-phase4-actions-ai.md` | 行动/执行/验证 + 订阅提醒 + AI Context + 文字执行材料 | Phase 3 |
| 5 | `2026-09-02-shice-ai-mini-v1-phase5-miniprogram-e2e.md` | 原生微信小程序页面 + API 接入 + Demo + E2E/真机试点 Gate | Phase 1–4 |

## Phase gates

- [ ] **Gate 1 — Core correctness:** Schema V2→V3 原地升级、R1 回归全绿；利润无真实营业额时为 UNAVAILABLE；整店/渠道收入无重复计算。
- [ ] **Gate 2 — Ingestion trust:** 任意图片/文件先草稿确认；同日累计更新不会双算；坏文件有可审计失败记录；完整度可自动学习并允许人工结束等待。
- [ ] **Gate 3 — Insight usefulness:** `/api/mini/v1/today` 一次返回老板首页需要的内容；异常最多 3 条；低可信异常不能伪装成确定事实；对账无证据不归责平台。
- [ ] **Gate 4 — Closed loop:** 建议可执行/跳过/提醒；次日返回 IMPROVED / NO_CLEAR_CHANGE / WORSENED / INSUFFICIENT_DATA；AI 数据不足时明确提示缺失项。
- [ ] **Gate 5 — Mini V1 acceptance:** 新用户从微信进入到截图确认、利润区间、Top 3、执行、提醒、次日验证的完整场景可在 DevTools + 真机试点跑通。

## Spec coverage map

- 微信登录、单店、Demo、4 Tab → Phase 1 + Phase 5
- 截图/文件/手填、确认墙、防重复、完整度 → Phase 2
- 真实营业额、成本估算、行业 Benchmark、利润区间 → Phase 1
- Today、7日趋势、Top 3、简化对账 → Phase 3
- 行动、执行材料、提醒、次日验证、AI 追问 → Phase 4
- 原生微信小程序完整交互与错误状态 → Phase 5

## Full-suite command after every phase

```bash
python -m pytest -q
python -m compileall .
```

Expected at every phase boundary: all pre-existing R1 tests remain PASS and all newly added phase tests PASS.


---

# 食策AI Mini V1 Phase 1 — Core Foundation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 建立 Mini V1 的 Schema V3、repository 边界、微信认证/单店绑定、收入覆盖语义，以及可审计的成本/Benchmark/利润区间引擎。

**Architecture:** 新建 `db.py` 作为迁移编排器，保留 `db_v2.py` 的 V2 兼容职责；Mini 新能力写入独立 package，不把逻辑继续堆进 `app.py`。Revenue Resolver 先解决整店总额与渠道数据重叠，再由 Profit Engine 按真实数据→本店历史→当地/行业基准的优先级计算经营利润区间。

**Tech Stack:** Python, FastAPI, SQLite, Decimal, pytest, Pydantic.

**Spec:** `docs/superpowers/specs/2026-09-02-shice-ai-mini-v1-design.md`

## Global Constraints

- 不修改 R1 已确认的 V2 财务语义。
- Schema V3 必须能从 V2 原地升级，失败时事务回滚。
- `db_v2.migrate_database()` 继续只负责到 V2；新 `db.migrate_database()` 编排 V2→V3。
- V3 追加 `TAOBAO_FLASH` 渠道但保留 `MEITUAN_FLASH`；不得通过重命名破坏历史渠道。
- `category_code` 固定为 `MILK_TEA / COFFEE / FAST_FOOD_SNACK / CHINESE_DINING / HOTPOT / BBQ / BAKERY_DESSERT / BAR_LEISURE / OTHER_FOOD`。
- 任何业务查询必须带 `store_id`；前端单店不等于后端省略隔离键。
- 没有真实营业额时 Profit Engine 必须返回 `UNAVAILABLE`。
- Benchmark 必须有来源、日期、区域与审核状态；未审核记录不得参与估算。
- 结算周期费用不按单日伪分摊。

---

### Task 1: Schema V3 migration orchestrator and core tables

**Files:**
- Create: `db.py`
- Create: `db_v3.py`
- Modify: `app.py:1-75`
- Test: `tests/test_schema_v3.py`

**Interfaces:**
- Produces: `db.migrate_database(db_path: str | Path) -> int`
- Produces: `db_v3.migrate_v2_to_v3(db_path: str | Path, fail_after_statement: int | None = None) -> int`
- Consumes: `db_v2.get_schema_version`, `db_v2.migrate_database`

- [ ] **Step 1: Write failing migration tests**

```python
from tests.test_schema_v2 import create_v04_db


def test_v2_database_migrates_to_schema_v3(tmp_path):
    from db_v2 import migrate_database as migrate_v2
    from db import migrate_database
    db = tmp_path / "mini.db"
    create_v04_db(db)
    assert migrate_v2(db) == 2
    assert migrate_database(db) == 3
    required = {
        "mini_users", "store_profiles", "daily_store_sales_totals",
        "store_cost_profiles", "cost_entries", "industry_benchmarks",
        "profit_snapshots",
    }
    with sqlite3.connect(db) as con:
        names = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert required.issubset(names)


def test_v3_migration_rolls_back_on_injected_failure(tmp_path):
    from db_v2 import migrate_database as migrate_v2
    from db_v3 import migrate_v2_to_v3
    db = tmp_path / "mini.db"
    create_v04_db(db)
    migrate_v2(db)
    with pytest.raises(RuntimeError, match="injected v3 migration failure"):
        migrate_v2_to_v3(db, fail_after_statement=4)
    assert get_schema_version(db) == 2
```

- [ ] **Step 2: Run the targeted tests and verify failure**

```bash
python -m pytest tests/test_schema_v3.py -q
```

Expected: FAIL because `db.py`, `db_v3.py`, and V3 tables do not exist.

- [ ] **Step 3: Implement V3 migration with explicit tables and checks**

`db.py` must expose only the orchestrator:

```python
def migrate_database(db_path):
    version = get_schema_version(db_path)
    if version < 2:
        migrate_v2(db_path)
        version = get_schema_version(db_path)
    if version == 2:
        return migrate_v2_to_v3(db_path)
    if version == 3:
        return 3
    raise RuntimeError(f"database has newer schema version {version}; refusing downgrade to 3")
```

`db_v3.py` creates the exact Phase-1 tables with foreign keys to `stores(id)`, `schema_meta.schema_version=3`, millisecond timestamps, seeds `TAOBAO_FLASH / 淘宝闪购 / DELIVERY` with `INSERT OR IGNORE`, and applies these minimum uniqueness rules:

```sql
UNIQUE(wechat_openid)
UNIQUE(store_id)
UNIQUE(store_id, business_date)              -- daily_store_sales_totals
UNIQUE(category_code, region_level, region_code, metric_code, valid_from)
```

`industry_benchmarks` must include `review_status TEXT CHECK(review_status IN ('DRAFT','APPROVED','REJECTED'))`.

- [ ] **Step 4: Switch app startup to the orchestrator**

In `app.py`, replace `from db_v2 import migrate_database` with `from db import migrate_database`; do not change V2 endpoint behavior.

- [ ] **Step 5: Update the additive-channel API expectation and run migration + full R1 regression**

`tests/test_api_v2.py` must stop asserting an exact channel count of 9 after application-level V3 migration. Assert that the original 9 R1 codes remain present and `TAOBAO_FLASH` is additionally present. `tests/test_schema_v2.py` continues to test pure V2 migration in isolation and still expects the original 9 channels.

```bash
python -m pytest tests/test_schema_v3.py tests/test_schema_v2.py tests/test_data_integrity_r1.py tests/test_api_v2.py -q
```

Expected: all PASS; no original channel code is removed or renamed.

- [ ] **Step 6: Checkpoint**

```bash
git status --short 2>/dev/null || true
```

If running in the canonical Git repository:

```bash
git add db.py db_v3.py app.py tests/test_schema_v3.py
git commit -m "feat: add mini schema v3 foundation"
```

Do not initialize Git in an extracted delivery snapshot.

---

### Task 2: Repository boundary and store isolation

**Files:**
- Create: `repositories/__init__.py`
- Create: `repositories/mini_store_repository.py`
- Create: `repositories/mini_sales_repository.py`
- Create: `repositories/mini_cost_repository.py`
- Test: `tests/test_mini_repositories.py`

**Interfaces:**
- Produces: `MiniStoreRepository(db_path)`
- Produces: `MiniSalesRepository(db_path)`
- Produces: `MiniCostRepository(db_path)`
- Every read/write method consumes an explicit `store_id: int` unless it resolves ownership by `user_id`.

- [ ] **Step 1: Write failing isolation tests**

```python
def test_sales_repository_never_crosses_store_boundary(v3_db):
    repo = MiniSalesRepository(v3_db)
    repo.upsert_store_total(1, "2026-09-02", "1000.00", "ACTUAL", "MANUAL")
    repo.upsert_store_total(2, "2026-09-02", "2000.00", "ACTUAL", "MANUAL")
    assert repo.get_store_total(1, "2026-09-02")["gross_sales"] == "1000.00"
    assert repo.get_store_total(2, "2026-09-02")["gross_sales"] == "2000.00"
```

- [ ] **Step 2: Run and verify failure**

```bash
python -m pytest tests/test_mini_repositories.py -q
```

- [ ] **Step 3: Implement focused repository methods**

Required signatures (implement these exact names and types):

- `MiniStoreRepository.create_or_get_user(openid: str, unionid: str | None = None) -> dict`
- `MiniStoreRepository.bind_store(user_id: int, store_id: int) -> None`
- `MiniStoreRepository.get_current_store(user_id: int) -> dict | None`
- `MiniStoreRepository.create_store(user_id: int, name: str, category_code: str) -> dict`
- `MiniSalesRepository.upsert_store_total(store_id: int, business_date: str, gross_sales: str, source_kind: str, source_ref: str | None) -> dict`
- `MiniSalesRepository.get_store_total(store_id: int, business_date: str) -> dict | None`
- `MiniSalesRepository.list_channel_sales(store_id: int, business_date: str) -> list[dict]`
- `MiniCostRepository.get_profile(store_id: int) -> dict | None`
- `MiniCostRepository.save_profile(store_id: int, values: dict) -> dict`
- `MiniCostRepository.list_cost_entries(store_id: int, start: str, end: str) -> list[dict]`
- `MiniCostRepository.list_approved_benchmarks(category_code: str, metric_code: str, region_codes: list[str]) -> list[dict]`

- [ ] **Step 4: Run repository tests**

```bash
python -m pytest tests/test_mini_repositories.py -q
```

Expected: PASS.

- [ ] **Step 5: Checkpoint / commit if Git exists**

```bash
git add repositories tests/test_mini_repositories.py && git commit -m "feat: add mini repositories"
```

---

### Task 3: Mini auth provider, token service, and single-store onboarding API

**Files:**
- Create: `mini/__init__.py`
- Create: `mini/auth.py`
- Create: `mini/models.py`
- Create: `mini/routes.py`
- Modify: `app.py:20-45,229-240`
- Modify: `requirements.txt`
- Test: `tests/test_mini_auth_api.py`

**Interfaces:**
- Produces: `AuthProvider.exchange_code(code: str) -> WechatIdentity`
- Produces: `TokenService.issue(user_id: int) -> str`
- Produces: `TokenService.verify(token: str) -> int`
- Produces endpoints: `POST /api/mini/v1/auth/wechat`, `POST/GET/PATCH /api/mini/v1/store`

- [ ] **Step 1: Write failing API tests using an injected fake provider**

```python
def test_wechat_login_and_store_onboarding(client, monkeypatch):
    monkeypatch.setattr("mini.auth.get_auth_provider", lambda: FakeAuthProvider("openid-1"))
    login = client.post("/api/mini/v1/auth/wechat", json={"code": "wx-code"})
    token = login.json()["token"]
    created = client.post(
        "/api/mini/v1/store",
        headers={"Authorization": f"Bearer {token}"},
        json={"name": "老王奶茶", "category_code": "MILK_TEA"},
    )
    assert created.status_code == 200
    assert created.json()["store"]["name"] == "老王奶茶"
```

Also test: invalid/missing token → 401; user A cannot read user B store.

- [ ] **Step 2: Run and verify failure**

```bash
python -m pytest tests/test_mini_auth_api.py -q
```

- [ ] **Step 3: Implement authentication contracts**

Use signed HMAC tokens with `MINI_TOKEN_SECRET` and timestamped payload; do not store WeChat `session_key` in API responses. `AuthProvider` has two explicit implementations:

```python
class DevAuthProvider(AuthProvider):
    def exchange_code(self, code: str) -> WechatIdentity:
        if not code.startswith("dev-"):
            raise AuthError("invalid dev code")
        return WechatIdentity(openid=f"dev:{code}", unionid=None)

class WechatAuthProvider(AuthProvider):
    def exchange_code(self, code: str) -> WechatIdentity:
        response = self.client.get(self.endpoint, params={
            "appid": self.appid, "secret": self.secret, "js_code": code,
            "grant_type": "authorization_code",
        })
        payload = response.json()
        if response.status_code != 200 or payload.get("errcode"):
            raise AuthError(payload.get("errmsg") or "wechat code exchange failed")
        return WechatIdentity(openid=payload["openid"], unionid=payload.get("unionid"))
```

Add `httpx>=0.27` to `requirements.txt` for the WeChat server exchange.

- [ ] **Step 4: Mount the Mini router without moving legacy endpoints**

```python
from mini.routes import router as mini_router
app.include_router(mini_router, prefix="/api/mini/v1")
```

- [ ] **Step 5: Run auth/API + legacy regression**

```bash
python -m pytest tests/test_mini_auth_api.py tests/test_api_v2.py tests/test_v04_regression.py -q
```

Expected: PASS.

- [ ] **Step 6: Checkpoint / commit if Git exists**

```bash
git add mini repositories app.py requirements.txt tests/test_mini_auth_api.py && git commit -m "feat: add mini auth and onboarding"
```

---

### Task 4: Revenue Resolver and whole-store/channel overlap semantics

**Files:**
- Create: `services/__init__.py`
- Create: `services/revenue_resolver.py`
- Test: `tests/test_revenue_resolver.py`

**Interfaces:**
- Produces: `RevenueResolver.resolve(store_id: int, business_date: str) -> RevenueResult`
- `RevenueResult` fields: `amount: Decimal | None`, `source: str`, `coverage: str`, `warnings: list[str]`

- [ ] **Step 1: Write failing coverage tests**

```python
def test_whole_store_total_wins_over_overlapping_payment_channels(v3_db):
    # POS/整店总额 1000，微信 600 + 支付宝 400 只是支付拆分，不能得到 2000。
    seed_store_total(v3_db, 1, "2026-09-02", "1000.00")
    seed_channel_sale(v3_db, 1, "2026-09-02", "WECHAT_PAY", "600.00")
    seed_channel_sale(v3_db, 1, "2026-09-02", "ALIPAY", "400.00")
    result = RevenueResolver(v3_db).resolve(1, "2026-09-02")
    assert result.amount == Decimal("1000.00")
    assert result.coverage == "WHOLE_STORE_TOTAL"


def test_channel_sum_is_used_when_no_whole_store_total(v3_db):
    seed_channel_sale(v3_db, 1, "2026-09-02", "MEITUAN_DELIVERY", "700.00")
    seed_channel_sale(v3_db, 1, "2026-09-02", "DOUYIN_LOCAL", "300.00")
    assert RevenueResolver(v3_db).resolve(1, "2026-09-02").amount == Decimal("1000.00")
```

- [ ] **Step 2: Run and verify failure**

```bash
python -m pytest tests/test_revenue_resolver.py -q
```

- [ ] **Step 3: Implement deterministic resolver rules**

Rules in order:

```text
1. Confirmed whole-store total exists → use it as total revenue.
2. Otherwise sum non-overlapping sales channels.
3. Payment channels WECHAT_PAY/ALIPAY/CASH are not automatically added on top of a confirmed whole-store total.
4. If coverage metadata is ambiguous, return warning and do not silently add both scopes.
```

The resolver must not use settlement/payment amounts as sales revenue.

- [ ] **Step 4: Run targeted + V2 calculation tests**

```bash
python -m pytest tests/test_revenue_resolver.py tests/test_calculation_reconciliation_v2.py -q
```

- [ ] **Step 5: Checkpoint / commit if Git exists**

```bash
git add services/revenue_resolver.py tests/test_revenue_resolver.py && git commit -m "feat: resolve whole-store revenue safely"
```

---

### Task 5: Benchmark repository, approval gate, and auditable seed format

**Files:**
- Create: `services/benchmark_service.py`
- Create: `data/benchmarks/benchmark_seed.schema.json`
- Create: `data/benchmarks/benchmark_seed.json`
- Test: `tests/test_benchmark_service.py`

**Interfaces:**
- Produces: `BenchmarkService.find_range(category_code, metric_code, city_code=None) -> BenchmarkRange | None`
- `BenchmarkRange`: `low: Decimal`, `mid: Decimal`, `high: Decimal`, `source_name`, `source_url`, `source_date`, `confidence_level`, `benchmark_id`

- [ ] **Step 1: Write failing gate tests**

```python
def test_unapproved_benchmark_is_never_used(v3_db):
    insert_benchmark(v3_db, review_status="DRAFT", metric_code="FOOD_COST_RATE")
    assert BenchmarkService(v3_db).find_range("MILK_TEA", "FOOD_COST_RATE", "URUMQI") is None


def test_local_approved_benchmark_beats_national(v3_db):
    insert_benchmark(v3_db, region_level="COUNTRY", region_code="CN", low="0.35", high="0.45", review_status="APPROVED")
    insert_benchmark(v3_db, region_level="CITY", region_code="URUMQI", low="0.38", high="0.42", review_status="APPROVED")
    result = BenchmarkService(v3_db).find_range("MILK_TEA", "FOOD_COST_RATE", "URUMQI")
    assert result.low == Decimal("0.38")
```

- [ ] **Step 2: Run and verify failure**

```bash
python -m pytest tests/test_benchmark_service.py -q
```

- [ ] **Step 3: Implement benchmark priority and seed validation**

Priority:

```text
APPROVED city → APPROVED province → APPROVED country → None
```

Seed JSON exact record shape:

```json
{
  "category_code": "MILK_TEA",
  "region_level": "COUNTRY",
  "region_code": "CN",
  "metric_code": "FOOD_COST_RATE",
  "low_value": "0.38",
  "mid_value": "0.42",
  "high_value": "0.45",
  "unit": "RATE",
  "source_name": "source title",
  "source_url": "https://example.org/research-source",
  "source_date": "2026-01-01",
  "confidence_level": "MEDIUM",
  "review_status": "APPROVED",
  "valid_from": "2026-01-01"
}
```

Production import rejects records without source URL/date or with `review_status != APPROVED`.

- [ ] **Step 4: Populate the first production seed only from reviewed sources**

Research output must cover the V1 category codes that have defensible public data. For any category/metric without a defensible source, omit the benchmark rather than inventing a number; Profit Engine will expose the missing input. The seed file must include source metadata for every row and no uncited magic numbers.

- [ ] **Step 5: Run benchmark tests and JSON validation**

```bash
python -m pytest tests/test_benchmark_service.py -q
python -m json.tool data/benchmarks/benchmark_seed.json >/dev/null
```

- [ ] **Step 6: Checkpoint / commit if Git exists**

```bash
git add services/benchmark_service.py data/benchmarks tests/test_benchmark_service.py && git commit -m "feat: add audited benchmark service"
```

---

### Task 6: Cost profile and Profit Engine

**Files:**
- Create: `services/cost_resolver.py`
- Create: `services/profit_engine.py`
- Create: `mini/profit_routes.py`
- Modify: `mini/routes.py`
- Test: `tests/test_profit_engine.py`
- Test: `tests/test_mini_profit_api.py`

**Interfaces:**
- Produces: `CostResolver.resolve(store_id, business_date, cost_type) -> CostRange`
- Produces: `ProfitEngine.calculate(store_id, business_date) -> ProfitResult`
- Endpoints: `GET /profit/today`, `GET /profit/profile`, `PATCH /profit/profile`

- [ ] **Step 1: Write failing profit tests**

```python
def test_profit_unavailable_without_real_revenue(v3_db):
    result = ProfitEngine(v3_db).calculate(1, "2026-09-02")
    assert result.status == "UNAVAILABLE"
    assert "营业额" in result.missing_data


def test_profit_returns_range_when_some_costs_are_benchmarks(v3_db):
    seed_store_total(v3_db, 1, "2026-09-02", "10000.00")
    seed_actual_cost(v3_db, 1, "2026-09-02", "MARKETING", "500.00")
    seed_approved_rate_benchmark(v3_db, "MILK_TEA", "FOOD_COST_RATE", "0.38", "0.45")
    result = ProfitEngine(v3_db).calculate(1, "2026-09-02")
    assert result.status == "ESTIMATED_RANGE"
    assert result.profit_low < result.profit_high
    assert any(x.source == "INDUSTRY_BENCHMARK" for x in result.components)
```

Also test actual costs override benchmark, store history overrides industry when enough valid history exists, and weekly settlement fee with `business_date=NULL` is not assigned to today.

- [ ] **Step 2: Run and verify failure**

```bash
python -m pytest tests/test_profit_engine.py tests/test_mini_profit_api.py -q
```

- [ ] **Step 3: Implement cost-source priority**

For each cost type, use:

```text
ACTUAL → STORE_HISTORY → LOCAL_BENCHMARK → INDUSTRY_BENCHMARK → UNKNOWN
```

Special rules:
- Food: actual consumed-cost entry or user cost-rate profile; purchase amount alone is not automatically consumption cost.
- Labor: actual monthly labor, otherwise city/category benchmark × full-time count + hourly benchmark × part-time hours.
- Rent: actual monthly rent allocated by configured operating-day rule; otherwise approved rent-to-sales benchmark.
- Platform: use daily attributable actual fees only; settlement-period fee without day attribution stays outside today profit.
- Owner labor: tracked separately and not forced into headline operating profit.

- [ ] **Step 4: Implement ProfitResult with explicit provenance**

```python
@dataclass(frozen=True)
class ProfitComponent:
    code: str
    low: Decimal
    high: Decimal
    source: str
    source_ref: str | None

@dataclass(frozen=True)
class ProfitResult:
    status: Literal["ACTUAL_BASED", "ESTIMATED_RANGE", "UNAVAILABLE"]
    revenue: Decimal | None
    profit_low: Decimal | None
    profit_high: Decimal | None
    components: Sequence[ProfitComponent]
    missing_data: Sequence[str]
```

- [ ] **Step 5: Expose plain-language Mini Profit API**

Response must contain canonical numeric strings and user-facing source labels, e.g. `实际数据 / 根据本店历史估算 / 根据同类店参考 / 暂时没有数据`.

- [ ] **Step 6: Run full Phase-1 tests**

```bash
python -m pytest tests/test_schema_v3.py tests/test_mini_repositories.py tests/test_mini_auth_api.py tests/test_revenue_resolver.py tests/test_benchmark_service.py tests/test_profit_engine.py tests/test_mini_profit_api.py -q
python -m pytest -q
```

Expected: all PASS.

- [ ] **Step 7: Phase-1 Gate report**

Create `docs/superpowers/gates/2026-09-02-mini-v1-phase1-gate.md` containing exact test counts, migration smoke result, and unresolved external dependencies. Do not mark browser/OCR/UI work as PASS because it is not in Phase 1.

- [ ] **Step 8: Checkpoint / commit if Git exists**

```bash
git add services mini repositories tests data/benchmarks docs/superpowers/gates requirements.txt && git commit -m "feat: complete mini v1 core foundation"
```


---

# 食策AI Mini V1 Phase 2 — Ingestion & Recognition Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 交付统一“上传数据”后端：手动填写、CSV/XLSX、图片识别草稿、用户确认、正式导入、防重复与每日数据完整度。

**Architecture:** 所有输入先进入 Mini ingestion staging；图片识别永远只生成 draft。确认后 `MiniImportAdapter` 才调用现有 V2 importer 或 whole-store repository，确保原始证据链与 R1 fail-closed 原则保持完整。

**Tech Stack:** FastAPI, SQLite, pytest, openpyxl, pluggable RecognitionProvider.

**Spec:** `docs/superpowers/specs/2026-09-02-shice-ai-mini-v1-design.md`

## Global Constraints

- OCR/Vision 不直接写 `daily_channel_sales / settlements / payments`。
- 低可信字段必须可单独修改后确认。
- 同日累计更新不得重复累计。
- 不确定重复关系时返回 `POSSIBLE_DUPLICATE`，由用户选择。
- 空 CSV、坏 JSON/XLSX、无法识别文件仍必须留下可审计失败记录。
- V1 首批平台模板：美团外卖、淘宝闪购、京东外卖、抖音本地生活、美团团购、微信、支付宝、常见 POS 日报。

---

### Task 1: Phase-2 Schema tables and repositories

**Files:**
- Modify: `db_v3.py`
- Create: `repositories/upload_repository.py`
- Create: `repositories/data_status_repository.py`
- Test: `tests/test_ingestion_schema.py`

**Interfaces:**
- Tables: `upload_documents`, `extraction_jobs`, `extracted_fields`, `document_import_links`, `store_data_sources`, `daily_data_status`

- [ ] **Step 1: Write failing schema tests**

```python
def test_ingestion_tables_exist(v3_db):
    required = {"upload_documents","extraction_jobs","extracted_fields",
                "document_import_links","store_data_sources","daily_data_status"}
    assert required.issubset(table_names(v3_db))
```

- [ ] **Step 2: Run and verify failure**

```bash
python -m pytest tests/test_ingestion_schema.py -q
```

- [ ] **Step 3: Add additive V3 table creation**

All tables include `store_id` where relevant. `upload_documents.status` is constrained to:

```text
UPLOADED, PROCESSING, NEEDS_CONFIRMATION, CONFIRMED, IMPORTED, FAILED
```

`extracted_fields` stores `raw_text`, `normalized_value`, `confidence`, `user_corrected`, `confirmed_value`.

- [ ] **Step 4: Implement repositories and rerun tests**

```bash
python -m pytest tests/test_ingestion_schema.py -q
```

---

### Task 2: Manual data endpoints with explicit scope

**Files:**
- Create: `mini/manual_routes.py`
- Create: `services/manual_ingestion.py`
- Modify: `mini/routes.py`
- Test: `tests/test_manual_ingestion_api.py`

**Interfaces:**
- `POST /api/mini/v1/manual/sales`
- `POST /api/mini/v1/manual/cost`
- `POST /api/mini/v1/manual/payment`

- [ ] **Step 1: Write failing tests for whole-store and channel sales**

```python
def test_manual_whole_store_sale_does_not_create_fake_channel(client, auth_headers):
    r = client.post("/api/mini/v1/manual/sales", headers=auth_headers, json={
        "business_date":"2026-09-02", "scope":"WHOLE_STORE", "gross_sales":"1000.00"
    })
    assert r.status_code == 200
    assert r.json()["record"]["scope"] == "WHOLE_STORE"


def test_manual_channel_sale_requires_channel_code(client, auth_headers):
    r = client.post("/api/mini/v1/manual/sales", headers=auth_headers, json={
        "business_date":"2026-09-02", "scope":"CHANNEL", "gross_sales":"1000.00"
    })
    assert r.status_code == 422
```

- [ ] **Step 2: Implement explicit `WHOLE_STORE|CHANNEL` contract and Decimal validation**

Channel sales use existing V2 normalization where possible; whole-store totals write only `daily_store_sales_totals`.

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_manual_ingestion_api.py -q
```

---

### Task 3: CSV/XLSX preview-confirm pipeline

**Files:**
- Modify: `requirements.txt`
- Create: `services/file_preview.py`
- Create: `services/mini_import_adapter.py`
- Create: `mini/upload_routes.py`
- Test: `tests/test_file_upload_pipeline.py`

**Interfaces:**
- `POST /api/mini/v1/uploads/file` → draft summary
- `GET /api/mini/v1/uploads/<built-in function id>`
- `POST /api/mini/v1/uploads/<built-in function id>/confirm`
- `POST /api/mini/v1/uploads/<built-in function id>/reject`

- [ ] **Step 1: Write failing CSV and XLSX tests**

```python
def test_file_upload_is_preview_only_until_confirmed(client, auth_headers):
    upload = client.post("/api/mini/v1/uploads/file", headers=auth_headers,
        files={"file": ("sales.csv", SALES_CSV, "text/csv")})
    assert upload.json()["status"] == "NEEDS_CONFIRMATION"
    assert client.get("/api/v2/sales/daily?store_id=1").json()["sales"] == []
    confirm = client.post(f"/api/mini/v1/uploads/{upload.json()['id']}/confirm", headers=auth_headers)
    assert confirm.status_code == 200
    assert len(client.get("/api/v2/sales/daily?store_id=1").json()["sales"]) == 1
```

Also test malformed XLSX → FAILED document with error code; GB18030 CSV continues to work.

- [ ] **Step 2: Add `openpyxl>=3.1` and implement read-only XLSX parsing**

Do not execute formulas/macros. Accept `.xlsx` only; reject `.xls` with a clear user-facing error.

- [ ] **Step 3: Implement MiniImportAdapter**

Implement the exact method `MiniImportAdapter.import_confirmed_document(document_id: int, store_id: int) -> ImportOutcome`.

The adapter creates `document_import_links` to `import_file_id/import_batch_id` or whole-store record id after successful import.

- [ ] **Step 4: Run tests**

```bash
python -m pytest tests/test_file_upload_pipeline.py tests/test_data_integrity_r1.py -q
```

---

### Task 4: RecognitionProvider and platform-template parsing

**Files:**
- Create: `recognition/__init__.py`
- Create: `recognition/provider.py`
- Create: `recognition/templates.py`
- Create: `recognition/service.py`
- Create: `recognition/providers/fake.py`
- Test: `tests/test_recognition_service.py`

**Interfaces:**
- `RecognitionProvider.recognize(image_bytes: bytes) -> RecognitionDocument`
- `RecognitionService.create_draft(document_id: int) -> ExtractionDraft`
- Template IDs exactly versioned, e.g. `MEITUAN_DELIVERY_DAILY_V1` and `TAOBAO_FLASH_DAILY_V1`.

- [ ] **Step 1: Write failing service tests with deterministic fake provider**

```python
def test_recognition_creates_draft_not_business_fact(v3_db):
    service = RecognitionService(v3_db, provider=FakeRecognitionProvider({
        "platform":"MEITUAN_DELIVERY", "page_type":"DAILY_REPORT",
        "fields":{"GROSS_SALES":{"value":"3860.00","confidence":0.98},
                  "PLATFORM_FEE":{"value":"426.00","confidence":0.61}}
    }))
    draft = service.create_draft(seed_image_document(v3_db))
    assert draft.status == "NEEDS_CONFIRMATION"
    assert get_daily_sales_count(v3_db) == 0
    assert any(f.confidence < 0.70 for f in draft.fields)
```

- [ ] **Step 2: Implement provider-neutral normalized output**

Unknown platform/page → `UNKNOWN_PLATFORM`/`UNKNOWN_PAGE`; recognized text without semantic mapping remains an unconfirmed field, never guessed into financial semantics.

- [ ] **Step 3: Implement initial template label maps**

Each template defines required labels, aliases, output field codes, and whether the report is cumulative or interval-based. Do not encode a field mapping unless test fixtures prove the label semantics.

- [ ] **Step 4: Run recognition unit tests**

```bash
python -m pytest tests/test_recognition_service.py -q
```

---

### Task 5: Image upload, field correction, and confirm wall

**Files:**
- Modify: `mini/upload_routes.py`
- Create: `mini/extraction_models.py`
- Test: `tests/test_image_confirm_api.py`

**Interfaces:**
- `POST /api/mini/v1/uploads/image`
- `PATCH /api/mini/v1/uploads/<built-in function id>/fields`
- `POST /api/mini/v1/uploads/<built-in function id>/confirm`

- [ ] **Step 1: Write failing API test**

```python
def test_low_confidence_field_can_be_corrected_before_import(client, auth_headers, fake_recognition):
    upload = upload_test_image(client, auth_headers)
    doc_id = upload.json()["id"]
    patch = client.patch(f"/api/mini/v1/uploads/{doc_id}/fields", headers=auth_headers,
        json={"fields":[{"field_code":"PLATFORM_FEE","confirmed_value":"406.00"}]})
    assert patch.status_code == 200
    confirmed = client.post(f"/api/mini/v1/uploads/{doc_id}/confirm", headers=auth_headers)
    assert confirmed.json()["status"] == "IMPORTED"
```

- [ ] **Step 2: Implement validation**

Money/date/count fields normalize using the same R1 helpers where possible. Missing required fields prevent confirm; optional low-confidence fields may be explicitly excluded by user.

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_image_confirm_api.py -q
```

---

### Task 6: Duplicate/update detection for same-day cumulative reports

**Files:**
- Create: `services/duplicate_detection.py`
- Modify: `services/mini_import_adapter.py`
- Test: `tests/test_duplicate_detection.py`

**Interfaces:**
- `DuplicateDetectionService.classify(candidate, existing) -> NEW|UPDATE|POSSIBLE_DUPLICATE`

- [ ] **Step 1: Write failing scenarios**

```python
def test_later_cumulative_report_updates_instead_of_adds():
    existing = report("MEITUAN_DELIVERY", "2026-09-02", "14:00", "2000.00", cumulative=True)
    later = report("MEITUAN_DELIVERY", "2026-09-02", "20:00", "4800.00", cumulative=True)
    assert classify(later, existing) == "UPDATE"


def test_ambiguous_same_day_report_requires_user_choice():
    assert classify(ambiguous_report(), existing_report()) == "POSSIBLE_DUPLICATE"
```

- [ ] **Step 2: Implement classification using store/channel/date/template/time-range/reference**

Never infer UPDATE from amount alone.

- [ ] **Step 3: Expose conflict response and user decision endpoint**

`409` response includes choices `REPLACE_EXISTING` and `TREAT_AS_SEPARATE`; only valid where data scope semantics allow separate records.

- [ ] **Step 4: Run tests**

```bash
python -m pytest tests/test_duplicate_detection.py -q
```

---

### Task 7: Data completeness learning and manual completion

**Files:**
- Create: `services/completeness_service.py`
- Create: `mini/data_status_routes.py`
- Modify: `mini/routes.py`
- Test: `tests/test_completeness_service.py`

**Interfaces:**
- `CompletenessService.get_status(store_id, business_date) -> DataStatus`
- `POST /api/mini/v1/data-status/today/complete`

- [ ] **Step 1: Write failing tests**

```python
def test_repeated_sources_become_expected_after_history(v3_db):
    seed_source_presence(v3_db, store_id=1, channel="MEITUAN_DELIVERY", days=14, recent_30d=14)
    status = CompletenessService(v3_db).get_status(1, "2026-09-02")
    assert "MEITUAN_DELIVERY" in status.expected_sources


def test_user_can_declare_day_complete(v3_db):
    service = CompletenessService(v3_db)
    service.declare_complete(1, "2026-09-02")
    assert service.get_status(1, "2026-09-02").user_declared_complete is True
```

- [ ] **Step 2: Implement explicit expectation rule**

A source becomes expected when it appeared on at least 5 of the last 7 operating days or 12 of the last 30 days. This threshold is versioned as `COMPLETENESS_V1` so it can change later without rewriting history.

- [ ] **Step 3: Run Phase-2 suite and full regression**

```bash
python -m pytest tests/test_ingestion_schema.py tests/test_manual_ingestion_api.py tests/test_file_upload_pipeline.py tests/test_recognition_service.py tests/test_image_confirm_api.py tests/test_duplicate_detection.py tests/test_completeness_service.py -q
python -m pytest -q
```

- [ ] **Step 4: Phase-2 Gate report**

Create `docs/superpowers/gates/2026-09-02-mini-v1-phase2-gate.md`; explicitly separate deterministic fake-provider test PASS from real-provider/real-screenshot acceptance, which is completed in Phase 5 before release.


---

# 食策AI Mini V1 Phase 3 — Today, Trends, Anomaly & Reconciliation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 交付老板首页一次聚合查询、7日简要趋势、可信的 Top 3 异常和简化对账表达。

**Architecture:** 先由结构化服务计算，再由 Today Aggregator 组合；前端不拼多个财务口径。异常使用规则评分且把 severity 与 confidence 分离，对账继续复用 R1 reconciliation，不把“暂未对上”说成平台少打款。

**Tech Stack:** Python, FastAPI, SQLite, Decimal, pytest.

**Spec:** `docs/superpowers/specs/2026-09-02-shice-ai-mini-v1-design.md`

## Global Constraints
- `/api/mini/v1/today` 是首页唯一聚合入口。
- 首页最多返回 3 个 `top_issues`。
- 数据未齐时必须返回 `as_of` 与 completeness 状态。
- 低可信数据不能生成确定性警报。
- 对账结论只来自现有 settlement/payment/reconciliation 证据。

---

### Task 1: Anomaly schema and baseline service

**Files:**
- Modify: `db_v3.py`
- Create: `repositories/insight_repository.py`
- Create: `services/baseline_service.py`
- Test: `tests/test_baseline_service.py`

**Interfaces:**
- Table: `anomaly_events`
- `BaselineService.get(metric_code, store_id, business_date) -> Baseline`

- [ ] **Step 1: Write failing baseline-priority tests**

```python
def test_store_30d_baseline_beats_industry_when_enough_history(v3_db):
    seed_metric_history(v3_db, days=30, metric="AOV")
    seed_approved_benchmark(v3_db, metric="AOV")
    b = BaselineService(v3_db).get("AOV", 1, "2026-09-02")
    assert b.source in {"STORE_7D", "STORE_14D", "STORE_30D"}
```

- [ ] **Step 2: Implement baseline order**

```text
STORE_7D (enough comparable days) → STORE_14D → STORE_30D → LOCAL_CATEGORY → NATIONAL_CATEGORY
```

History uses median/robust range rather than a single raw prior day; minimum sample sizes are versioned.

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_baseline_service.py -q
```

---

### Task 2: Anomaly Engine and Top-3 prioritization

**Files:**
- Create: `services/anomaly_engine.py`
- Create: `mini/issue_routes.py`
- Test: `tests/test_anomaly_engine.py`

**Interfaces:**
- `AnomalyEngine.detect(store_id, business_date) -> list[Anomaly]`
- `AnomalyEngine.top_issues(store_id: int, business_date: str, limit: int = 3) -> list[Anomaly]`
- Endpoints: `GET /issues/today`, `GET /issues/<built-in function id>`

- [ ] **Step 1: Write failing ranking tests**

```python
def test_top_issues_never_returns_more_than_three(v3_db):
    issues = AnomalyEngine(v3_db).top_issues(1, "2026-09-02")
    assert len(issues) <= 3


def test_high_severity_low_confidence_does_not_outrank_reliable_cash_difference(v3_db):
    seed_anomaly_inputs(v3_db)
    top = AnomalyEngine(v3_db).top_issues(1, "2026-09-02")
    assert top[0].anomaly_type == "RECONCILIATION_DIFFERENCE"
```

- [ ] **Step 2: Implement `Priority Score` components explicitly**

Use normalized discrete factors, not a black-box model:

```text
impact 1..5 × severity 1..5 × confidence 0.25/0.5/0.75/1.0 × persistence 1..3 × actionability 1..3
```

Add deduplication by root-cause group so three variants of the same issue cannot fill all slots.

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_anomaly_engine.py -q
```

---

### Task 3: Simplified reconciliation service

**Files:**
- Create: `services/reconciliation_summary.py`
- Create: `mini/reconciliation_routes.py`
- Test: `tests/test_reconciliation_summary.py`

**Interfaces:**
- `ReconciliationSummaryService.today(store_id, business_date) -> ReconciliationSummary`
- Endpoints: `GET /reconciliation/today`, `GET /reconciliation/<built-in function id>`

- [ ] **Step 1: Write evidence-language tests**

```python
def test_unmatched_is_worded_as_not_reconciled_not_platform_underpayment(v3_db):
    summary = service.today(1, "2026-09-02")
    assert summary.status == "DIFFERENCE"
    assert "没对上" in summary.user_message
    assert "少给" not in summary.user_message
```

- [ ] **Step 2: Implement three headline states**

```text
OK → 暂时没发现问题
DIFFERENCE → 还有 ¥X 暂时没对上
INSUFFICIENT_DATA → 还缺平台结算/到账数据
```

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_reconciliation_summary.py tests/test_calculation_reconciliation_v2.py -q
```

---

### Task 4: 7-day trend service

**Files:**
- Create: `services/trend_service.py`
- Create: `mini/trend_routes.py`
- Test: `tests/test_trend_service.py`

**Interfaces:**
- `TrendService.get(store_id, end_date, days=7) -> TrendSummary`
- `GET /api/mini/v1/trends?days=7`

- [ ] **Step 1: Write failing tests for missing days and percentage safety**

```python
def test_trend_does_not_invent_zero_for_missing_day(v3_db):
    seed_sales(v3_db, dates=["2026-09-01", "2026-09-02"])
    trend = TrendService(v3_db).get(1, "2026-09-02", 7)
    assert trend.observed_days == 2
    assert trend.missing_days == 5
```

- [ ] **Step 2: Implement concise trend metrics**

V1 exposes sales, AOV when order_count is available, profit status/range, and one most notable issue. No fake percentage when comparison denominator is zero or sample is insufficient.

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_trend_service.py -q
```

---

### Task 5: Today Aggregator and single-call API

**Files:**
- Create: `services/today_aggregator.py`
- Create: `mini/today_routes.py`
- Modify: `mini/routes.py`
- Test: `tests/test_today_api.py`

**Interfaces:**
- `TodayAggregator.build(store_id, business_date, now) -> TodayResponse`
- `GET /api/mini/v1/today`

- [ ] **Step 1: Write failing homepage contract test**

```python
def test_today_response_contains_only_aggregated_home_contract(client, auth_headers):
    r = client.get("/api/mini/v1/today?date=2026-09-02", headers=auth_headers)
    body = r.json()
    assert {"date","as_of","sales","profit","data_status","top_issues",
            "reconciliation","pending_actions","yesterday_verification"} <= body.keys()
    assert len(body["top_issues"]) <= 3
```

- [ ] **Step 2: Implement aggregator without duplicating business logic**

Aggregator calls RevenueResolver, ProfitEngine, CompletenessService, AnomalyEngine, ReconciliationSummaryService and ActionRepository; it does not recalculate finance itself.

- [ ] **Step 3: Run Phase-3 + full regression**

```bash
python -m pytest tests/test_baseline_service.py tests/test_anomaly_engine.py tests/test_reconciliation_summary.py tests/test_trend_service.py tests/test_today_api.py -q
python -m pytest -q
```

- [ ] **Step 4: Phase-3 Gate report**

Create `docs/superpowers/gates/2026-09-02-mini-v1-phase3-gate.md` with fixture-backed homepage examples for complete and incomplete days.


---

# 食策AI Mini V1 Phase 4 — Actions, Verification, Reminder & AI Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 把“发现问题”变成可执行闭环：建议、执行记录、微信订阅提醒、次日指标验证，以及只基于结构化门店上下文的 AI 解释/文字材料。

**Architecture:** Action Engine 只消费结构化 anomaly/metric，不让 LLM 自由决定财务事实；Verification Engine 比较预先声明的目标指标，只描述“执行后相关指标变化”而不宣称因果。AI Context Service 先做 Sufficiency Gate，再把事实/估算/缺失项交给可替换文本模型。

**Tech Stack:** Python, FastAPI, SQLite, pytest, httpx, pluggable text-model provider, WeChat subscription message provider.

**Spec:** `docs/superpowers/specs/2026-09-02-shice-ai-mini-v1-design.md`

## Global Constraints
- 高风险动作只能提供步骤，未经用户确认不得自动执行第三方操作。
- `EXECUTED` 只能由用户明确“我已经做完”产生。
- 效果验证不声称因果。
- AI 不做核心算账，不把用户闲聊当结构化事实。
- 数据不足时 AI 必须返回缺失项和补数入口。

---

### Task 1: Action/verification/reminder schema and repositories

**Files:**
- Modify: `db_v3.py`
- Create: `repositories/action_repository.py`
- Test: `tests/test_action_schema.py`

**Interfaces:**
- Tables: `action_items`, `action_executions`, `action_verifications`, `reminders`, `ai_conversations`, `ai_messages`

- [ ] **Step 1: Write failing schema/state tests**

```python
def test_action_status_constraint(v3_db):
    allowed = {"PENDING","EXECUTED","SKIPPED","REMIND","WAITING_VERIFICATION","VERIFIED"}
    assert read_check_values(v3_db, "action_items", "status") == allowed
```

- [ ] **Step 2: Implement tables and repository methods**

Required repository signatures:

- `create_action(store_id: int, business_date: str, anomaly_id: int, action_type: str, title: str, reason: str, expected_metric: str, expected_direction: str, priority: int) -> dict`
- `mark_executed(action_id: int, store_id: int, executed_at: int, note: str | None = None) -> dict`
- `mark_skipped(action_id: int, store_id: int) -> dict`
- `schedule_reminder(action_id: int, user_id: int, store_id: int, scheduled_at: int) -> dict`

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_action_schema.py -q
```

---

### Task 2: Rule-based Action Engine and max-3 action policy

**Files:**
- Create: `services/action_engine.py`
- Create: `mini/action_routes.py`
- Test: `tests/test_action_engine.py`

**Interfaces:**
- `ActionEngine.generate(store_id, business_date) -> list[ActionItem]`
- Endpoints: `GET /actions`, `GET /actions/<built-in function id>`, `POST /actions/<built-in function id>/execute`, `/skip`, `/remind`

- [ ] **Step 1: Write failing action tests**

```python
def test_action_engine_returns_at_most_three_and_links_to_issue(v3_db):
    actions = ActionEngine(v3_db).generate(1, "2026-09-02")
    assert len(actions) <= 3
    assert all(a.anomaly_id for a in actions)
```

- [ ] **Step 2: Implement versioned action templates**

Start with deterministic mappings for V1 issue types such as reconciliation difference, low AOV/low-price mix, labor pressure, incomplete data. Unknown issue types may return explanation-only action; never fabricate platform UI steps.

- [ ] **Step 3: Enforce explicit execute semantics**

`POST /execute` records execution; merely opening an action or generating copy never changes status to EXECUTED.

- [ ] **Step 4: Run tests**

```bash
python -m pytest tests/test_action_engine.py -q
```

---

### Task 3: Verification Engine

**Files:**
- Create: `services/verification_engine.py`
- Test: `tests/test_verification_engine.py`

**Interfaces:**
- `VerificationEngine.verify(action_id: int, verification_date: str) -> VerificationResult`

- [ ] **Step 1: Write all four result-state tests**

```python
@pytest.mark.parametrize("before,after,expected", [
    ("28","23","IMPROVED"),
    ("28","27.8","NO_CLEAR_CHANGE"),
    ("28","32","WORSENED"),
    (None,"23","INSUFFICIENT_DATA"),
])
def test_verification_states(before, after, expected, verification_fixture):
    action_id = verification_fixture(expected_metric="LABOR_COST_RATE", expected_direction="DOWN", before=before, after=after)
    result = VerificationEngine(verification_fixture.db).verify(action_id, "2026-09-03")
    assert result.result == expected
```

- [ ] **Step 2: Implement metric-specific direction/tolerance**

Each action stores `expected_metric` and `expected_direction`; verification compares only that metric with versioned tolerance. Explanation wording must use “执行后相关指标…” not “因为这个动作导致…”.

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_verification_engine.py -q
```

---

### Task 4: WeChat subscription reminder provider

**Files:**
- Create: `notifications/provider.py`
- Create: `notifications/wechat.py`
- Create: `services/reminder_service.py`
- Test: `tests/test_reminder_service.py`

**Interfaces:**
- `NotificationProvider.send(reminder) -> SendResult`
- `ReminderService.dispatch_due(now) -> list[SendResult]`

- [ ] **Step 1: Write fake-provider tests**

```python
def test_due_reminder_is_sent_once(v3_db):
    fake = FakeNotificationProvider()
    results = ReminderService(v3_db, fake).dispatch_due(now=FIXED_TIME)
    assert len(results) == 1
    assert fake.sent[0].action_id == 1
    assert reminder_status(v3_db, 1) == "SENT"
```

- [ ] **Step 2: Implement WeChat provider using environment credentials**

Use `WECHAT_APPID`, `WECHAT_SECRET`, `WECHAT_SUBSCRIBE_TEMPLATE_ID`. Failed provider calls persist `FAILED` plus error summary; no infinite retry loop. Retry is a separate explicit scheduler run.

- [ ] **Step 3: Add a CLI/scheduler entrypoint**

Create `jobs/send_due_reminders.py` which exits non-zero on provider/system failure and prints counts for SENT/FAILED/SKIPPED.

- [ ] **Step 4: Run tests**

```bash
python -m pytest tests/test_reminder_service.py -q
```

---

### Task 5: AI Context Service and Sufficiency Gate

**Files:**
- Create: `ai/provider.py`
- Create: `services/ai_context_service.py`
- Create: `services/sufficiency_gate.py`
- Test: `tests/test_ai_context.py`

**Interfaces:**
- `AIContextService.build(store_id, question, business_date) -> AIContext`
- `SufficiencyGate.check(question_type, context) -> SufficiencyResult`

- [ ] **Step 1: Write failing context/sufficiency tests**

```python
def test_labor_question_without_labor_data_is_blocked(v3_db):
    ctx = AIContextService(v3_db).build(1, "我今天人工是不是太高？", "2026-09-02")
    gate = SufficiencyGate().check("LABOR_DIAGNOSIS", ctx)
    assert gate.sufficient is False
    assert "人工" in gate.missing_data
```

- [ ] **Step 2: Implement structured context**

```python
@dataclass(frozen=True)
class AIContext:
    facts: dict
    estimates: dict
    missing_data: Sequence[str]
    anomalies: Sequence[dict]
    recent_actions: Sequence[dict]
```

Never include legacy free-form chat as a financial fact source.

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_ai_context.py -q
```

---

### Task 6: AI chat and text execution-material endpoints

**Files:**
- Create: `ai/text_service.py`
- Create: `mini/ai_routes.py`
- Modify: `mini/action_routes.py`
- Test: `tests/test_ai_routes.py`

**Interfaces:**
- `POST /api/mini/v1/ai/chat`
- `POST /api/mini/v1/actions/<built-in function id>/generate-copy`

- [ ] **Step 1: Write failing provider-independent tests**

```python
def test_ai_chat_returns_missing_data_without_calling_model(client, auth_headers, fake_text_provider):
    r = client.post("/api/mini/v1/ai/chat", headers=auth_headers,
                    json={"question":"我今天人工是不是太高？","date":"2026-09-02"})
    assert r.json()["status"] == "NEEDS_DATA"
    assert fake_text_provider.calls == []
```

- [ ] **Step 2: Implement model provider interface**

The provider contract is the exact method `TextModelProvider.generate(system: str, user: str) -> str`; tests inject a deterministic fake implementation, while production configuration selects the real provider adapter.

Provider input is generated from facts/estimates/missing/anomalies only. Prompt explicitly forbids inventing numbers and asks for plain-language output.

- [ ] **Step 3: Implement copy-generation templates**

V1 supported outputs: `WECHAT_GROUP`, `MOMENTS`, `XIAOHONGSHU`, `DOUYIN_CAPTION`, `ACTIVITY_PLAN`. The response is draft material only; no auto-publish action exists.

- [ ] **Step 4: Run Phase-4 + full regression**

```bash
python -m pytest tests/test_action_schema.py tests/test_action_engine.py tests/test_verification_engine.py tests/test_reminder_service.py tests/test_ai_context.py tests/test_ai_routes.py -q
python -m pytest -q
```

- [ ] **Step 5: Phase-4 Gate report**

Create `docs/superpowers/gates/2026-09-02-mini-v1-phase4-gate.md` including one full fixture story: anomaly → action → executed → reminder → next-day verification.


---

# 食策AI Mini V1 Phase 5 — Native Mini Program & E2E Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 交付老板可实际操作的原生微信小程序：欢迎/Demo、今天、待办、上传、我的、利润/异常/对账详情、OCR确认与 AI 追问，并通过 DevTools + 真机 E2E Gate。

**Architecture:** 前端只消费 `/api/mini/v1/*`，不直接理解 V2 财务表。4 个 Tab 固定为“今天 / 待办 / 上传 / 我的”；“问食策AI”是辅助入口。API client 统一处理 token、超时、401、后端错误和 loading/error/empty 状态。

**Tech Stack:** Native WeChat Mini Program, WXML, WXSS, JavaScript, WeChat DevTools, Python API contract tests.

**Spec:** `docs/superpowers/specs/2026-09-02-shice-ai-mini-v1-design.md`

## Global Constraints
- 不把网页版菜单搬进小程序。
- 首页第一屏结论优先；专业术语默认隐藏。
- 所有估算利润显示区间，不显示伪精确单点。
- OCR 低可信字段必须在确认页可见。
- Tab 固定为 4 个：今天、待办、上传、我的。
- V1 不做图片生成和自动发布。

---

### Task 1: Native project scaffold and API client

**Files:**
- Create: `miniprogram/project.config.json`
- Create: `miniprogram/app.js`
- Create: `miniprogram/app.json`
- Create: `miniprogram/app.wxss`
- Create: `miniprogram/utils/api.js`
- Create: `miniprogram/utils/session.js`
- Test: `tests/test_miniprogram_static_contract.py`

**Interfaces:**
- `api.request({path, method, data, filePath})` automatically attaches Bearer token.
- `session.login()` uses `wx.login()` then `/auth/wechat`.

- [ ] **Step 1: Write static contract test**

```python
def test_tabbar_has_exact_four_tabs(project_root):
    app = json.loads((project_root / "miniprogram/app.json").read_text("utf-8"))
    assert [x["text"] for x in app["tabBar"]["list"]] == ["今天","待办","上传","我的"]
```

- [ ] **Step 2: Create scaffold with no third-party UI framework**

`app.json` declares only the V1 pages. API base URL is injected through `miniprogram/config.js`; no localhost URL is hard-coded for release.

- [ ] **Step 3: Run static test + JS syntax check**

```bash
python -m pytest tests/test_miniprogram_static_contract.py -q
node --check miniprogram/app.js
node --check miniprogram/utils/api.js
```

---

### Task 2: Welcome, Demo, and onboarding pages

**Files:**
- Create: `miniprogram/pages/welcome/*`
- Create: `miniprogram/pages/onboarding/*`
- Create: `miniprogram/pages/demo/*`
- Test: `tests/test_miniprogram_copy_contract.py`

**Interfaces:**
- Welcome buttons: `开始管理我的店`, `先看看食策AI能做什么`
- Onboarding fields: store name + one category selection only.

- [ ] **Step 1: Write copy/scope tests**

```python
def test_onboarding_does_not_require_city_rent_or_staff(read_wxml):
    text = read_wxml("pages/onboarding/onboarding.wxml")
    assert "门店名称" in text and "主营" in text
    assert "房租" not in text and "员工人数" not in text and "城市" not in text
```

- [ ] **Step 2: Implement pages and auth flow**

Demo uses a backend demo session or bundled read-only demo payload; no demo interaction may write the user's real store.

- [ ] **Step 3: Syntax/static tests**

```bash
python -m pytest tests/test_miniprogram_copy_contract.py -q
```

---

### Task 3: Today page and drill-down details

**Files:**
- Create: `miniprogram/pages/today/*`
- Create: `miniprogram/pages/profit-detail/*`
- Create: `miniprogram/pages/issue-detail/*`
- Create: `miniprogram/pages/reconciliation-detail/*`
- Create: `miniprogram/pages/trends/*`

**Interfaces:**
- Today loads only `/today` for first render.
- Detail pages call their dedicated Mini endpoints.

- [ ] **Step 1: Implement required states before styling polish**

Today must render all of:

```text
LOADING
READY_COMPLETE
READY_INCOMPLETE
NO_DATA
ERROR_RETRYABLE
```

Profit supports `ACTUAL_BASED`, `ESTIMATED_RANGE`, `UNAVAILABLE`.

- [ ] **Step 2: Implement copy rules**

Examples:

```text
ESTIMATED_RANGE → 今天估计赚 ¥820～¥1,180
UNAVAILABLE → 今天还算不了赚多少钱；先告诉我今天卖了多少
DIFFERENCE → 还有 ¥386 暂时没对上
```

- [ ] **Step 3: Add static assertions for max Top-3 rendering and no forbidden jargon**

```bash
python -m pytest tests/test_miniprogram_static_contract.py tests/test_miniprogram_copy_contract.py -q
```

---

### Task 4: Upload page, image/file selection, and OCR confirmation UI

**Files:**
- Create: `miniprogram/pages/upload/*`
- Create: `miniprogram/pages/upload-confirm/*`
- Create: `miniprogram/pages/manual-entry/*`

**Interfaces:**
- Buttons: `拍照`, `选截图`, `选文件`, `手动填写`
- Confirm page supports field edit and explicit final `确认没问题`.

- [ ] **Step 1: Implement upload methods using native APIs**

Use `wx.chooseMedia` for camera/gallery and `wx.chooseMessageFile` for CSV/XLSX. Upload first returns draft status; never navigate straight to success before confirm.

- [ ] **Step 2: Implement low-confidence emphasis without hiding values**

Fields below the backend confidence threshold receive `需要确认` state and a direct edit control.

- [ ] **Step 3: Implement possible-duplicate decision UI**

Show plain language choices:

```text
更新之前的数据
这是另一份数据
```

Only show the second choice when backend says separate records are semantically valid.

---

### Task 5: Tasks page and subscription-message request

**Files:**
- Create: `miniprogram/pages/actions/*`
- Create: `miniprogram/pages/action-detail/*`

**Interfaces:**
- Actions: `看看具体怎么做`, `暂不做`, `明天提醒`, `我已经做完`

- [ ] **Step 1: Implement status sections**

```text
今天建议做
等待验证
已完成（折叠）
```

- [ ] **Step 2: Implement `明天提醒` correctly**

Call `wx.requestSubscribeMessage` first. Only when the user accepts should frontend call `/actions/<built-in function id>/remind`. Rejection keeps the action unchanged and shows a non-blocking explanation.

- [ ] **Step 3: Implement generated text-material view**

V1 supports text outputs only; there is no `生成宣传图` functional button in V1.

---

### Task 6: Profile/cost-improvement and AI chat pages

**Files:**
- Create: `miniprogram/pages/profile/*`
- Create: `miniprogram/pages/cost-profile/*`
- Create: `miniprogram/pages/chat/*`

**Interfaces:**
- Profile headline includes profit accuracy and `让结果更准`.
- Cost flow asks for city only when labor estimation needs it.
- Chat handles `NEEDS_DATA` with a direct补数据 action.

- [ ] **Step 1: Implement progressive disclosure**

Do not show all cost fields at once. The backend profile endpoint identifies highest-value missing inputs; UI renders them in priority order.

- [ ] **Step 2: Implement AI chat states**

`NEEDS_DATA` is a first-class state, not an error. Model/network errors show retry; financial facts already loaded remain visible.

---

### Task 7: DevTools, real provider, and end-to-end acceptance

**Files:**
- Create: `docs/superpowers/gates/2026-09-02-mini-v1-e2e-checklist.md`
- Create: `tests/test_mini_v1_acceptance_api.py`

**Interfaces:**
- Acceptance scenario follows Spec §41 exactly.

- [ ] **Step 1: Build a backend fixture acceptance test**

The test must perform: login → create MILK_TEA store → image draft → correct/confirm → add manual labor/cost input → `/today` → top issue → action execute → reminder → next-day data → verification.

- [ ] **Step 2: Configure one real RecognitionProvider for pilot**

The provider must implement the Phase-2 interface and pass a fixture set of real screenshots with human-reviewed expected fields. Provider credentials stay in environment variables and never enter source files or exported screenshots.

- [ ] **Step 3: WeChat DevTools smoke**

Verify on at least one normal-width phone profile and one narrow phone profile:
- welcome/onboarding
- Today complete/incomplete
- image upload + confirm
- manual entry
- actions/reminder permission flow
- profile
- AI NEEDS_DATA

Record screenshots or checklist evidence; do not mark untested flows PASS.

- [ ] **Step 4: Real-device pilot smoke**

Backend must be reachable through HTTPS and configured as a legal request/upload domain. Verify `wx.login`, image upload, message-file selection, and subscription-message authorization on an actual WeChat device.

- [ ] **Step 5: Run complete automated suite**

```bash
python -m pytest -q
python -m compileall .
find miniprogram -name '*.js' -print0 | xargs -0 -n1 node --check
```

Expected: all tests PASS, compile PASS, all JS syntax checks PASS.

- [ ] **Step 6: Final V1 Gate report**

Create `docs/superpowers/gates/2026-09-02-mini-v1-final-gate.md` containing exact automated test count, DevTools evidence, real-device evidence, recognition fixture accuracy summary, known limitations, and explicit PASS/FAIL per V1 acceptance scenario. Never substitute mock-provider success for real screenshot acceptance.

- [ ] **Step 7: Delivery package**

Generate ZIP from the verified source tree plus SHA256 manifest. Keep prior R1 audit/history. Do not overwrite the last known-good R1 delivery artifact.


---

