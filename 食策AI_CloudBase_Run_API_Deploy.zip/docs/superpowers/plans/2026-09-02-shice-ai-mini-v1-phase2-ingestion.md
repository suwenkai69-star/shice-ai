# 食策AI Mini V1 Phase 2 — Ingestion & Recognition Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 交付统一“上传数据”后端：手动填写、CSV/XLSX、图片识别草稿、用户确认、正式导入、防重复与每日数据完整度。

**Architecture:** 所有输入先进入 Mini ingestion staging；图片识别永远只生成 draft。确认后 `MiniImportAdapter` 才调用现有 V2 importer 或 whole-store repository，确保原始证据链与 R1 fail-closed 原则保持完整。

**Tech Stack:** FastAPI, SQLite, pytest, openpyxl, pluggable RecognitionProvider.

**Spec:** `docs/superpowers/specs/2026-09-02-shice-ai-mini-v1-design.md`

## Global Constraints

- OCR/Vision 不直接写 `daily_channel_sales / settlements / payments`。
- 低可信字段必须可单独修改后确认。
- 同日累计更新不得重复累计。
- 不确定重复关系时返回 `POSSIBLE_DUPLICATE`，由用户选择。
- 空 CSV、坏 JSON/XLSX、无法识别文件仍必须留下可审计失败记录。
- V1 首批平台模板：美团外卖、淘宝闪购、京东外卖、抖音本地生活、美团团购、微信、支付宝、常见 POS 日报。

---

### Task 1: Phase-2 Schema tables and repositories

**Files:**
- Modify: `db_v3.py`
- Create: `repositories/upload_repository.py`
- Create: `repositories/data_status_repository.py`
- Test: `tests/test_ingestion_schema.py`

**Interfaces:**
- Tables: `upload_documents`, `extraction_jobs`, `extracted_fields`, `document_import_links`, `store_data_sources`, `daily_data_status`

- [ ] **Step 1: Write failing schema tests**

```python
def test_ingestion_tables_exist(v3_db):
    required = {"upload_documents","extraction_jobs","extracted_fields",
                "document_import_links","store_data_sources","daily_data_status"}
    assert required.issubset(table_names(v3_db))
```

- [ ] **Step 2: Run and verify failure**

```bash
python -m pytest tests/test_ingestion_schema.py -q
```

- [ ] **Step 3: Add additive V3 table creation**

All tables include `store_id` where relevant. `upload_documents.status` is constrained to:

```text
UPLOADED, PROCESSING, NEEDS_CONFIRMATION, CONFIRMED, IMPORTED, FAILED
```

`extracted_fields` stores `raw_text`, `normalized_value`, `confidence`, `user_corrected`, `confirmed_value`.

- [ ] **Step 4: Implement repositories and rerun tests**

```bash
python -m pytest tests/test_ingestion_schema.py -q
```

---

### Task 2: Manual data endpoints with explicit scope

**Files:**
- Create: `mini/manual_routes.py`
- Create: `services/manual_ingestion.py`
- Modify: `mini/routes.py`
- Test: `tests/test_manual_ingestion_api.py`

**Interfaces:**
- `POST /api/mini/v1/manual/sales`
- `POST /api/mini/v1/manual/cost`
- `POST /api/mini/v1/manual/payment`

- [ ] **Step 1: Write failing tests for whole-store and channel sales**

```python
def test_manual_whole_store_sale_does_not_create_fake_channel(client, auth_headers):
    r = client.post("/api/mini/v1/manual/sales", headers=auth_headers, json={
        "business_date":"2026-09-02", "scope":"WHOLE_STORE", "gross_sales":"1000.00"
    })
    assert r.status_code == 200
    assert r.json()["record"]["scope"] == "WHOLE_STORE"


def test_manual_channel_sale_requires_channel_code(client, auth_headers):
    r = client.post("/api/mini/v1/manual/sales", headers=auth_headers, json={
        "business_date":"2026-09-02", "scope":"CHANNEL", "gross_sales":"1000.00"
    })
    assert r.status_code == 422
```

- [ ] **Step 2: Implement explicit `WHOLE_STORE|CHANNEL` contract and Decimal validation**

Channel sales use existing V2 normalization where possible; whole-store totals write only `daily_store_sales_totals`.

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_manual_ingestion_api.py -q
```

---

### Task 3: CSV/XLSX preview-confirm pipeline

**Files:**
- Modify: `requirements.txt`
- Create: `services/file_preview.py`
- Create: `services/mini_import_adapter.py`
- Create: `mini/upload_routes.py`
- Test: `tests/test_file_upload_pipeline.py`

**Interfaces:**
- `POST /api/mini/v1/uploads/file` → draft summary
- `GET /api/mini/v1/uploads/<built-in function id>`
- `POST /api/mini/v1/uploads/<built-in function id>/confirm`
- `POST /api/mini/v1/uploads/<built-in function id>/reject`

- [ ] **Step 1: Write failing CSV and XLSX tests**

```python
def test_file_upload_is_preview_only_until_confirmed(client, auth_headers):
    upload = client.post("/api/mini/v1/uploads/file", headers=auth_headers,
        files={"file": ("sales.csv", SALES_CSV, "text/csv")})
    assert upload.json()["status"] == "NEEDS_CONFIRMATION"
    assert client.get("/api/v2/sales/daily?store_id=1").json()["sales"] == []
    confirm = client.post(f"/api/mini/v1/uploads/{upload.json()['id']}/confirm", headers=auth_headers)
    assert confirm.status_code == 200
    assert len(client.get("/api/v2/sales/daily?store_id=1").json()["sales"]) == 1
```

Also test malformed XLSX → FAILED document with error code; GB18030 CSV continues to work.

- [ ] **Step 2: Add `openpyxl>=3.1` and implement read-only XLSX parsing**

Do not execute formulas/macros. Accept `.xlsx` only; reject `.xls` with a clear user-facing error.

- [ ] **Step 3: Implement MiniImportAdapter**

Implement the exact method `MiniImportAdapter.import_confirmed_document(document_id: int, store_id: int) -> ImportOutcome`.

The adapter creates `document_import_links` to `import_file_id/import_batch_id` or whole-store record id after successful import.

- [ ] **Step 4: Run tests**

```bash
python -m pytest tests/test_file_upload_pipeline.py tests/test_data_integrity_r1.py -q
```

---

### Task 4: RecognitionProvider and platform-template parsing

**Files:**
- Create: `recognition/__init__.py`
- Create: `recognition/provider.py`
- Create: `recognition/templates.py`
- Create: `recognition/service.py`
- Create: `recognition/providers/fake.py`
- Test: `tests/test_recognition_service.py`

**Interfaces:**
- `RecognitionProvider.recognize(image_bytes: bytes) -> RecognitionDocument`
- `RecognitionService.create_draft(document_id: int) -> ExtractionDraft`
- Template IDs exactly versioned, e.g. `MEITUAN_DELIVERY_DAILY_V1` and `TAOBAO_FLASH_DAILY_V1`.

- [ ] **Step 1: Write failing service tests with deterministic fake provider**

```python
def test_recognition_creates_draft_not_business_fact(v3_db):
    service = RecognitionService(v3_db, provider=FakeRecognitionProvider({
        "platform":"MEITUAN_DELIVERY", "page_type":"DAILY_REPORT",
        "fields":{"GROSS_SALES":{"value":"3860.00","confidence":0.98},
                  "PLATFORM_FEE":{"value":"426.00","confidence":0.61}}
    }))
    draft = service.create_draft(seed_image_document(v3_db))
    assert draft.status == "NEEDS_CONFIRMATION"
    assert get_daily_sales_count(v3_db) == 0
    assert any(f.confidence < 0.70 for f in draft.fields)
```

- [ ] **Step 2: Implement provider-neutral normalized output**

Unknown platform/page → `UNKNOWN_PLATFORM`/`UNKNOWN_PAGE`; recognized text without semantic mapping remains an unconfirmed field, never guessed into financial semantics.

- [ ] **Step 3: Implement initial template label maps**

Each template defines required labels, aliases, output field codes, and whether the report is cumulative or interval-based. Do not encode a field mapping unless test fixtures prove the label semantics.

- [ ] **Step 4: Run recognition unit tests**

```bash
python -m pytest tests/test_recognition_service.py -q
```

---

### Task 5: Image upload, field correction, and confirm wall

**Files:**
- Modify: `mini/upload_routes.py`
- Create: `mini/extraction_models.py`
- Test: `tests/test_image_confirm_api.py`

**Interfaces:**
- `POST /api/mini/v1/uploads/image`
- `PATCH /api/mini/v1/uploads/<built-in function id>/fields`
- `POST /api/mini/v1/uploads/<built-in function id>/confirm`

- [ ] **Step 1: Write failing API test**

```python
def test_low_confidence_field_can_be_corrected_before_import(client, auth_headers, fake_recognition):
    upload = upload_test_image(client, auth_headers)
    doc_id = upload.json()["id"]
    patch = client.patch(f"/api/mini/v1/uploads/{doc_id}/fields", headers=auth_headers,
        json={"fields":[{"field_code":"PLATFORM_FEE","confirmed_value":"406.00"}]})
    assert patch.status_code == 200
    confirmed = client.post(f"/api/mini/v1/uploads/{doc_id}/confirm", headers=auth_headers)
    assert confirmed.json()["status"] == "IMPORTED"
```

- [ ] **Step 2: Implement validation**

Money/date/count fields normalize using the same R1 helpers where possible. Missing required fields prevent confirm; optional low-confidence fields may be explicitly excluded by user.

- [ ] **Step 3: Run tests**

```bash
python -m pytest tests/test_image_confirm_api.py -q
```

---

### Task 6: Duplicate/update detection for same-day cumulative reports

**Files:**
- Create: `services/duplicate_detection.py`
- Modify: `services/mini_import_adapter.py`
- Test: `tests/test_duplicate_detection.py`

**Interfaces:**
- `DuplicateDetectionService.classify(candidate, existing) -> NEW|UPDATE|POSSIBLE_DUPLICATE`

- [ ] **Step 1: Write failing scenarios**

```python
def test_later_cumulative_report_updates_instead_of_adds():
    existing = report("MEITUAN_DELIVERY", "2026-09-02", "14:00", "2000.00", cumulative=True)
    later = report("MEITUAN_DELIVERY", "2026-09-02", "20:00", "4800.00", cumulative=True)
    assert classify(later, existing) == "UPDATE"


def test_ambiguous_same_day_report_requires_user_choice():
    assert classify(ambiguous_report(), existing_report()) == "POSSIBLE_DUPLICATE"
```

- [ ] **Step 2: Implement classification using store/channel/date/template/time-range/reference**

Never infer UPDATE from amount alone.

- [ ] **Step 3: Expose conflict response and user decision endpoint**

`409` response includes choices `REPLACE_EXISTING` and `TREAT_AS_SEPARATE`; only valid where data scope semantics allow separate records.

- [ ] **Step 4: Run tests**

```bash
python -m pytest tests/test_duplicate_detection.py -q
```

---

### Task 7: Data completeness learning and manual completion

**Files:**
- Create: `services/completeness_service.py`
- Create: `mini/data_status_routes.py`
- Modify: `mini/routes.py`
- Test: `tests/test_completeness_service.py`

**Interfaces:**
- `CompletenessService.get_status(store_id, business_date) -> DataStatus`
- `POST /api/mini/v1/data-status/today/complete`

- [ ] **Step 1: Write failing tests**

```python
def test_repeated_sources_become_expected_after_history(v3_db):
    seed_source_presence(v3_db, store_id=1, channel="MEITUAN_DELIVERY", days=14, recent_30d=14)
    status = CompletenessService(v3_db).get_status(1, "2026-09-02")
    assert "MEITUAN_DELIVERY" in status.expected_sources


def test_user_can_declare_day_complete(v3_db):
    service = CompletenessService(v3_db)
    service.declare_complete(1, "2026-09-02")
    assert service.get_status(1, "2026-09-02").user_declared_complete is True
```

- [ ] **Step 2: Implement explicit expectation rule**

A source becomes expected when it appeared on at least 5 of the last 7 operating days or 12 of the last 30 days. This threshold is versioned as `COMPLETENESS_V1` so it can change later without rewriting history.

- [ ] **Step 3: Run Phase-2 suite and full regression**

```bash
python -m pytest tests/test_ingestion_schema.py tests/test_manual_ingestion_api.py tests/test_file_upload_pipeline.py tests/test_recognition_service.py tests/test_image_confirm_api.py tests/test_duplicate_detection.py tests/test_completeness_service.py -q
python -m pytest -q
```

- [ ] **Step 4: Phase-2 Gate report**

Create `docs/superpowers/gates/2026-09-02-mini-v1-phase2-gate.md`; explicitly separate deterministic fake-provider test PASS from real-provider/real-screenshot acceptance, which is completed in Phase 5 before release.
