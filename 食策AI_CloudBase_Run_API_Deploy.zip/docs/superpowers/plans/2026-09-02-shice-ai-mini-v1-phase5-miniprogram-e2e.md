# 食策AI Mini V1 Phase 5 — Native Mini Program & E2E Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 交付老板可实际操作的原生微信小程序：欢迎/Demo、今天、待办、上传、我的、利润/异常/对账详情、OCR确认与 AI 追问，并通过 DevTools + 真机 E2E Gate。

**Architecture:** 前端只消费 `/api/mini/v1/*`，不直接理解 V2 财务表。4 个 Tab 固定为“今天 / 待办 / 上传 / 我的”；“问食策AI”是辅助入口。API client 统一处理 token、超时、401、后端错误和 loading/error/empty 状态。

**Tech Stack:** Native WeChat Mini Program, WXML, WXSS, JavaScript, WeChat DevTools, Python API contract tests.

**Spec:** `docs/superpowers/specs/2026-09-02-shice-ai-mini-v1-design.md`

## Global Constraints
- 不把网页版菜单搬进小程序。
- 首页第一屏结论优先；专业术语默认隐藏。
- 所有估算利润显示区间，不显示伪精确单点。
- OCR 低可信字段必须在确认页可见。
- Tab 固定为 4 个：今天、待办、上传、我的。
- V1 不做图片生成和自动发布。

---

### Task 1: Native project scaffold and API client

**Files:**
- Create: `miniprogram/project.config.json`
- Create: `miniprogram/app.js`
- Create: `miniprogram/app.json`
- Create: `miniprogram/app.wxss`
- Create: `miniprogram/utils/api.js`
- Create: `miniprogram/utils/session.js`
- Test: `tests/test_miniprogram_static_contract.py`

**Interfaces:**
- `api.request({path, method, data, filePath})` automatically attaches Bearer token.
- `session.login()` uses `wx.login()` then `/auth/wechat`.

- [ ] **Step 1: Write static contract test**

```python
def test_tabbar_has_exact_four_tabs(project_root):
    app = json.loads((project_root / "miniprogram/app.json").read_text("utf-8"))
    assert [x["text"] for x in app["tabBar"]["list"]] == ["今天","待办","上传","我的"]
```

- [ ] **Step 2: Create scaffold with no third-party UI framework**

`app.json` declares only the V1 pages. API base URL is injected through `miniprogram/config.js`; no localhost URL is hard-coded for release.

- [ ] **Step 3: Run static test + JS syntax check**

```bash
python -m pytest tests/test_miniprogram_static_contract.py -q
node --check miniprogram/app.js
node --check miniprogram/utils/api.js
```

---

### Task 2: Welcome, Demo, and onboarding pages

**Files:**
- Create: `miniprogram/pages/welcome/*`
- Create: `miniprogram/pages/onboarding/*`
- Create: `miniprogram/pages/demo/*`
- Test: `tests/test_miniprogram_copy_contract.py`

**Interfaces:**
- Welcome buttons: `开始管理我的店`, `先看看食策AI能做什么`
- Onboarding fields: store name + one category selection only.

- [ ] **Step 1: Write copy/scope tests**

```python
def test_onboarding_does_not_require_city_rent_or_staff(read_wxml):
    text = read_wxml("pages/onboarding/onboarding.wxml")
    assert "门店名称" in text and "主营" in text
    assert "房租" not in text and "员工人数" not in text and "城市" not in text
```

- [ ] **Step 2: Implement pages and auth flow**

Demo uses a backend demo session or bundled read-only demo payload; no demo interaction may write the user's real store.

- [ ] **Step 3: Syntax/static tests**

```bash
python -m pytest tests/test_miniprogram_copy_contract.py -q
```

---

### Task 3: Today page and drill-down details

**Files:**
- Create: `miniprogram/pages/today/*`
- Create: `miniprogram/pages/profit-detail/*`
- Create: `miniprogram/pages/issue-detail/*`
- Create: `miniprogram/pages/reconciliation-detail/*`
- Create: `miniprogram/pages/trends/*`

**Interfaces:**
- Today loads only `/today` for first render.
- Detail pages call their dedicated Mini endpoints.

- [ ] **Step 1: Implement required states before styling polish**

Today must render all of:

```text
LOADING
READY_COMPLETE
READY_INCOMPLETE
NO_DATA
ERROR_RETRYABLE
```

Profit supports `ACTUAL_BASED`, `ESTIMATED_RANGE`, `UNAVAILABLE`.

- [ ] **Step 2: Implement copy rules**

Examples:

```text
ESTIMATED_RANGE → 今天估计赚 ¥820～¥1,180
UNAVAILABLE → 今天还算不了赚多少钱；先告诉我今天卖了多少
DIFFERENCE → 还有 ¥386 暂时没对上
```

- [ ] **Step 3: Add static assertions for max Top-3 rendering and no forbidden jargon**

```bash
python -m pytest tests/test_miniprogram_static_contract.py tests/test_miniprogram_copy_contract.py -q
```

---

### Task 4: Upload page, image/file selection, and OCR confirmation UI

**Files:**
- Create: `miniprogram/pages/upload/*`
- Create: `miniprogram/pages/upload-confirm/*`
- Create: `miniprogram/pages/manual-entry/*`

**Interfaces:**
- Buttons: `拍照`, `选截图`, `选文件`, `手动填写`
- Confirm page supports field edit and explicit final `确认没问题`.

- [ ] **Step 1: Implement upload methods using native APIs**

Use `wx.chooseMedia` for camera/gallery and `wx.chooseMessageFile` for CSV/XLSX. Upload first returns draft status; never navigate straight to success before confirm.

- [ ] **Step 2: Implement low-confidence emphasis without hiding values**

Fields below the backend confidence threshold receive `需要确认` state and a direct edit control.

- [ ] **Step 3: Implement possible-duplicate decision UI**

Show plain language choices:

```text
更新之前的数据
这是另一份数据
```

Only show the second choice when backend says separate records are semantically valid.

---

### Task 5: Tasks page and subscription-message request

**Files:**
- Create: `miniprogram/pages/actions/*`
- Create: `miniprogram/pages/action-detail/*`

**Interfaces:**
- Actions: `看看具体怎么做`, `暂不做`, `明天提醒`, `我已经做完`

- [ ] **Step 1: Implement status sections**

```text
今天建议做
等待验证
已完成（折叠）
```

- [ ] **Step 2: Implement `明天提醒` correctly**

Call `wx.requestSubscribeMessage` first. Only when the user accepts should frontend call `/actions/<built-in function id>/remind`. Rejection keeps the action unchanged and shows a non-blocking explanation.

- [ ] **Step 3: Implement generated text-material view**

V1 supports text outputs only; there is no `生成宣传图` functional button in V1.

---

### Task 6: Profile/cost-improvement and AI chat pages

**Files:**
- Create: `miniprogram/pages/profile/*`
- Create: `miniprogram/pages/cost-profile/*`
- Create: `miniprogram/pages/chat/*`

**Interfaces:**
- Profile headline includes profit accuracy and `让结果更准`.
- Cost flow asks for city only when labor estimation needs it.
- Chat handles `NEEDS_DATA` with a direct补数据 action.

- [ ] **Step 1: Implement progressive disclosure**

Do not show all cost fields at once. The backend profile endpoint identifies highest-value missing inputs; UI renders them in priority order.

- [ ] **Step 2: Implement AI chat states**

`NEEDS_DATA` is a first-class state, not an error. Model/network errors show retry; financial facts already loaded remain visible.

---

### Task 7: DevTools, real provider, and end-to-end acceptance

**Files:**
- Create: `docs/superpowers/gates/2026-09-02-mini-v1-e2e-checklist.md`
- Create: `tests/test_mini_v1_acceptance_api.py`

**Interfaces:**
- Acceptance scenario follows Spec §41 exactly.

- [ ] **Step 1: Build a backend fixture acceptance test**

The test must perform: login → create MILK_TEA store → image draft → correct/confirm → add manual labor/cost input → `/today` → top issue → action execute → reminder → next-day data → verification.

- [ ] **Step 2: Configure one real RecognitionProvider for pilot**

The provider must implement the Phase-2 interface and pass a fixture set of real screenshots with human-reviewed expected fields. Provider credentials stay in environment variables and never enter source files or exported screenshots.

- [ ] **Step 3: WeChat DevTools smoke**

Verify on at least one normal-width phone profile and one narrow phone profile:
- welcome/onboarding
- Today complete/incomplete
- image upload + confirm
- manual entry
- actions/reminder permission flow
- profile
- AI NEEDS_DATA

Record screenshots or checklist evidence; do not mark untested flows PASS.

- [ ] **Step 4: Real-device pilot smoke**

Backend must be reachable through HTTPS and configured as a legal request/upload domain. Verify `wx.login`, image upload, message-file selection, and subscription-message authorization on an actual WeChat device.

- [ ] **Step 5: Run complete automated suite**

```bash
python -m pytest -q
python -m compileall .
find miniprogram -name '*.js' -print0 | xargs -0 -n1 node --check
```

Expected: all tests PASS, compile PASS, all JS syntax checks PASS.

- [ ] **Step 6: Final V1 Gate report**

Create `docs/superpowers/gates/2026-09-02-mini-v1-final-gate.md` containing exact automated test count, DevTools evidence, real-device evidence, recognition fixture accuracy summary, known limitations, and explicit PASS/FAIL per V1 acceptance scenario. Never substitute mock-provider success for real screenshot acceptance.

- [ ] **Step 7: Delivery package**

Generate ZIP from the verified source tree plus SHA256 manifest. Keep prior R1 audit/history. Do not overwrite the last known-good R1 delivery artifact.
