# 食策AI V0.5.0 Data Foundation Design

## Goal
Upgrade the existing V0.4 FastAPI + SQLite engineering prototype in place so it can safely represent multi-channel daily sales, platform settlements, actual payments, fee details, import provenance, and future reconciliation without breaking any V0.4 API, page, demo, upload flow, or local fallback behavior.

## Scope
V0.5.0 is Data Foundation only. It does not perform a UI rewrite, AI rewrite, tax/invoice work, BOM/inventory work, platform API/RPA synchronization, CRM, or automatic marketing publishing.

## Architecture
Keep `app.py` as the existing V0.4 application entry point and add focused V0.5.0 modules:

- `db_v2.py`: schema versioning, transactional migration, channel seed, Decimal persistence helpers.
- `data_foundation.py`: import pipeline, normalization, deduplication, provenance, settlement/payment persistence, calculation profiles, reconciliation and legacy adapter.
- `app.py`: preserve all existing routes and add thin `/api/v2/*` HTTP adapters.

The existing `app_state` remains the compatibility source for V0.4 pages. Schema V2 is additive. A compatibility adapter can overwrite only legacy fields that Schema V2 can prove, while retaining legacy values for fields that V2 cannot currently derive.

## Money semantics
All business calculations use Python `Decimal`. To avoid SQLite binary-float ambiguity, monetary values in new V2 tables are stored as canonical decimal strings with two fractional digits. The service layer converts them to/from `Decimal`; no V2 financial arithmetic uses Python `float` or JavaScript arithmetic.

Fees and refunds are stored as positive magnitudes. Addition/subtraction is decided centrally by calculation profiles. Platform subsidy is never assumed to be a universal add or subtract item.

## Provenance
Each upload attempt creates an `import_batches` row. File identity is represented by `import_files` so `source_file_id` fields are real foreign keys. Each parsed input row is retained in `raw_import_rows`. Normalized rows link back to their batch/raw row wherever one-to-one provenance is meaningful.

Traceability chain:

`normalized record -> raw_import_row -> import_batch -> import_file metadata`

## Idempotency
- Daily sales unique key: `(store_id, business_date, channel_id)`. Re-upload overwrites/upserts the same logical day/channel record and never accumulates gross sales.
- Settlements have a stable `settlement_fingerprint` generated from a reliable reference when present, otherwise from store/channel/period/date. Re-upload updates or skips, never duplicates the logical settlement.
- Payments have a stable `payment_fingerprint` based on bank reference where reliable, otherwise store/channel/date/amount/settlement reference/source.
- Every upload attempt is still audited as its own import batch, including duplicates.

## Reconciliation
`reconciliation_matches` is many-to-many between settlements and payments. V0.5.0 supports reference-based matching and explicit match records, but does not attempt complex probabilistic matching.

Statuses:
- MATCHED
- SMALL_DIFFERENCE
- UNMATCHED
- MISSING_PAYMENT
- MISSING_SETTLEMENT

Threshold lives in backend configuration, not the page.

## UX constraint
No large UI changes in V0.5.0. Backend/API naming may be professional, but future user-facing copy must follow the locked product principle: bottom layer professional, top layer simple; conclusion first, reason second, details last.

## Compatibility
Existing `users`, `stores`, `app_state`, and `uploads` are preserved. The existing `stores` table is extended in place with `store_type`, `timezone`, `currency`, `created_at`, and `updated_at`; the old `type` and `user_id` fields remain for V0.4 compatibility.

Existing `/api/state`, `/api/upload/*`, `/api/ask`, `/api/marketing`, demo routes, and `static/index.html` remain functional.

## Acceptance gates
1. Existing V0.4 database upgrades in place without deletion.
2. Migration is idempotent and rollback-safe.
3. Repeated sales/payment/settlement uploads do not double count.
4. All normalized data is traceable to upload batch/raw rows/file metadata.
5. V0.4 APIs and front-end entry remain available.
6. Automated tests pass.
