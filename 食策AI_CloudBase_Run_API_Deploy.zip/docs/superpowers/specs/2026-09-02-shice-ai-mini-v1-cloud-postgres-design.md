# 食策AI Mini V1 云端 PostgreSQL + Vercel 设计规格

**日期：** 2026-09-02  
**状态：** 已完成对话级设计确认，待书面规格复核后进入实施计划  
**基线：** 食策AI Mini V1 RC / `0.5.0-R1+MiniV1` / Schema V3  
**目标平台：** 微信小程序 + Vercel FastAPI + Neon PostgreSQL

---

## 1. 背景与问题

Mini V1 RC 已完成本地 SQLite 版本的自动化 RC 验证，但当前实现仍依赖本地持久文件系统：

1. 经营数据、用户、门店、对账、成本、异常、Action 等写入 SQLite 文件。
2. 上传的 CSV/XLSX/图片先保存到 `mini_uploads/`，后续确认时再次读取原文件。
3. 多个 Repository、Service 与 `data_foundation.py` 直接使用 `sqlite3`、`?` 占位符、`lastrowid`、`INSERT OR IGNORE` 等 SQLite 语义。
4. `app.py` 启动时会初始化 legacy Demo 用户、Demo 门店和 `app_state`。

Vercel Functions 的本地文件系统不能作为可靠长期状态存储，因此直接部署当前 RC 会产生数据持久性风险。云端版必须把正式经营数据迁到外部持久数据库，并取消对上传原文件长期存在的依赖。

本次改造不是重写 Mini V1，而是为已通过验证的业务逻辑增加云端持久化能力。

---

## 2. 已锁定决策

### 2.1 数据库

正式云端使用 **Neon PostgreSQL**。

本地开发、原有 R1/Web 原型与现有 SQLite 回归测试继续保留 SQLite，不删除、不强制迁移。

### 2.2 云端初始数据

云端数据库从**空业务库**开始，仅初始化：

- Schema；
- 标准渠道字典；
- 必要系统配置；
- 通过审核的 Benchmark Seed。

不得迁移：

- Demo 用户；
- Demo 门店；
- 测试销售；
- 测试对账；
- 测试 Action；
- 本地上传历史；
- legacy `app_state`。

### 2.3 上传文件策略

采用 **EPHEMERAL**：原始截图/CSV/XLSX 仅用于当次请求的识别或解析，处理完成后不长期保存。

云端长期保存的是可审计的结构化信息，而不是原文件：

- `content_hash`；
- 文件名、MIME、大小；
- 平台/页面分类；
- OCR 原始字段；
- 规范化值；
- 可信度；
- 用户修正；
- Provider / Model / Template 版本；
- 确认时间；
- 最终 Import lineage。

### 2.4 架构方式

采用 **数据库适配层**，不维护两套业务 Service。

```text
WeChat Mini Program
        │ HTTPS
        ▼
Vercel / FastAPI Mini API
        │
        ▼
Existing Business Services
        │
        ▼
Persistence Adapter
   ┌──────────┴──────────┐
   ▼                     ▼
SQLite                 PostgreSQL
Local / Regression     Neon / Cloud
```

业务规则只能保留一份。

---

## 3. 本次范围

### 3.1 In Scope

云端 Mini V1 实际生产链路：

- Mini 用户；
- 单店门店；
- 渠道；
- 销售；
- 整店营业额；
- Import File / Batch / Raw Row lineage；
- Settlement / Platform Fee / Payment / Reconciliation；
- 成本 Profile 与 Cost Entry；
- Industry Benchmark；
- Profit Snapshot；
- Upload Document / Draft / Extraction；
- Data Completeness；
- Anomaly；
- Action / Execution / Verification；
- Reminder；
- AI conversation 必要元数据；
- Mini API 所需 Repository / query path；
- Vercel FastAPI 入口；
- Neon 连接；
- 公网 HTTPS Acceptance。

### 3.2 Out of Scope

本次不做：

- legacy Web `app_state` PostgreSQL 化；
- 自动迁移本地 SQLite 业务数据到云端；
- 原始截图对象存储；
- 多门店；
- 员工权限系统；
- 平台 API/RPA 自动抓取；
- BOM、库存、税务、自动开票；
- 将微信登录替换为 Neon Auth；
- 用 Neon Data API 绕过 FastAPI；
- 重构所有 legacy Web 路由。

---

## 4. 方案比较与最终选择

### 方案 A：一次性把所有 SQLite 代码改为 PostgreSQL

优点：最终只有 PostgreSQL。  
问题：影响 `data_foundation.py`、legacy Web、全部测试和本地运行路径，改动面过大，容易破坏 R1 数据完整性契约。

**不采用。**

### 方案 B：SQLite / PostgreSQL 两套 Repository 和 Service

优点：短期容易隔离。  
问题：同一利润、对账、导入、异常规则会逐渐分叉，长期维护风险高。

**不采用。**

### 方案 C：共享业务逻辑 + Persistence Adapter

优点：

- 本地 SQLite 保持兼容；
- 云端 PostgreSQL 获得持久性；
- 业务 Service 不复制；
- 可建立双后端契约测试；
- 后续迁移更多模块时路径清晰。

代价：需要把当前直接使用 `sqlite3` 的生产模块逐步收口到统一数据访问接口。

**正式采用。**

---

## 5. Persistence Adapter 设计

### 5.1 新增运行时配置

建议新增：

```text
persistence/
  __init__.py
  config.py
  database.py
  sqlite_backend.py
  postgres_backend.py
  migrations.py
  postgres/
    0001_mini_v1_initial.sql
```

职责：

- `config.py`：读取 `DATABASE_URL` 和运行模式；
- `database.py`：定义业务代码可使用的统一 Session/Transaction 接口；
- `sqlite_backend.py`：包装现有 SQLite；
- `postgres_backend.py`：使用 PostgreSQL 驱动；
- `migrations.py`：只负责 PostgreSQL schema version / migration；
- SQL migration 文件：可审计、可重复验证的云端 schema。

### 5.2 后端选择规则

- `DATABASE_URL` 为空：SQLite 模式；
- `DATABASE_URL` 为 PostgreSQL URL：PostgreSQL 模式；
- 生产环境若 `DATABASE_URL` 缺失：启动失败，不允许回退到临时 SQLite。

不得出现“Vercel 上没有 DATABASE_URL，于是自动创建临时 SQLite 并继续服务”的行为。

### 5.3 推荐依赖

使用 SQLAlchemy 2.x 作为连接/事务统一层，并使用 Psycopg 3 连接 PostgreSQL。

原因：

- 两种数据库使用相同 transaction/context 模型；
- 避免自己实现连接池与游标兼容层；
- 支持 PostgreSQL / SQLite 双后端测试；
- 后续可逐步把 SQL 收口，不要求本轮引入 ORM entity 模型。

本轮只使用 SQLAlchemy Engine/Core 能力，不引入大型 ORM 重构。

### 5.4 SQL 规范

新增/迁移后的共享查询使用命名参数，不再新增 SQLite `?` 占位符。

需要明确替换的 SQLite 专用语义包括：

- `INSERT OR IGNORE`；
- `lastrowid`；
- `PRAGMA foreign_keys`；
- SQLite-only DDL；
- 依赖 sqlite row object 的行为。

新增 insert 应通过 `RETURNING id` 或统一 helper 取得主键。

---

## 6. PostgreSQL Schema 原则

### 6.1 语义兼容优先

为降低行为漂移，本次不顺便“优化”财务字段类型。

现有以字符串保存的 Decimal 财务值，在初始 PostgreSQL Schema 中继续保持与现有业务层兼容的表达方式。业务计算继续由 `Decimal` 完成。

现有毫秒时间戳继续使用整数毫秒，不在本轮改成另一套 timestamp 语义。

### 6.2 Schema Version

PostgreSQL 使用现有 `schema_meta` 思路记录版本，但其 migration 与 SQLite `db_v2.py/db_v3.py` 分离。

初始云端 schema 逻辑版本仍对应 Mini V1 Schema V3 业务契约；未来云端 migration 独立递增时，需要明确记录 cloud migration version，避免与 SQLite 文件升级流程混淆。

### 6.3 云端需要的表

基础：

- `schema_meta`
- `users`
- `stores`
- `channels`

Data Foundation：

- `import_files`
- `import_batches`
- `raw_import_rows`
- `daily_channel_sales`
- `settlements`
- `platform_fees`
- `payments`
- `reconciliation_matches`

Mini V1：

- `mini_users`
- `store_profiles`
- `daily_store_sales_totals`
- `store_cost_profiles`
- `cost_entries`
- `industry_benchmarks`
- `profit_snapshots`
- `upload_documents`
- `upload_drafts`（新增，见上传章节）
- `extraction_jobs`
- `extracted_fields`
- `document_import_links`
- `store_data_sources`
- `daily_data_status`
- `anomaly_events`
- `action_items`
- `action_executions`
- `action_verifications`
- `reminders`
- `ai_conversations`
- `ai_messages`

legacy `app_state`、legacy `uploads` 不进入云端 Mini V1 初始 schema。

---

## 7. 系统 Seed

### 7.1 渠道

云端初始化标准渠道，保持现有 code 稳定，包括新增的 `TAOBAO_FLASH`，不得用重命名方式覆盖历史 code。

Seed 必须幂等。

### 7.2 Benchmark

只加载 `review_status=APPROVED` 的 Benchmark。

任何聊天中临时讨论过但没有正式来源、年份、区域和审核状态的比例不得成为生产 Seed。

Benchmark Seed 加载应有版本/哈希，避免每次 cold start 重复制造新记录。

### 7.3 禁止 Demo Seed

生产启动不得自动插入：

- 演示用户；
- 永民手作；
- Demo state。

Demo 体验继续使用小程序前端只读 Demo 数据，不依赖生产数据库 Demo 店。

---

## 8. 上传 EPHEMERAL 设计

这是本次云端化最关键的行为调整之一。

### 8.1 当前问题

当前 `mini/upload_routes.py`：

1. `_store_raw()` 把原文件写到 SQLite 数据库旁边；
2. 文件确认页再次读取 `storage_key`；
3. `MiniImportAdapter` 确认时也可能重新读取文件；
4. 图片识别使用 FastAPI `BackgroundTasks` 后再访问本地文件。

这些假设在 Vercel Serverless 上不可靠。

### 8.2 云端文件流程

CSV/XLSX：

```text
HTTP upload bytes
→ 大小/MIME/扩展名校验
→ hash
→ 同请求解析
→ canonical rows + preview
→ upload_documents metadata
→ upload_drafts structured payload
→ discard raw bytes
→ user confirmation
→ import lineage + normalized tables
```

图片：

```text
HTTP upload bytes
→ 大小/MIME校验
→ hash
→ Recognition Provider（同请求完成）
→ platform/page/template classification
→ extraction_jobs + extracted_fields
→ upload_documents metadata
→ discard raw bytes
→ user confirmation/correction
→ import lineage + normalized tables
```

### 8.3 不使用 Serverless BackgroundTasks 承担关键识别

云端 V1 不依赖“响应已经返回后，本函数实例仍持续执行”的假设。

因此生产图片识别在上传请求内完成，返回：

- `NEEDS_CONFIRMATION`；或
- 明确的 `TEMPLATE_UNSUPPORTED / RECOGNITION_UNAVAILABLE / OCR_UNCERTAIN`。

如果未来识别耗时超过 Serverless 合理上限，再独立设计 Queue/Worker；本轮不提前引入。

### 8.4 `upload_drafts` 新表

文件类上传确认需要在原文件已经释放后仍保留待确认内容，因此新增结构化 Draft 表：

建议字段：

- `id`
- `document_id`（唯一）
- `draft_type`
- `preview_json`
- `canonical_payload_json`
- `payload_hash`
- `created_at`
- `updated_at`

Draft 只能保存用于确认与正式导入所需的结构化数据，不保存原始文件 bytes/base64。

### 8.5 `upload_documents` 扩展

新增/明确：

- `storage_policy = EPHEMERAL`
- `storage_key = NULL`（云端 EPHEMERAL）
- `content_hash`
- `size_bytes`
- `processed_at`

本地 SQLite 模式可以继续使用本地 `storage_key`，但 Repository/API 不得再假定所有 document 都一定有 `storage_key`。

### 8.6 上传限制

生产入口必须设置明确限制并 fail closed：

- 图片仅接受允许的 image MIME；
- 文件 V1 仅 CSV/XLSX；
- 文件大小必须有限制；
- XLSX 解压/解析必须限制工作量；
- 不支持类型返回老板可理解的错误，不尝试猜格式。

具体 MB/行数常量在实施计划中从当前测试与 Vercel函数约束确定并写入单一配置位置。

---

## 9. Data Foundation 迁移策略

### 9.1 不复制业务规则

以下 R1 契约必须在 PostgreSQL 下保持：

- Import lineage；
- Raw Row 可审计；
- 幂等；
- 缺字段修正版 fail closed；
- 渠道冲突拒绝；
- 跨渠道 reconciliation 拒绝；
- 周期费用不伪造日归属；
- Revenue / Settlement 语义分离；
- Decimal 财务计算。

### 9.2 `data_foundation.py`

当前该文件直接使用 SQLite。云端化时不得复制成 `data_foundation_postgres.py`。

应将连接/事务和少量 dialect 差异抽离，使同一个 importer 业务流程跑在两个 backend 上。

如某条 SQL 确实存在 dialect 差异，应通过 Persistence Adapter 的明确 helper 或极小 dialect-specific query 实现，不允许在 Service 里散布 `if postgres`。

### 9.3 测试要求

针对销售、Settlement、Payment、Reconciliation 的关键 R1 风险，至少建立 PostgreSQL 契约测试，不能因为 SQLite 的 R1 测试通过就推断 PostgreSQL 等价。

---

## 10. Repository / Service 收口

当前以下生产模块直接 `import sqlite3`，需要迁移或收口：

- `data_foundation.py`
- `repositories/mini_store_repository.py`
- `repositories/mini_sales_repository.py`
- `repositories/mini_cost_repository.py`
- `repositories/upload_repository.py`
- `repositories/data_status_repository.py`
- `repositories/insight_repository.py`
- `repositories/action_repository.py`
- `recognition/service.py`
- `services/benchmark_service.py`
- `services/completeness_service.py`
- `services/cost_resolver.py`
- `services/manual_ingestion.py`
- `services/mini_import_adapter.py`
- `services/profit_engine.py`
- `services/verification_engine.py`
- 以及少量 route 内直接 SQL。

原则：

1. 先收口到 Persistence Adapter；
2. 不顺手重写业务算法；
3. 一个模块迁移后同时跑 SQLite 契约测试和 PostgreSQL 契约测试；
4. 不相关 legacy Web 路径不进入本轮重构。

---

## 11. FastAPI 云端启动模式

### 11.1 Startup

当前 `app.py:init_db()` 同时负责 legacy Demo 初始化、SQLite migration、Benchmark seed、job recovery。

云端应拆分：

**SQLite local startup：**

- 保持现有兼容行为；
- 仍可使用 legacy Demo/Web。

**PostgreSQL production startup：**

- 校验 `DATABASE_URL`；
- 校验云端 schema version；
- 加载幂等系统 Seed；
- 不创建 Demo user/store/app_state；
- 不扫描本地文件恢复 upload job；
- 若 migration 未完成则 fail fast。

### 11.2 Vercel Entry

FastAPI 保持单一应用入口，不另建一套业务 API。

部署配置需要：

- Python FastAPI entrypoint；
- 合理的 function duration；
- 排除 tests/samples/legacy static 等非运行必需内容以控制 bundle；
- 环境变量配置；
- 生产 URL。

---

## 12. 连接与事务

### 12.1 Neon

Vercel 使用 Neon 推荐的 PostgreSQL connection string，并通过环境变量注入。

不得把连接串写进：

- git 文件；
- 小程序 config；
- API 响应；
- 日志。

### 12.2 Serverless 连接策略

采用适合 Serverless 的连接配置，避免每个函数实例维护大量长期空闲连接。

数据库 transaction 边界必须继续围绕“一个业务写操作”，例如：

- 创建 Import Batch + Raw Rows + normalized record；
- 确认 OCR Draft + 正式 Import Link；
- Action 状态转换；
- Reminder 状态写入。

不能把同一业务动作拆成多个无事务保护的独立写入。

---

## 13. Authentication / Tenant Boundary

本次不改变微信认证产品设计。

云端必须强化：

1. `wx.login()` code 只在服务端换 OpenID；
2. 客户端不能提交任意 OpenID 作为身份；
3. Bearer token 解出 `user_id`；
4. `current_store_id` 从该用户所属关系查询；
5. Mini API 的 `store_id` 不信任客户端；
6. 上传、利润、对账、Action、AI 都必须做 owner scope；
7. PostgreSQL 查询必须带用户/门店边界，不允许通过 ID 猜测读取其他门店。

V1 仍为单店老板模式，不引入 RBAC。

---

## 14. AI / Recognition Provider

### 14.1 Recognition

生产环境未配置 Provider 时，必须显式返回“截图识别服务尚未配置”，不能启用 Fake provider。

Provider 配置只通过 Vercel Secret/Environment Variables。

### 14.2 Text AI

同样保留现有 Sufficiency Gate：

- 数据不足 → `NEEDS_DATA`；
- 只有结构化 facts/estimates/evidence 才交给模型；
- 模型不直接写财务核心表；
- 未配置 provider 时返回可理解的 unavailable 状态。

---

## 15. 错误处理

对外继续使用“机器 code + 老板语言 + 下一步动作”的模式。

云端新增错误边界至少包括：

- `DATABASE_UNAVAILABLE`
- `DATABASE_MIGRATION_REQUIRED`
- `UPLOAD_TOO_LARGE`
- `UPLOAD_TYPE_UNSUPPORTED`
- `RECOGNITION_UNAVAILABLE`
- `RECOGNITION_TIMEOUT`
- `DRAFT_EXPIRED_OR_MISSING`

数据库原始异常、SQL、host、credential 不得进入用户响应。

---

## 16. 可观测性

V1 云端只做最低必要可观测性：

- request correlation id；
- route；
- status；
- duration；
- database backend；
- recognition provider/model；
- import batch/document/action id；
- error code。

禁止日志记录：

- DATABASE_URL；
- AppSecret；
- API Key；
- 完整经营截图；
- 完整支付敏感内容。

---

## 17. 测试策略

### 17.1 SQLite 回归 Gate

云端化完成后必须重新运行当前完整 Python 测试集。

原 SQLite 行为不能被“大量跳过 PostgreSQL 专项后仍宣称通过”替代。

### 17.2 PostgreSQL 专项 Gate

使用 Neon 临时 branch 或专用测试 database，覆盖：

- schema bootstrap；
- seed 幂等；
- user/store；
- sales/store-total；
- manual ingestion；
- CSV/XLSX draft→confirm；
- image structured draft→confirm（provider stub）；
- duplicate detection；
- Data Foundation sales/settlement/payment；
- reconciliation；
- profit；
- anomaly；
- action/verification；
- today aggregation；
- tenant isolation；
- transaction rollback；
- restart/persistence。

### 17.3 双后端契约测试

关键 Repository 使用同一组行为测试分别运行在：

- temporary SQLite；
- Neon temporary branch。

目的是证明业务接口一致，而不是证明两种 SQL 字符串一致。

### 17.4 公网 Acceptance

Vercel 部署后至少验证：

```text
/api/health
微信登录测试模式/真实模式边界
创建门店
手填营业额
补成本
Today
上传 CSV/XLSX → 确认
OCR Provider 配置状态
Action
重新请求后数据仍存在
```

最后再把公网 base URL 写入小程序 release config，进入微信 DevTools/真机 Gate。

---

## 18. Neon 安全迁移工作流

由于云端从空库开始，不执行“把 SQLite 数据导入生产库”。

Neon schema 建立使用临时 branch 验证：

1. 创建 Neon project；
2. 在 temporary branch 建 schema；
3. 验证表、约束、seed；
4. 运行 PostgreSQL contract tests；
5. 人工 Gate；
6. 再应用到 main branch。

任何 destructive migration 必须单独审批。本次 initial schema 不需要删除生产数据，因为生产库为空。

---

## 19. 发布 Gate

### Gate A — Persistence Adapter

- SQLite 现有测试保持通过；
- backend selection fail-safe；
- production missing DB URL fails fast。

### Gate B — PostgreSQL Schema

- Neon temporary branch schema 完整；
- seed 正确且无 Demo；
- transaction / constraints 工作。

### Gate C — Mini API on PostgreSQL

- 核心 Mini Acceptance 通过；
- tenant isolation 通过；
- restart 后数据仍存在。

### Gate D — EPHEMERAL Upload

- 原文件不落持久磁盘；
- CSV/XLSX 确认不依赖原文件；
- 图片确认不依赖原图；
- metadata/field/provenance 可审计。

### Gate E — Vercel HTTPS

- 正式 FastAPI 部署成功；
- health 200；
- PostgreSQL 实际读写成功；
- 生产 URL 不依赖临时 SQLite。

### Gate F — WeChat

这一 Gate 仍需微信外部环境：

- AppID；
- request/uploadFile 合法域名；
- DevTools；
- 真机登录；
- 截图/文件；
- 订阅消息。

Gate F 未完成前，不宣称微信正式发布 PASS。

---

## 20. 回滚原则

云端化失败不能破坏本地 RC。

因此：

- 原 `食策AI_Mini_V1_RC.zip` 保持不变；
- 云端开发在独立工作副本进行；
- SQLite 模式始终可继续运行；
- Neon schema 先走 temporary branch；
- Vercel 失败时不修改微信 release base URL；
- 只有公网 Acceptance 通过后，小程序才指向新地址。

---

## 21. 成功标准

本次云端化成功必须同时满足：

1. Mini V1 同一套业务 Service 可在 SQLite 与 PostgreSQL 下运行；
2. 云端生产不依赖 SQLite 文件持久化；
3. 云端生产不依赖本地 upload 文件持久化；
4. Neon 从空业务库启动，无 Demo 污染；
5. 关键 R1 数据完整性契约在 PostgreSQL 下有专项证据；
6. Vercel HTTPS API 可创建真实用户/门店并持久保存数据；
7. 服务重启/新实例后数据仍存在；
8. 所有密钥仅通过服务端环境变量；
9. 未完成微信 DevTools/真机 Gate 时明确标记 PENDING。

---

## 22. 最终架构

```text
┌───────────────────────────────┐
│       WeChat Mini Program     │
│ 今天 / 待办 / 上传 / 我的     │
└───────────────┬───────────────┘
                │ HTTPS
                ▼
┌───────────────────────────────┐
│       Vercel FastAPI          │
│       /api/mini/v1            │
├───────────────────────────────┤
│ Auth / Today / Upload / AI    │
│ Profit / Anomaly / Action     │
├───────────────────────────────┤
│ Existing Business Services    │
├───────────────────────────────┤
│ Persistence Adapter           │
└───────────────┬───────────────┘
                │
                ▼
┌───────────────────────────────┐
│       Neon PostgreSQL         │
│ structured data + lineage     │
└───────────────────────────────┘

Uploads:
raw bytes → parse/OCR in request → structured draft → discard bytes
```

**核心原则保持不变：数据支持到哪里，AI 就判断到哪里；数据不足就补数据，不让 AI 编答案。**
