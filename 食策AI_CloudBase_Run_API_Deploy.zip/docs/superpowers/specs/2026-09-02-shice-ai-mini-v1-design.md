# 食策AI Mini V1 产品与技术设计规格

**日期：** 2026-09-02  
**状态：** Design approved in chat; implementation planning approved to proceed  
**产品：** 食策AI Mini V1（微信小程序老板版）  
**基础版本：** 食策AI V0.5.0-R1 Data Integrity / Schema V2  

---

## 1. 目标

食策AI Mini V1 面向单店餐饮老板，核心不是展示更多报表，而是每天用最少操作回答四个问题：

1. 今天生意怎么样？
2. 今天大概赚了多少钱？
3. 今天哪里最需要处理？
4. 今天的钱有没有对上？

并形成完整经营闭环：

`上传数据 → 判断完整度/可信度 → 计算经营结果 → 找出 Top 3 问题 → 给出具体动作 → 老板执行/提醒 → 次日验证`

产品原则：

- 底层专业，上层简单。
- 结论优先，原因其次，明细最后。
- 数据支持到哪里，AI 就判断到哪里；数据不足就提示补数据，不编答案。
- 事实、估算、推断、建议必须在底层语义上分离。
- 高风险经营动作只建议，不未经老板确认自动执行。
- 普通老板主流程尽量控制在 1–3 次点击内。

---

## 2. V1 成功标准

V1 不以“页面数量”作为验收标准，而以真实单店闭环作为验收标准。

一个新用户应能完成：

1. 微信进入小程序。
2. 填写门店名称并选择主营品类。
3. 上传一张已适配平台截图。
4. 系统识别截图并展示待确认字段。
5. 用户确认或修改后，数据才进入正式经营数据区。
6. 用户可继续上传文件、截图，或手动补数据。
7. 同一天允许多次上传，系统不会重复累计。
8. 首页显示截至当前时间的营业情况和数据完整度。
9. 营业额有真实数据、成本不完整时，可用经过审核的行业/当地基准估算经营利润区间。
10. 首页最多展示 3 个最值得处理的问题。
11. 系统针对问题给出具体行动和文字执行材料。
12. 用户可标记已执行、暂不做或明天提醒。
13. 次日补充数据后，系统验证相关指标是改善、无明显变化、恶化，还是数据不足。
14. 对账区域只在有证据时给确定结论；否则明确显示“暂未对上”或“数据不足”。

---

## 3. V1 范围

### 3.1 必须包含

- 原生微信小程序前端。
- 微信登录，不强制手机号。
- 单店老板体验。
- 可先进入 Demo 体验。
- 4 个底部 Tab：`今天 / 待办 / 上传 / 我的`。
- 非 Tab 的“问食策AI”辅助入口。
- 统一数据上传入口：拍照、截图、文件、手动填写。
- 图片识别必须经过用户确认后才能入正式数据。
- CSV / XLSX 文件导入。
- 同一天多次上传、更新与防重复。
- 数据完整度学习与“今天没有其他数据了”人工确认。
- 今日营业数据。
- 经营利润：真实成本优先，缺失成本可做区间估算。
- 成本来源与可信度追踪。
- 行业 Benchmark 服务。
- 冷启动异常判断 + 本店历史逐渐接管。
- 首页 Top 3 异常。
- AI 行动建议。
- 文字类执行材料：活动方案、优惠设计、标题、文案、发布建议。
- 执行追踪。
- 微信订阅消息“明天提醒”。
- 次日效果验证。
- 简化对账。
- 7 日简要趋势。
- 基于结构化经营上下文的 AI 追问。

### 3.2 V1.1

- 宣传图片自动生成。
- 更多截图模板。
- 成本类截图识别增强。
- Benchmark 覆盖增强。
- 趋势分析增强。
- 更多行动模板。

### 3.3 V1 明确不做

- 平台 API 自动同步。
- RPA 自动抓取。
- 自动修改美团/抖音等平台设置。
- 自动发券、自动调价、自动关活动。
- 自动发布小红书/抖音/朋友圈。
- BOM。
- 库存。
- 自动报税。
- 自动开票。
- 完整会计净利润系统。
- 多门店前端。
- 总部/区域/店长/财务复杂权限。
- 员工账号体系。
- PostgreSQL 迁移。
- 自研 OCR 模型训练。

---

## 4. 技术路线

V1 采用：

`原生微信小程序 + FastAPI + 现有 Data Foundation + SQLite（开发/试点）`

架构：

```text
微信小程序
  ├─ 今天
  ├─ 待办
  ├─ 上传
  ├─ 我的
  └─ 问食策AI
        ↓
/api/mini/v1/*
        ↓
Mini Application Services
  ├─ Today Service
  ├─ Profit Engine
  ├─ Benchmark Service
  ├─ Recognition Service
  ├─ Data Completeness Service
  ├─ Duplicate Detection Service
  ├─ Anomaly Engine
  ├─ Action Engine
  ├─ Verification Engine
  ├─ Reminder Service
  └─ AI Context Service
        ↓
Existing Data Foundation
  ├─ Import Files / Batches / Raw Rows
  ├─ Daily Channel Sales
  ├─ Settlements
  ├─ Platform Fees
  ├─ Payments
  └─ Reconciliation Matches
        ↓
SQLite
```

### 4.1 为什么使用原生微信小程序

V1 重点是验证餐饮老板是否愿意每天使用，而不是多端复用。原生小程序在微信登录、图片/文件选择、订阅消息、授权和交互体验上路径最短。

V1 不采用 uni-app，也不采用 H5 套壳。

---

## 5. 现有 V0.5.0-R1 的复用边界

### 5.1 必须复用，不重写

- `channels`
- `import_files`
- `import_batches`
- `raw_import_rows`
- `daily_channel_sales`
- `settlements`
- `platform_fees`
- `payments`
- `reconciliation_matches`
- Decimal 金额语义
- 导入 provenance
- sales / settlement / payment normalization
- settlement/payment fingerprint
- 幂等逻辑
- 缺字段更正 fail-closed 规则
- 渠道冲突 fail-closed 规则
- reconciliation store/channel 边界
- revenue 与 settlement 语义分离
- full backup/reset/restore 基础能力

### 5.2 Mini V1 不直接使用 legacy state 作为经营事实

现有 `app_state` 和 V0.4 页面继续用于网页版兼容，但 Mini V1 的核心经营事实必须来自结构化表和 Mini V1 新表。

Mini V1 不调用现有 hard-coded `store_id=1` 的 legacy 状态流来管理真实用户。

### 5.3 `/api/v2/*` 作为内部底层能力

小程序前端不直接调用 `/api/v2/import/*`。

数据流：

`Mini Upload → Draft/Confirm → Mini Import Adapter → existing Data Foundation importer`

这样保持现有 Data Foundation 为唯一标准化入口。

---

## 6. Schema 策略

Mini V1 采用 **Schema V3 additive migration**。

原则：

- Schema V2 表不删除、不改写既有财务语义。
- V3 只增加 Mini V1 需要的表/索引/必要兼容字段。
- 为支持已确认的“淘宝闪购”截图/渠道，V3 在保留现有 `MEITUAN_FLASH` 的同时新增标准渠道 `TAOBAO_FLASH`（category=`DELIVERY`）；不重命名旧渠道，避免破坏历史数据。
- Migration 必须幂等、事务化、可回滚。
- 继续保留 V0.5.0-R1 的升级前备份原则。
- 新金额字段仍使用 canonical decimal string，由 Python `Decimal` 处理。

---

## 7. 用户、认证和门店

### 7.1 首次进入

欢迎页只提供：

- `开始管理我的店`
- `先看看食策AI能做什么`

正式使用流程：

`wx.login → FastAPI 微信登录 → 新用户创建 → 门店名称 → 主营品类 → 今天页`

首登不要求：城市、房租、员工人数、渠道配置、成本表、手机号。

### 7.2 新表：`mini_users`

建议字段：

```text
id
user_id              FK -> legacy users.id, UNIQUE
wechat_openid        UNIQUE NOT NULL
wechat_unionid       nullable
status
created_at
last_login_at
```

创建 Mini 用户时同时建立 legacy `users` owner 记录，以兼容现有 `stores.user_id NOT NULL`。登录成功后后端签发自己的短期访问 token；微信 `session_key` 不下发到小程序、不写入普通日志。token 过期后由小程序重新走 `wx.login` 获取新会话。

### 7.3 新表：`store_profiles`

```text
store_id             PK/FK -> stores.id
category_code        NOT NULL
city_code            nullable
owner_work_mode      nullable
created_at
updated_at
```

V1 `category_code` 固定枚举：

```text
MILK_TEA
COFFEE
FAST_FOOD_SNACK
CHINESE_DINING
HOTPOT
BBQ
BAKERY_DESSERT
BAR_LEISURE
OTHER_FOOD
```

前端显示中文名称，数据库保存稳定代码。

前端为单店体验，但所有 Mini V1 业务表继续保存 `store_id`，避免未来多店升级被锁死。

### 7.4 安全边界

Mini API **不接受客户端传入任意 `store_id` 作为授权依据**。

后端必须从登录 token 解析当前用户，再解析该用户绑定的 current store。任何资源读取和写入均在服务层再次校验 store ownership。

现有 `/api/v2/*?store_id=` 仅作为内部/开发接口保留，不作为 Mini V1 公网客户端接口。

---

## 8. 小程序页面结构

固定 Tab：

1. 今天
2. 待办
3. 上传
4. 我的

非 Tab：

- 欢迎 / Demo
- 创建门店
- 利润详情
- 异常详情
- 对账详情
- OCR/识别确认
- 行动详情
- 7 日趋势
- 问食策AI

不设置“数据中心”“经营诊断”“AI营销”“利润分析”等独立底部入口。

---

## 9. 今天页

首页聚合接口：

`GET /api/mini/v1/today`

前端不分别拼接销售、利润、异常、对账和待办结果。

返回至少包含：

```text
business_date
as_of_time
sales_summary
profit_summary
data_completeness
top_issues (max 3)
reconciliation_summary
latest_verifications
pending_action_count
```

页面主顺序：

1. 截至当前的营业额、订单数、客单价。
2. 经营利润点值或估算区间。
3. 数据完整度。
4. 今天最值得处理的最多 3 件事。
5. 今天的钱是否对上。
6. 最近行动验证结果。
7. 近 7 日简要趋势入口。

数据不完整时必须显示“截至 HH:mm”，不得暗示全天已结束。

---

## 10. 收入与重复覆盖语义

### 10.1 关键风险：整店总额与渠道数据不能重复相加

POS 日报、人工填写“整店营业额”和各渠道营业额可能覆盖同一批交易。如果简单把 POS 总额 + 微信 + 支付宝 + 外卖相加，会重复计算收入。

因此 V1 增加“报表覆盖范围”语义。

### 10.2 新表：`daily_store_sales_totals`

用于保存明确代表“整店总营业额”的真实数据，不伪装成 `OTHER` 渠道。

建议字段：

```text
id
store_id
business_date
gross_sales
order_count nullable
source_document_id nullable
import_batch_id nullable
source_scope          STORE_TOTAL
created_at
updated_at
```

唯一逻辑键：`(store_id, business_date)`。

### 10.3 Revenue Resolver

当日真实营业额采用以下优先级：

1. 经用户确认的整店总营业额 `daily_store_sales_totals`；
2. 如果没有整店总额，则对已确认“不重叠”的 `daily_channel_sales` 求和；
3. 如果存在覆盖范围不明或可能重叠的数据，标记冲突，要求用户确认，不能静默相加。

整店总额存在时，渠道数据用于结构分析和交叉校验，不再额外加到总营业额中。

### 10.4 POS 识别规则

- POS 能明确拆分渠道：按渠道导入。
- POS 只给整店总额：进入 `daily_store_sales_totals`。
- POS 总额与支付方式/平台数据可能重叠：系统保留两者，但 Revenue Resolver 只选择一套不重叠口径计算总收入。

---

## 11. 数据上传

上传页只有：

- 拍照
- 选截图
- 选文件
- 手动填写

并显示当日已收到的数据来源。

V1 第一批截图模板范围：

- 美团外卖
- 淘宝闪购
- 京东外卖
- 抖音本地生活/团购
- 美团点评/团购
- 微信收款
- 支付宝收款
- 常见 POS/收银日报

“常见 POS”不是承诺所有 POS 自动识别；V1 以明确适配的模板版本为准。

---

## 12. OCR / Vision 识别架构

### 12.1 硬规则

**识别结果永远不能直接写入正式经营/财务表。**

正式流：

`图片 → upload_documents → extraction_jobs → extracted_fields → 用户确认 → Import Adapter → Data Foundation / Store Total`

### 12.2 新表：`upload_documents`

```text
id
store_id
user_id
document_type
original_filename
storage_key
mime_type
business_date nullable
report_scope nullable
status
created_at
```

状态：

```text
UPLOADED
PROCESSING
NEEDS_CONFIRMATION
CONFIRMED
IMPORTED
FAILED
REJECTED
```

### 12.3 新表：`extraction_jobs`

```text
id
document_id
detected_platform
detected_page_type
template_code nullable
status
provider
model_version
started_at
completed_at
error_code nullable
error_message nullable
```

### 12.4 新表：`extracted_fields`

```text
id
extraction_job_id
field_code
raw_text
normalized_value
confidence
user_corrected
confirmed_value nullable
created_at
```

### 12.5 Recognition Provider Adapter

业务层只依赖统一接口，例如：

`recognize(document) -> RecognitionDraft`

底层可以替换 OCR/Vision Provider，不把业务代码绑定死在单一供应商。

### 12.6 Platform Template

必须以“平台 + 页面类型 + 模板版本”识别字段语义，例如：

```text
MEITUAN_DELIVERY_DAILY_REPORT_V1
ALIPAY_DAILY_RECEIPT_V1
DOUYIN_LOCAL_LIFE_DAILY_V1
```

OCR 只负责读字；Platform Template 负责判断“这个数是什么”。

### 12.7 未识别截图

- 平台未知：`UNKNOWN_PLATFORM`
- 数字可读但字段含义未知：`UNKNOWN_FIELD`

前端提示“我看到了数据，但还不能确定它代表什么”，允许用户手动确认。不得猜测后直接入账。

### 12.8 Mini Import Adapter 与原始证据链

图片/XLSX 不能直接交给现有只理解结构化行的 Data Foundation importer。Mini Import Adapter 必须先把**用户已经确认的字段**序列化成 canonical JSON 行，再调用现有 sales/settlement/payment importer。

为保留原始证据，新增桥接表 `document_import_links`：

```text
document_id
import_batch_id
confirmed_by_user_id
confirmed_at
created_at
```

这样正式链路为：

`原始图片/文件 → upload_document → extraction/parse draft → 用户确认 → canonical JSON → import_batch/raw_row → normalized record`

并且可以从 `import_batch` 反查原始截图/文件。

建议 source_type 使用明确值，例如：

```text
MINI_OCR_CONFIRMED
MINI_FILE_CONFIRMED
MINI_MANUAL
```

人工录入若进入现有渠道销售/结算/到账，也通过 canonical payload 进入 importer；整店总额则进入独立 `daily_store_sales_totals` 并保存提交来源。

### 12.9 任务执行方式

V1 试点期不引入 Redis/Celery。

- 上传后创建持久化 extraction job。
- FastAPI 进程内后台任务执行识别。
- 前端轮询上传详情直到 `NEEDS_CONFIRMATION` 或 `FAILED`。
- 服务重启后遗留 `PROCESSING` 任务不得假装成功，应进入可重试失败状态。
- 后续规模增长时可替换为正式任务队列，不改变前端接口。

---

## 13. 文件上传

V1 正式支持：

- CSV
- XLSX

文件流程：

`上传 → 识别平台/模板 → 解析 → 摘要 → 用户确认 → Data Foundation importer`

V1 不承诺 PDF 自动结构化。

解析失败仍必须保留可审计失败记录，不出现“0 行 COMPLETED”。

---

## 14. 手动填写

第一层只问用户想补什么：

- 今天卖了多少
- 成本
- 平台到账
- 其他

不把专业财务字段直接暴露给老板。

例如“今天卖了多少”只需要选择：

- 整店
- 美团
- 淘宝闪购
- 京东
- 抖音
- 微信
- 支付宝
- 现金
- 其他

并输入必要字段：营业额（必填）、订单数（可选）、退款（可选）。

“整店”进入 `daily_store_sales_totals`，不是 `OTHER` 渠道。

---

## 15. 同日多次上传和防重复

同一天允许无限次补充数据，但不得重复累计。

Duplicate Detection Service 输出：

```text
NEW
UPDATE
POSSIBLE_DUPLICATE
CONFLICTING_SCOPE
```

判断依据：

- store
- business_date
- channel
- report/page type
- report scope
- platform reference
- time range
- existing imports
- cumulative/period semantics

能够证明是同一份累计更新时：更新逻辑记录。

不能证明时：要求用户选择“更新之前的数据”或“这是另一份数据”。

继续遵守 R1 原则：如果更正会造成缺字段覆盖、混合来源或不可证明的 merge，则 fail closed。

---

## 16. 数据完整度

### 16.1 自动学习 + 人工确认

系统根据历史上传学习常用数据来源，同时保留按钮：

`今天没有其他数据了`

### 16.2 新表：`store_data_sources`

```text
store_id
channel_code nullable
data_type
report_scope
first_seen_at
last_seen_at
appearance_days
recent_30d_days
is_expected
updated_at
```

### 16.3 新表：`daily_data_status`

```text
store_id
business_date
expected_source_count
received_source_count
user_declared_complete
completeness_level
as_of_time
updated_at
```

数据完整度和数据可信度是两个不同概念，不共用一个分数。

---

## 17. 利润口径

V1 首页默认展示 **经营利润**，不是完整会计净利润。

V1 经营利润主要考虑：

- 营业收入
- 原料成本
- 人工
- 房租
- 平台费用
- 推广
- 水电杂费
- 其他主要经营成本（用户明确提供时）

默认不强行纳入：

- 税费
- 折旧
- 利息/融资成本
- 复杂社保会计处理
- 库存/BOM 调整

利润详情必须提示尚未纳入的项目，避免把经营利润冒充会计净利润。

---

## 18. 利润计算状态

Profit Engine 输出三种状态：

### 18.1 `ACTUAL_BASED`

营业额为真实数据，主要成本来自实际值或可确定的实际期间分摊。

显示一个经营利润点值，并仍可使用“预计”表述，因为月度成本到日成本存在分摊口径。

### 18.2 `ESTIMATED_RANGE`

营业额是真实数据，但一个或多个重要成本来自历史/当地/行业 Benchmark。

首页只显示区间，例如：

`今天估计赚 ¥900～¥1,300`

不显示伪精确中间值。

### 18.3 `UNAVAILABLE`

没有可靠真实营业额，或缺失到无法形成合理结果。

显示“今天还算不了赚多少钱”，并告诉用户下一步应补什么。

**硬规则：没有真实营业额，不生成利润。**

---

## 19. 成本来源优先级

每项成本单独决定数据来源，而不是整张利润表只有“实际/估算”二选一。

统一来源枚举：

```text
ACTUAL
USER_ESTIMATE
STORE_HISTORY
LOCAL_BENCHMARK
INDUSTRY_BENCHMARK
UNKNOWN
```

前端翻译：

- 实际数据
- 你提供的大概值
- 根据你店历史估算
- 根据当地同类店参考
- 根据同类店参考
- 暂时没有数据

---

## 20. 原料成本

优先级：

1. 用户提供的实际消耗成本/实际成本率。
2. 本店历史成本率。
3. 同城/区域同品类 Benchmark。
4. 全国同品类 Benchmark。
5. UNKNOWN。

### 20.1 采购金额不能自动等同原料消耗成本

V1 不做库存/BOM，因此“本月采购了 ¥20,000 原料”不能无条件视为“本月消耗了 ¥20,000”。

采购型数据可以保存为成本线索，但只有用户明确确认其用于对应期间成本估算时，才能作为估算来源，并标记为估算而非精确实际消耗。

---

## 21. 人工成本

优先级：

1. 实际日/班次人工。
2. 实际月人工，经明确的营业日/期间规则分摊。
3. 当地 + 品类市场工资区间 × 全职人数 + 当地小时工资区间 × 兼职月工时。
4. UNKNOWN。

城市只在第一次需要人工估算时询问并保存。

最低工资只作为合法下限校验，不作为默认市场工资。

### 21.1 老板本人劳动

询问：

- 基本全职
- 偶尔帮忙
- 不参与日常

V1 首页不强制把老板本人机会成本纳入经营利润。

利润详情可单独提示“如果把你自己的劳动按当地市场工资计算，结果约减少 X～Y”，且必须标记为辅助估算。

---

## 22. 房租

优先级：

1. 实际月租。
2. 同品类房租/营业额参考区间。
3. UNKNOWN。

实际月租默认按营业日分摊；如果尚不知道营业日规则，则按自然日临时分摊并明确这是日分摊口径，后续门店资料补齐后重算。

行业房租比例属于低可信估算，不得伪装为实际租金。

---

## 23. 平台费用、推广、水电等

- 有**与当日直接对应**的平台费用数据时优先使用实际值。
- 现有 R1 的周期结算费用 `platform_fees.business_date = NULL` 规则保持不变，绝不能为了算今日利润把一周/月度费用伪造到周期最后一天。
- 如果只有周期结算费用，可先从已完成结算期计算本店历史有效费率，作为 `STORE_HISTORY` 区间/估算用于当日利润；只有存在明确、可审计的期间分配规则时才做期间分摊。
- 平台费用继续使用 Data Foundation 已明确的 fee semantics。
- 不自动猜测 platform subsidy 的加减口径。
- 缺少可信平台 profile 时不自动套用平台抽佣比例。
- 推广、水电等允许用户填实际值或明确的用户估值。
- V1 不用一个全国统一比例静默补齐所有杂费。

---

## 24. 新表：`store_cost_profiles`

建议保存门店长期成本设置：

```text
store_id
food_cost_mode
food_cost_value nullable
labor_cost_mode
monthly_labor_actual nullable
full_time_count nullable
part_time_hours_month nullable
rent_mode
monthly_rent nullable
utilities_mode
utilities_value nullable
owner_work_mode nullable
created_at
updated_at
```

必要的分摊参数可追加：

```text
operating_days_per_month nullable
allocation_basis
```

---

## 25. 新表：`cost_entries`

保存实际或用户明确确认的期间成本：

```text
id
store_id
period_start
period_end
business_date nullable
cost_type
amount
source_type
source_document_id nullable
basis
created_at
```

`cost_type`：

```text
FOOD
LABOR
RENT
UTILITY
MARKETING
PACKAGING
OTHER
```

---

## 26. Benchmark 数据库

新表：`industry_benchmarks`

```text
id
category_code
region_level
region_code nullable
metric_code
low_value
mid_value nullable
high_value
unit
source_name
source_url
source_date
confidence_level
review_status
valid_from
valid_to nullable
created_at
updated_at
```

### 26.1 Benchmark Gate

只有 `review_status = APPROVED` 的 Benchmark 才能进入生产利润/异常计算。`review_status` 固定为 `DRAFT / APPROVED / RETIRED`；过期或 RETIRED 的基准不得用于新的计算快照。

每条 Benchmark 必须有：

- 品类
- 地区层级
- 指标
- 区间
- 来源名称
- 来源链接或可审计出处
- 数据日期
- 可信等级
- 审核状态

聊天中临时出现的行业数字不得直接写入生产 Benchmark。

### 26.2 Benchmark 优先级

`本店历史 → 同城同品类 → 省/区域同品类 → 全国同品类 → UNKNOWN`

没有经过审核的合理 Benchmark 时，系统宁可显示“暂时无法可靠估算”，也不使用无来源魔法数字。

---

## 27. Profit Engine

输入：

- Revenue Resolver 的真实营业额。
- 实际成本。
- Store Cost Profile。
- Store History。
- Approved Benchmark。
- Data completeness/confidence。

输出至少包含：

```text
status
revenue
profit_value nullable
profit_low nullable
profit_high nullable
components[]
missing_inputs[]
confidence_level
calculation_version
```

每个 component 必须包含：

```text
cost_type
value / low / high
source_type
source_reference
confidence
```

核心计算全部使用 `Decimal`，不依赖大模型算账。

---

## 28. 利润快照

建议新表：`profit_snapshots`

```text
id
store_id
business_date
as_of_time
revenue_amount
profit_status
profit_value nullable
profit_low nullable
profit_high nullable
data_completeness
confidence_level
calculation_version
input_signature
created_at
```

只有输入发生变化时生成新快照，保留用户当时看到的计算版本和输入签名，便于审计算法升级后的差异。

---

## 29. 异常检测

### 29.1 基准优先级

新用户冷启动：行业/当地参考。

随着数据累积：

`本店近期 → 本店更长期 → 同城同品类 → 全国同品类`

本店基准可优先使用 7/14/30 日窗口，具体窗口由不同指标规则决定，而不是所有指标强制同一窗口。

### 29.2 新表：`anomaly_events`

```text
id
store_id
business_date
anomaly_type
metric_code
observed_value
baseline_low nullable
baseline_high nullable
baseline_source
estimated_impact_low nullable
estimated_impact_high nullable
severity
confidence
actionability
persistence
status
created_at
updated_at
```

### 29.3 严重程度与可信度分开

允许：

`severity = HIGH`，同时 `confidence = LOW`

低可信的高异常不得用确定性语言占据首页第一优先级。

### 29.4 Top 3

第一版使用规则评分，不上机器学习：

`影响金额 × 异常程度 × 可信度 × 持续性 × 可处理程度`

并加入硬规则：

- 明显对账金额差异优先。
- 低可信度不能表述为确定警报。
- 同一根因不能占满三个位置。
- 首页最多 3 个，其余放详情。

AI 不负责决定 Top 3；AI 只负责把已经结构化的结论解释成人话。

---

## 30. 待办与行动

待办页分：

- 今天建议做
- 等待验证
- 已完成（折叠）

### 30.1 新表：`action_items`

```text
id
store_id
business_date
anomaly_id nullable
action_type
title
reason
expected_metric
expected_direction
priority
status
created_at
updated_at
```

状态：

```text
PENDING
EXECUTED
SKIPPED
REMIND
WAITING_VERIFICATION
VERIFIED
```

### 30.2 行动材料

V1 可生成：

- 活动方案
- 优惠设计
- 微信群文案
- 朋友圈文案
- 小红书文案
- 抖音文案
- 发布建议
- 简单排班建议
- 对账核对步骤

V1 不生成营销图片；图片进入 V1.1。

### 30.3 “去执行”的含义

“去执行”只展示操作方案/步骤，不代表 AI 已经修改第三方平台。

只有用户主动点击“我已经做完”，才记录为执行。

---

## 31. 执行与验证

### 31.1 `action_executions`

```text
id
action_id
executed_at
execution_note nullable
baseline_metric_code
baseline_metric_value nullable
created_at
```

### 31.2 `action_verifications`

```text
id
action_id
verification_date
before_value nullable
after_value nullable
change_rate nullable
result
confidence
explanation
created_at
```

结果：

```text
IMPROVED
NO_CLEAR_CHANGE
WORSENED
INSUFFICIENT_DATA
```

前端允许说“执行后相关指标有改善”，但无因果证据时不得说“这个动作导致利润提高 X%”。

---

## 32. 微信订阅消息提醒

用户只有主动点击“明天提醒我”时，才调用微信订阅消息授权。

流程：

`Action → wx.requestSubscribeMessage → 用户同意 → /actions/{id}/remind → reminder`

新表：`reminders`

```text
id
user_id
store_id
action_id
reminder_type
scheduled_at
wechat_template_id
status
sent_at nullable
error_message nullable
created_at
```

状态：

```text
PENDING
SENT
FAILED
CANCELLED
```

如果开发/审核阶段暂时没有可用微信订阅模板，功能必须降级为小程序内待办提醒，而不是伪报“微信提醒已发送”。

---

## 33. 对账

继续复用 V0.5.0-R1：

- settlements
- payments
- reconciliation_matches
- reference matching
- tolerance
- cross-channel rejection

首页对账是**截至当前的未结清/未匹配快照**，不是强行把平台结算归到“今天销售”。平台结算可能滞后数日，因此 `/reconciliation/today` 的语义是 `as-of today summary`。

首页只显示三种状态：

1. 暂时没发现问题。
2. 还有 ¥X 暂时没对上。
3. 数据不足，缺到账/结算数据。

无证据时不得表述为“平台少给了 ¥X”。

详情可显示：

- 平台应该结算
- 当前识别到账
- 暂未对上差额
- 可能原因（明确标为可能）
- 核对步骤

---

## 34. 问食策AI

聊天是辅助入口，不是首页主入口。

流程：

`用户问题 → Intent → 读取相关结构化数据 → Sufficiency Gate → Structured Context → LLM 解释`

### 34.1 AI Context

至少包含：

```text
facts
estimates
missing_data
anomalies
reconciliation
recent_actions
recent_verifications
benchmarks_used
```

底层将内容区分为：

- 事实
- 估算/推断
- 建议

前端不必强制展示这三个专业标题，但回答措辞必须保留区别。

### 34.2 Sufficiency Gate

例如用户问“今天人工是不是太高”，但系统没有实际人工、员工人数、兼职工时，也没有可用 Benchmark：

必须回答“现在还判断不了”，并提供“补人工数据”入口。

LLM 不得自行创造数字补齐 Context。

### 34.3 AI 的职责

AI 可以：

- 解释结构化事实。
- 把专业指标翻译成人话。
- 给基于已知事实的建议。
- 生成文字执行材料。

AI 不可以：

- 核心财务计算。
- 自己猜经营事实。
- OCR 未确认即记账。
- 自己决定正式财务口径。
- 未经确认执行高风险动作。

---

## 35. Mini API

### Auth

```http
POST /api/mini/v1/auth/wechat
POST /api/mini/v1/demo/session
```

### Store

```http
POST  /api/mini/v1/store
GET   /api/mini/v1/store
PATCH /api/mini/v1/store
```

### Today / Trend

```http
GET /api/mini/v1/today
GET /api/mini/v1/trends?days=7
```

### Profit

```http
GET   /api/mini/v1/profit/today
GET   /api/mini/v1/profit/profile
PATCH /api/mini/v1/profit/profile
```

### Upload

```http
POST /api/mini/v1/uploads/image
POST /api/mini/v1/uploads/file
GET  /api/mini/v1/uploads/{id}
POST /api/mini/v1/uploads/{id}/confirm
POST /api/mini/v1/uploads/{id}/reject
POST /api/mini/v1/uploads/{id}/retry
```

### Manual

```http
POST /api/mini/v1/manual/sales
POST /api/mini/v1/manual/cost
POST /api/mini/v1/manual/payment
```

### Data Status

```http
GET  /api/mini/v1/data-status/today
POST /api/mini/v1/data-status/today/complete
```

### Issues

```http
GET /api/mini/v1/issues/today
GET /api/mini/v1/issues/{id}
```

### Actions

```http
GET  /api/mini/v1/actions
GET  /api/mini/v1/actions/{id}
POST /api/mini/v1/actions/{id}/execute
POST /api/mini/v1/actions/{id}/skip
POST /api/mini/v1/actions/{id}/remind
POST /api/mini/v1/actions/{id}/generate-copy
```

### Reconciliation

```http
GET /api/mini/v1/reconciliation/today
GET /api/mini/v1/reconciliation/{id}
```

### AI

```http
POST /api/mini/v1/ai/chat
```

Mini API 响应给老板端简单语义，但内部保留 machine-readable status/code。

---

## 36. 错误处理

所有用户可见错误必须告诉用户下一步怎么解决。

### 36.1 图片识别失败

显示：

“这张截图暂时没识别清楚。”

操作：

- 重新上传
- 手动填写

### 36.2 字段低可信

只标记低可信字段，不要求用户重新填写整张表。

### 36.3 数据冲突

例如 POS 整店总额与渠道合计明显不一致：

显示“这两份数据可能覆盖了同一笔营业额”，让用户确认哪份代表整店总额。不得自动双算。

### 36.4 数据不足

不输出伪结论；返回 `INSUFFICIENT_DATA` 和 `missing_inputs`，前端提供直接补数据按钮。

### 36.5 后端/识别 Provider 暂时失败

已上传文档和 Draft 状态必须保留，用户不需要重新选择文件。允许重试。

---

## 37. 数据隐私与文件存储

经营截图可能包含交易、订单和门店信息。

V1 架构要求：

- 数据库不存大图片 Blob。
- 本地开发可使用服务器私有文件目录。
- 正式部署使用私有 Object Storage。
- 数据库只保存 `storage_key`。
- 文件不提供永久公开 URL。
- 下载/查看使用短时授权或后端受控读取。
- Mini API 必须校验用户与 store ownership。
- 日志不得记录微信 session_key、完整授权 token 或敏感支付明细。

---

## 38. 部署边界

### 38.1 开发

- SQLite
- 本地/测试 FastAPI
- 微信开发者工具
- Provider sandbox/test credentials

### 38.2 真机试点

需要：

- 可公网访问的 HTTPS FastAPI
- 微信小程序 AppID
- 合法 request/upload/download 域名配置
- 微信登录服务端凭据
- 订阅消息模板（若已通过）
- 私有文件存储

### 38.3 商业化前

数据库再评估迁移 PostgreSQL。

V1 不为了未来 SaaS 预先引入 Kubernetes、Redis、Celery、复杂多租户 RBAC。

---

## 39. 代码组织建议

不要求一次性把现有 `app.py` 全部重构。

新增 Mini V1 代码应隔离：

```text
mini_api/
  auth.py
  store.py
  today.py
  uploads.py
  profit.py
  issues.py
  actions.py
  reconciliation.py
  ai.py

services/
  revenue_resolver.py
  profit_engine.py
  benchmark_service.py
  recognition_service.py
  platform_templates.py
  completeness_service.py
  duplicate_detection.py
  anomaly_engine.py
  action_engine.py
  verification_engine.py
  reminder_service.py
  ai_context_service.py

repositories/
  mini_user_repository.py
  store_repository.py
  upload_repository.py
  cost_repository.py
  benchmark_repository.py
  anomaly_repository.py
  action_repository.py
```

现有 `data_foundation.py` 继续负责 V2 财务标准化；不把 Mini OCR、AI Prompt、页面聚合逻辑塞回该文件。

---

## 40. 测试策略

V1 必须继续保持“先数据完整性、再页面体验”的测试原则。

### 40.1 Migration

- V2 → V3 原地升级。
- 原 V2 数据不丢。
- migration 幂等。
- migration rollback。
- V0.4/R1 现有 58 个测试继续回归通过（如测试集未因后续版本增加而变化，则至少保持原有覆盖全部通过）。

### 40.2 Auth / Isolation

- 用户只能读取自己的 store。
- 伪造 store_id 不能跨店访问。
- Demo 数据与正式用户数据隔离。

### 40.3 Upload / OCR

- OCR 结果未确认前，核心财务表 0 写入。
- 用户修改字段后使用 confirmed value。
- 低可信字段正确标记。
- 已确认图片/文件生成 canonical payload 后，normalized record 可追溯到 import batch，并通过 `document_import_links` 追溯到原始 document。
- 未知平台不猜字段。
- Provider 失败可重试。
- 进程重启遗留任务不会被标成成功。

### 40.4 Revenue / Duplicate

- 14:00 累计美团 ¥2,000，20:00 累计 ¥4,800，最终收入为 ¥4,800，不是 ¥6,800。
- POS 整店总额 ¥10,000 + 微信 ¥3,000 + 支付宝 ¥2,000 不得计算为 ¥15,000。
- 已有整店总额后新增渠道数据只做分解/校验，除非用户明确更换总额来源。
- 存在 whole-store total 时，渠道仅用于分解和校验。
- coverage 冲突时 fail closed / needs confirmation。
- 继续覆盖 R1 partial correction fail-safe。

### 40.5 Profit

- 无真实营业额 → `UNAVAILABLE`。
- 真实营业额 + 全实际成本 → `ACTUAL_BASED`。
- 真实营业额 + Benchmark 成本 → `ESTIMATED_RANGE`。
- Benchmark 未 APPROVED 不进入计算。
- 每个成本组件保存 source。
- Decimal 结果稳定。
- 采购额不会被静默当作原料消耗成本。

### 40.6 Anomaly

- 新店可使用已批准 Benchmark，且标低/相应可信度。
- 有足够本店历史后优先本店基准。
- severity 与 confidence 可独立。
- 首页最多 3 条。
- 低可信异常不会被表达为确定事实。

### 40.7 Action / Verification

- “去执行”不直接标记 EXECUTED。
- 只有用户确认“我已经做完”才记录执行。
- 提醒授权失败不伪报成功。
- 验证支持 IMPROVED / NO_CLEAR_CHANGE / WORSENED / INSUFFICIENT_DATA。
- 文案不得把相关性写成已证明因果。

### 40.8 AI

- 缺数据时返回 missing data，而不是补数字。
- LLM 不直接执行财务算术作为最终权威值。
- AI 回答只使用 Structured Context 中允许的信息。
- 高风险动作只输出建议/步骤。

### 40.9 Mini 前端

- 4 Tab 正常跳转。
- 首登只要求门店名和品类。
- 数据不完整时显示“截至时间”。
- 首页最多 Top 3。
- 所有失败态有可执行下一步。
- 不出现专业财务字段作为默认主文案。

---

## 41. V1 验收场景

### 场景 A：新奶茶店、只有截图

1. 创建“XX奶茶”，品类奶茶饮品。
2. 上传美团截图。
3. Recognition 识别营业额/订单/实付/退款。
4. 用户确认。
5. 首页显示真实营业额，成本缺失。
6. Benchmark 已审核的情况下，原料等可形成估算区间；人工需要城市/人数时再询问。
7. 利润显示区间，不显示伪精确值。

### 场景 B：同日多次上传

1. 14:00 上传美团累计数据。
2. 20:00 上传同页面更新版。
3. 系统识别为 UPDATE。
4. 首页更新截至 20:00 结果，不重复累计。

### 场景 C：POS + 支付数据重叠

1. POS 报表显示整店 ¥10,000。
2. 用户又上传微信、支付宝。
3. 系统将 POS 保存为 STORE_TOTAL。
4. Revenue Resolver 使用 ¥10,000 作为总收入。
5. 微信/支付宝用于渠道结构/校验，不追加成 ¥15,000。

### 场景 D：行动闭环

1. 系统检测客单价连续下降。
2. Top 3 中展示问题。
3. 生成具体方案和微信群/朋友圈文案。
4. 用户标记已执行。
5. 用户授权明天提醒。
6. 次日上传数据。
7. Verification 显示相关指标改善/无明显变化/恶化/数据不足。

### 场景 E：对账

1. 有 settlement 和 payment。
2. 暂未匹配 ¥386。
3. 首页显示“还有 ¥386 暂时没对上”。
4. 不写“平台少给你 ¥386”。

---

## 42. 开发硬规则

以下规则为 V1 开发不可静默更改的边界：

1. AI 不直接写正式经营数据。
2. 图片识别必须经过用户确认。
3. 没有真实营业额，不生成利润。
4. 成本可以估，但必须保存来源；重要估算在首页显示区间。
5. 未审核 Benchmark 不得进入生产估算。
6. AI 不负责核心财务计算。
7. 周期结算费用不得伪造成某一天的实际费用。
8. 整店总额与渠道数据不能静默重复相加。
9. 不能证明安全合并的数据更正继续 fail closed。
10. 高风险经营动作未经确认不能自动执行。
11. 对账差异没有证据时只说“暂未对上”。
12. 数据不足必须明确提示缺什么。
13. 首页最多 3 个重点问题和最多 3 个重点行动。
14. 小程序体验单店，但底层所有正式业务数据保留 store_id。
15. 现有 Data Foundation 财务语义不得为迁就前端而重写。

---

## 43. 实施顺序约束

正式实施计划应按依赖关系推进，而不是先堆 UI：

1. Schema V3 + migration + repository 边界。
2. Mini Auth + 单店绑定。
3. Revenue Resolver + whole-store total 语义。
4. Cost/Benchmark/Profit Engine。
5. Manual + CSV/XLSX upload confirmation pipeline。
6. Recognition draft/confirm pipeline + 第一批平台模板。
7. Today aggregation + data completeness。
8. Anomaly Top 3。
9. Action/Execution/Verification。
10. Subscription Reminder。
11. AI Context + 文字执行材料。
12. 原生微信小程序页面接入和完整 E2E。

具体任务拆分、测试先后和文件级改动由后续 implementation plan 定义，本设计规格不提前实施。

---

## 44. 设计结论

食策AI Mini V1 不是现有网页版的缩小版，而是一个“老板每天打开就知道今天该做什么”的操作层。

现有 V0.5.0-R1 Data Foundation 继续做可信的数据底座；Mini V1 新增上传确认、利润估算、Benchmark、异常、行动和验证服务；小程序只呈现老板第一眼真正需要的信息。

最终产品路径：

`真实数据优先 → 缺失项透明估算 → 发现少数关键问题 → 给出可执行动作 → 老板确认 → 次日验证`

这条闭环是 V1 的唯一主线，不能被复杂报表、全平台自动化、图片生成、多门店权限等后续能力打断。
