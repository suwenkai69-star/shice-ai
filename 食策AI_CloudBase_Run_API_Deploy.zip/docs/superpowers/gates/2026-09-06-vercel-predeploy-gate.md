# 食策AI Mini V1 — Vercel Predeploy Gate — 2026-09-06

## Code readiness
- FastAPI entrypoint remains `app.py` with global `app`.
- `vercel.json` configures the Python function with `maxDuration >= 60`.
- local databases, raw upload directories, tests, samples, static legacy assets, caches and environment files are excluded from deployment.
- production route guard exposes only `/api/health` and `/api/mini/v1/**`.
- production database configuration fails closed without `DATABASE_URL`.
- production auth fails closed without WeChat credentials and `MINI_TOKEN_SECRET`.

## Cloud reminder conversion
The previous local reminder CLI remains usable, and cloud execution is now additionally available through:

`GET /api/mini/v1/internal/reminders/dispatch`

Security contract:
- requires `Authorization: Bearer <CRON_SECRET>`
- missing or wrong secret returns `401`
- no secret is stored in source or `vercel.json`
- runtime database is obtained from `get_database()`, so PostgreSQL is used in cloud

Vercel schedule:
- hourly at `0 * * * *`

## Required Vercel Environment Variables
Configure as Vercel Project Settings / Environment Variables. Do not store values in source files.

Required for preview/production backend:
- `DATABASE_URL`
- `SHICE_ENV=production`
- `MINI_TOKEN_SECRET`
- `WECHAT_APPID`
- `WECHAT_SECRET`
- `CRON_SECRET`

Required when reminder subscription messages are enabled:
- `WECHAT_SUBSCRIBE_TEMPLATE_ID`

Required when screenshot recognition is enabled through OpenAI:
- `RECOGNITION_PROVIDER=openai`
- `OPENAI_API_KEY`
- `OPENAI_RECOGNITION_MODEL`

## Public smoke test prepared
`tests/cloud/test_public_contract.py` is guarded by `SHICE_PUBLIC_BASE_URL` and checks:
- HTTPS health is live and reports PostgreSQL
- legacy cloud routes are 404
- protected Mini route is 401 without auth

It is intentionally skipped before a public preview URL exists.

## Fresh local verification before checkpoint
Run:
- `PYTHONPATH=. pytest -q`
- `python -m compileall -q .`
- all Mini Program JavaScript files through `node --check`

Fresh result:
- `243 passed`
- `7 skipped` (4 live PostgreSQL contracts needing psycopg/network; 3 public HTTPS smoke checks needing a preview URL)
- `0 failed`
- `2 warnings` (inherited FastAPI `on_event` deprecation warnings)
- compileall PASS
- Mini Program JavaScript syntax PASS

## External deployment blocker
The available Vercel connector exposes deploy/project/log capabilities but no project-environment-variable write action. Per the migration plan, secrets must not be embedded in deployment files. A one-time Vercel Environment Variables configuration is therefore required before preview deployment.
