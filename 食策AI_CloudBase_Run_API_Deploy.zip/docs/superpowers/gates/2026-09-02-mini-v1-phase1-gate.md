# 食策AI Mini V1 — Phase 1 Core Foundation Gate

**Review date:** 2026-09-02  
**Scope:** Mini V1 Phase 1 — Schema V3, repository boundaries, Mini auth/onboarding, revenue resolver, benchmark service, cost resolver, profit engine/API  
**Gate result:** **PASS**

## 1. Scope completed

Phase 1 adds an additive Mini-program backend foundation on top of the existing V0.5.0-R1 Data Foundation. It does not replace the existing sales / settlement / payment / reconciliation lineage model.

Completed components:

- Schema V3 additive migration
- `TAOBAO_FLASH` channel added without renaming/removing `MEITUAN_FLASH`
- Mini user/store repositories with single-store ownership boundary
- WeChat auth adapter + dev auth provider + signed bearer token
- Mini store create/read/update APIs
- Revenue resolver with whole-store/channel overlap protection
- Approved benchmark registry and seed validation
- Cost resolver with actual/history/benchmark priority
- Operating-profit range engine
- Mini profit profile and today-profit APIs

## 2. Data-integrity boundaries retained

The following V0.5.0-R1 rules remain intact:

- existing normalized financial records retain import lineage
- partial corrections continue to fail closed instead of mixing field provenance
- settlement-period fees are not fabricated onto a single business date
- revenue and settlement semantics remain separate
- existing channel codes remain stable
- Decimal-based money calculation remains the financial core

New Phase-1 rules:

- whole-store sales and covered channel sales are never silently summed together
- settlement/payment values are never treated as sales revenue
- profit is unavailable without real revenue
- estimated costs retain source and range
- benchmarks must be `APPROVED`, cited, dated, and valid for the requested period
- benchmark-derived profit remains a range rather than a false point estimate

## 3. Automated tests

### Phase-1 focused suite

Command:

```bash
python -m pytest tests/test_schema_v3.py tests/test_mini_repositories.py tests/test_mini_auth_api.py tests/test_revenue_resolver.py tests/test_benchmark_service.py tests/test_profit_engine.py tests/test_mini_profit_api.py -q
```

Result:

- **32 passed**
- **0 failed**
- 2 existing FastAPI `on_event` deprecation warnings

### Full regression suite

Command:

```bash
python -m pytest -q
```

Result:

- **90 passed**
- **0 failed**
- 2 existing FastAPI `on_event` deprecation warnings

### Python compile check

```bash
python -m compileall -q .
```

Result: **PASS**

## 4. Real R1 → Schema V3 migration smoke

A copy of the untouched R1 database was migrated, never the source database.

Observed:

- before schema: **2**
- after schema: **3**
- original store rows preserved: **YES**
- legacy `app_state` preserved: **YES**
- original 9 channel codes preserved: **YES**
- `TAOBAO_FLASH` added: **YES**
- final channel count: **10**
- required V3 tables present: **YES**
- production benchmark seed accepted: **4 APPROVED rows**
- second migration call returns schema 3 without duplication: **YES**

## 5. Actual FastAPI process smoke

A real Uvicorn process was started against the isolated development workspace.

Verified:

- `GET /api/health` → **200**
- `GET /api/state` → **200**
- `GET /api/v2/channels` → **200**, includes `TAOBAO_FLASH`
- `POST /api/mini/v1/auth/wechat` with `dev-*` code → **200**
- `POST /api/mini/v1/store` → **200**
- `GET /api/mini/v1/profit/today` without sales → **200**, `UNAVAILABLE`, missing `营业额`

This confirms Mini V1 is additive and the legacy API remains reachable.

## 6. Benchmark-data scope

The production seed currently contains only reviewed **MILK_TEA** national benchmark rows for:

- food-cost rate
- labor-cost rate
- rent-to-sales rate
- utility-cost rate

This is deliberate. Other restaurant categories are **not** filled with invented fallback values. If no approved benchmark exists, the cost resolver returns missing data rather than manufacturing an estimate.

Local city wage benchmarks are structurally supported but are not seeded from statutory minimum wage as a proxy for normal restaurant wages.

## 7. Known limitations / not a Phase-1 failure

1. FastAPI still emits two `on_event` deprecation warnings inherited from the current server lifecycle architecture.
2. `/api/health` still reports the legacy `0.5.0 / data-foundation-v2` metadata. Mini APIs are already mounted, but version-label harmonization is deferred to a product-version packaging task rather than mixed into financial logic changes.
3. `TokenService` uses a development fallback secret when `MINI_TOKEN_SECRET` is absent. Production deployment must require an environment secret.
4. Real WeChat `jscode2session` requires `WECHAT_APPID` and `WECHAT_SECRET`; local smoke uses the explicit `dev-*` provider.
5. No screenshot OCR, XLSX ingestion, anomaly engine, actions, reminders, native Mini Program UI, or browser/DevTools E2E is claimed in this gate. Those belong to later phases.

# Final Gate

**Mini V1 Phase 1 Core Foundation = PASS**

Phase 2 may begin: **Ingestion & Recognition**.
