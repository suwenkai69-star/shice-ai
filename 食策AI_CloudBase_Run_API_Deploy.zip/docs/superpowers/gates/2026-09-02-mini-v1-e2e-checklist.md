# 食策AI Mini V1 — E2E 验收清单

**日期：** 2026-09-02  
**候选版本：** `0.5.0-R1+MiniV1`  
**原则：** 未实际验证的项目必须保持 `PENDING`，不得按推测标记 PASS。

## A. 自动化验收 — PASS

- [x] API Owner Journey：微信登录边界（测试 Provider）→ 创建奶茶店 → 截图 Draft → 低可信字段修正 → 人工确认 → 正式入库 → 手工人工成本 → Today → AOV 异常 → 行动执行 → 提醒 → 次日数据 → 验证改善。
- [x] 同日累计截图更新：第二次累计报表不会与第一次重复相加；必须经过 duplicate decision 后替换。
- [x] POS 整店总额覆盖微信/支付宝子渠道，避免营业额重复计算。
- [x] 对账文案使用“暂时没对上”，不会无证据表达为“平台少给钱”。
- [x] `/api/health` 报告 Schema V3 与 Mini API v1。
- [x] 小程序 Tab 严格为“今天 / 待办 / 上传 / 我的”。
- [x] 首屏 `/today` 单聚合请求契约。
- [x] OCR 确认页包含低可信字段提醒、修改、明确“确认没问题”。
- [x] `明天提醒` 前端顺序为：先 `wx.requestSubscribeMessage`，接受后才调用后端 remind。
- [x] Release config 不硬编码 `localhost` 或 `127.0.0.1`。
- [x] 所有小程序 JavaScript 通过 `node --check`。
- [x] Python 全量回归：210 passed / 0 failed（仍有 2 条继承的 FastAPI `on_event` deprecation warning）。
- [x] `python -m compileall -q .` 通过。
- [x] 实际 Uvicorn 进程启动，并通过 `GET /api/health` 200 smoke。

## B. Recognition Provider — PARTIAL / PENDING REAL FIXTURES

- [x] 已实现 `OpenAIRecognitionProvider` adapter。
- [x] Provider 单元契约已验证：图片以 data URL 发送、Structured Outputs JSON Schema、字段解析、错误输出拒绝、只有完整配置时才启用。
- [ ] 使用真实美团外卖截图人工标注并验证字段准确率。
- [ ] 使用真实淘宝闪购截图人工标注并验证字段准确率。
- [ ] 使用真实京东外卖截图人工标注并验证字段准确率。
- [ ] 使用真实抖音本地生活截图人工标注并验证字段准确率。
- [ ] 使用真实美团点评/团购截图人工标注并验证字段准确率。
- [ ] 使用真实微信/支付宝/POS 截图人工标注并验证字段准确率。

**说明：** 当前运行环境没有配置生产 `OPENAI_API_KEY` / `OPENAI_RECOGNITION_MODEL`，且项目内没有可作为“真实平台截图黄金样本”的完整 fixture 集，因此不伪报真实截图识别 PASS。

## C. 微信开发者工具 — PENDING

当前容器未发现微信开发者工具/CLI，因此以下项目未执行：

- [ ] `touristappid` 项目导入微信开发者工具。
- [ ] 普通宽度手机：欢迎 / 首登 / Today / 上传 / 待办 / 我的。
- [ ] 窄屏手机：同上，检查溢出、按钮遮挡、底部 Tab。
- [ ] Today `READY_COMPLETE`。
- [ ] Today `READY_INCOMPLETE`。
- [ ] Today `NO_DATA`。
- [ ] Today `ERROR_RETRYABLE`。
- [ ] 图片上传 → PROCESSING → NEEDS_CONFIRMATION → 修改 → 确认。
- [ ] CSV/XLSX 微信聊天文件选择。
- [ ] Possible Duplicate 决策 UI。
- [ ] AI `NEEDS_DATA → 补数据`。

## D. 真机 + 微信能力 — PENDING

以下必须在用户的真实微信环境完成：

- [ ] 替换 `touristappid` 为正式/测试 AppID。
- [ ] 后端部署至 HTTPS。
- [ ] 微信公众平台配置合法 `request` / `uploadFile` 域名。
- [ ] 设置强随机 `MINI_TOKEN_SECRET`，不得使用开发默认值。
- [ ] 配置 `WECHAT_APPID` / `WECHAT_SECRET`。
- [ ] 配置 `WECHAT_SUBSCRIBE_TEMPLATE_ID` 且模板字段与 provider adapter 对齐。
- [ ] 真机 `wx.login`。
- [ ] 真机拍照/相册上传。
- [ ] 真机 `wx.chooseMessageFile`。
- [ ] 真机订阅消息授权接受/拒绝流程。
- [ ] 订阅消息真实送达。

## E. 当前 Gate 判定

**自动化 Release Candidate：PASS。**  
**微信正式发布 Gate：PENDING。**

原因不是已知业务代码测试失败，而是缺少外部发布环境：真实 AppID、HTTPS 合法域名、微信开发者工具/真机，以及真实平台截图识别黄金样本。
