# 食策AI Mini V1 — Phase 3 Gate

**Gate:** PASS  
**Scope:** Today 聚合、7/14/30 日趋势、Baseline、Top 3 异常、简化对账  
**Date:** 2026-09-02

## 1. Delivered

- `BaselineService`：本店 7/14/30 日可靠历史优先，历史不足时回退当地/全国已审核 Benchmark。
- 历史范围采用 median + MAD 鲁棒范围，不用单一前一日，也避免单个促销/节假日尖峰污染基准。
- `anomaly_events` additive schema + `AnomalyEngine`：severity 与 confidence 分离，规则评分，根因去重，最多 Top 3。
- AOV 低于可靠本店基准可形成异常；对账差异仅在 R1 settlement/payment/reconciliation 证据支持时形成高可信异常。
- `ReconciliationSummaryService`：`/reconciliation/today` 是 **as-of today** 未结清/未匹配快照，不把结算强绑到当天销售；文案只说“暂时没对上”，不归责平台。
- `TrendService`：7/14/30 日；缺失日期不补 0；零分母/样本不足时不制造百分比。
- `TodayAggregator` + `GET /api/mini/v1/today`：一次请求返回首页需要的销售、利润、完整度、Top 3、对账和后续行动槽位。
- 整店总额存在时，渠道明细只用于结构分析，不重复相加。

## 2. Homepage fixture — complete/current data example

```json
{
  "date": "2026-09-02",
  "sales": {
    "amount": "8420.00",
    "orders": 163,
    "avg_order_value": "51.66",
    "coverage": "WHOLE_STORE_TOTAL"
  },
  "data_status": {
    "complete": true,
    "missing_sources": []
  },
  "top_issues": [],
  "reconciliation": {
    "status": "OK",
    "user_message": "暂时没发现问题"
  }
}
```

`profit` 仍由 Phase 1 Profit Engine 决定 `ACTUAL_BASED / ESTIMATED_RANGE / UNAVAILABLE`，本聚合层不重新计算财务。

## 3. Homepage fixture — incomplete data example

```json
{
  "date": "2026-09-02",
  "sales": {
    "amount": null,
    "orders": null,
    "avg_order_value": null
  },
  "profit": {
    "status": "UNAVAILABLE",
    "missing_data": ["营业额"]
  },
  "data_status": {
    "complete": false,
    "missing_sources": ["WHOLE_STORE"]
  }
}
```

系统保留 `as_of` / `as_of_time`，不会把当前不完整数据伪装成完整日报。

## 4. Evidence language

未匹配结算示例：

```text
还有 ¥386.00 暂时没对上
```

禁止输出：

```text
平台少给了 ¥386.00
```

## 5. Verification

```text
Phase-3 targeted: 26 passed / 0 failed
Full suite:       147 passed / 0 failed
Compileall:       PASS
```

Known warning: FastAPI legacy `@app.on_event('startup')` 仍有 2 条 deprecation warning；这是 R1 已知旧架构问题，Phase 3 未做无关重构。

## 6. Gate checklist

- [x] `/api/mini/v1/today` 单次聚合
- [x] Top 3 最多三条且根因去重
- [x] 低可信异常使用不确定表达
- [x] 对账只依据正式 settlement/payment/reconciliation 证据
- [x] 对账为 as-of 快照，不绑定“今天销售”
- [x] 整店与渠道营业额不静默双算
- [x] 缺失日期不补零
- [x] 零分母不制造百分比
- [x] R1 + Phase 1/2 回归保持全绿

**Phase 3 Gate = PASS**
