# 食策AI Mini V1 — PostgreSQL Contract Gate — 2026-09-06

## Scope
- Neon project: `shice-ai-mini-v1`
- Project ID: `mute-unit-19408900`
- Disposable branch: `contract-test-2026-09-06`
- Branch ID: `br-delicate-smoke-auvhjv1d`
- Parent: Neon main
- Database: `neondb`

## Main-derived branch baseline
Read-only verification on the disposable branch before test writes:
- `cloud_schema_version = 1`
- `channels = 10`
- `APPROVED industry_benchmarks = 4`
- `users = 0`
- `stores = 0`

## Live Neon SQL persistence contract
Executed only on the disposable branch. Evidence confirmed:
- user/store creation works
- store profile creation works
- whole-store daily sales upsert works and updates `8420.00 -> 8600.00`
- second store sees no first-store sales row
- cost entry insert works
- upload document persists with `storage_policy=EPHEMERAL`
- upload `storage_key IS NULL`
- structured `upload_drafts` row persists
- action item/execution/verification persistence works

No test business rows were written to Neon main.

## Python contract suite status
Added guarded live PostgreSQL contract tests:
- `tests/cloud/conftest.py`
- `tests/cloud/test_repository_contracts.py`
- `tests/cloud/test_data_foundation_postgres.py`
- `tests/cloud/test_tenant_isolation.py`
- `tests/cloud/test_postgres_acceptance.py`
- `tests/cloud/test_postgres_compat_translation.py`
- `tests/cloud/test_postgres_service_propagation.py`

Live Python-via-psycopg execution is currently not executable in this container because:
1. `psycopg` is not installed in the runtime image.
2. outbound DNS from the container cannot resolve the Neon host.

The live tests therefore fail closed unless `SHICE_POSTGRES_CONTRACT=1` and a PostgreSQL `DATABASE_URL` are explicitly supplied; without that authorization they are skipped rather than accidentally targeting production.

## Production bug found/fixed
`TodayAggregator` passed `self.db_path` into `VerificationEngine`. For PostgreSQL, `self.db_path` is `None`, so a next-day verification path could fall back into an invalid SQLite target. Added a regression test first, observed RED, then changed the code to pass the full `Database` object.

## Fresh local automated verification
Command sequence:
- `python -m compileall -q .`
- all Mini Program `.js` files through `node --check`
- `PYTHONPATH=. pytest -q`

Result:
- `239 passed`
- `4 skipped` (explicit live PostgreSQL tests requiring psycopg/network)
- `0 failed`
- `2 warnings` (inherited FastAPI `on_event` deprecation warnings)

## Next gate
Proceed to Vercel Preview packaging/deployment only after secure environment variables can be configured through Vercel. Required at minimum:
- `DATABASE_URL`
- `SHICE_ENV=production`
- `MINI_TOKEN_SECRET`
- `WECHAT_APPID`
- `WECHAT_SECRET`

Never embed these values in source or deployment files.
