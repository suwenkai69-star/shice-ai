# 食策AI Mini V1 Cloud PostgreSQL — Predeploy Gate

## Decision

**LOCAL CLOUD REFACTOR: PASS**  
**NEON TEMPORARY-BRANCH MIGRATION: BLOCKED BY CONNECTOR ARGUMENT-MAPPING DEFECT**  
**NEON MAIN: UNCHANGED / NO 食策AI BUSINESS TABLES**  
**VERCEL PACKAGING: READY FOR PREVIEW ONCE DATABASE/SECRETS CAN BE CONFIGURED**

## Fresh local evidence

- Full regression: **236 passed / 0 failed / 2 inherited FastAPI deprecation warnings**.
- `python -m compileall -q .`: PASS.
- All Mini Program JavaScript files pass `node --check`.
- Vercel packaging contract: **3 passed**.
- `vercel.json` configures root `app.py`, a 60-second function duration, and excludes local-only/test assets.
- `.vercelignore` excludes environment files, SQLite DB files, transient uploads, caches, tests, samples, and legacy static UI.

## Neon evidence

Project: `shice-ai-mini-v1` (`mute-unit-19408900`)  
Default branch: `main` (`br-young-smoke-auz0ote5`)  
PostgreSQL: 18

Read-only branch inspection shows only the default databases and Neon system helper function; no 食策AI business tables are present.

The connected Neon actions that require a project selector expose camelCase arguments (for example `projectId`) but the provider runtime rejects those and requires snake_case (`project_id`). This blocks `prepare_database_migration`, `get_database_tables`, `run_sql`, `create_branch`, and connection-string retrieval through the connected action surface. No direct SQL fallback has been used against Neon main.

## Production safety state

- Production startup fails closed without `DATABASE_URL`.
- Vercel/production authentication fails closed without required WeChat/token configuration.
- Production route allowlist exposes only `/api/health` and `/api/mini/v1/**`.
- Raw uploads use EPHEMERAL handling and are not required after draft extraction.
- No Neon connection string or provider secret is stored in the source tree or this Gate.

## Remaining Gate sequence

1. Restore a working Neon project-parameter action surface.
2. Prepare exact migration on a temporary Neon branch.
3. Run schema, seed, repository, R1, upload, tenant and acceptance contracts on that exact branch.
4. Ask for explicit approval before applying the exact migration to Neon main.
5. Seed system-only data on main; verify zero users/stores before first real login.
6. Configure Vercel secrets through server-side environment variables.
7. Preview deploy → public HTTPS persistence acceptance → production publish.
8. Only then update Mini Program release API base URL.
