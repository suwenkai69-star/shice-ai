# 食策AI Mini V1 — Final Engineering Gate

**Date:** 2026-09-02  
**Version:** `0.5.0-R1+MiniV1`  
**Scope:** Mini V1 engineering release candidate  
**Decision:** **AUTOMATED RC PASS / WECHAT RELEASE PENDING**

## Fresh verification evidence

### Acceptance API

`python -m pytest tests/test_mini_v1_acceptance_api.py -q`

- **5 passed / 0 failed**
- 2 inherited FastAPI `on_event` deprecation warnings

Validated stories include:

1. Login → store → image extraction draft → human correction/confirm → labor cost → Today → Top issue → action execute → reminder → next-day verification.
2. Same-day cumulative image report update does not double count.
3. POS whole-store total prevents WeChat/Alipay double counting.
4. Reconciliation uses cautious “暂时没对上” language and hard-priority issue ranking.
5. Health reports Schema V3 + Mini API v1.

### Full regression / compile / Mini Program syntax

Commands:

```bash
python -m pytest -q
python -m compileall -q .
find miniprogram -name '*.js' -print0 | xargs -0 -n1 node --check
```

Result:

- **210 passed / 0 failed**
- `compileall`: PASS
- all Mini Program JS syntax checks: PASS
- 2 inherited FastAPI `on_event` deprecation warnings remain

### Front-end / provider contract subset

`python -m pytest tests/test_miniprogram_static_contract.py tests/test_miniprogram_copy_contract.py tests/test_openai_recognition_provider.py -q`

- **18 passed / 0 failed**

### Real process smoke

A real `python run.py` Uvicorn process was started and polled over HTTP.

`GET http://127.0.0.1:8765/api/health` returned 200 with:

```json
{
  "ok": true,
  "version": "0.5.0-R1+MiniV1",
  "engine": "fastapi+sqlite+data-foundation-v3",
  "schema_version": 3,
  "mini_api_version": "v1"
}
```

## Engineering status by phase

- Phase 1 — Core foundation: PASS
- Phase 2 — Ingestion / recognition draft pipeline: PASS
- Phase 3 — Insights / Today / Top-3 / trends / reconciliation summary: PASS
- Phase 4 — Action loop / reminders / verification / AI context + text drafts: PASS
- Phase 5 — Native Mini Program static/contract + automated API acceptance: PASS
- Phase 5 — WeChat DevTools + real-device + production-provider release checks: PENDING

## Release blockers that are external to automated code verification

1. No WeChat DevTools/CLI is installed in the current execution container; visual DevTools smoke cannot be claimed.
2. No actual WeChat device session is available; `wx.login`, camera/gallery, message-file selection, and subscription authorization cannot be claimed.
3. No production AppID / legal HTTPS request domain is configured in this local RC.
4. `OpenAIRecognitionProvider` is implemented and contract-tested, but no production credential or human-reviewed real-platform screenshot fixture set is available here. Real screenshot accuracy remains pending.
5. Text-model provider remains intentionally pluggable and disabled unless configured; it does not impersonate a live model.
6. Production must set a strong `MINI_TOKEN_SECRET`; the development fallback is not a production secret.

## Integrity rules preserved

- OCR/vision output cannot directly write normalized financial data; human confirm is required.
- Core money calculations remain Decimal-based.
- Whole-store revenue and channel children cannot silently double count.
- Partial correction safety from R1 remains fail-closed.
- Settlement-period fees are not fabricated onto one business day.
- Profit estimates are ranges with source provenance; no real sales means no profit result.
- AI explains structured facts; it does not invent missing financial facts.
- High-risk operations are recommendations only; user confirmation is required.

## Gate decision

The codebase is a **Mini V1 automated release candidate**, not a WeChat production release.

Proceed next with the deployment/real-device gate:

`AppID + HTTPS domain → real RecognitionProvider fixtures → WeChat DevTools smoke → real-device smoke → production release decision`.
