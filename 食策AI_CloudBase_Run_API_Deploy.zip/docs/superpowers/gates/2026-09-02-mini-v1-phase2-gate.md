# 食策AI Mini V1 — Phase 2 Ingestion & Recognition Gate

**Review date:** 2026-09-02  
**Scope:** Manual entry, CSV/XLSX preview-confirm, image recognition draft-confirm wall, duplicate protection, source learning and daily completeness  
**Gate result:** **PASS for deterministic backend scope**

> This gate does **not** claim real OCR/provider or real screenshot acceptance. Those remain Phase 5 release criteria.

## 1. Completed backend flow

Implemented:

- additive V3 ingestion tables:
  - `upload_documents`
  - `extraction_jobs`
  - `extracted_fields`
  - `document_import_links`
  - `store_data_sources`
  - `daily_data_status`
- compatibility backfill for intermediate development databases already marked schema 3
- manual sales:
  - explicit `WHOLE_STORE`
  - explicit `CHANNEL`
- manual cost
- manual payment
- CSV preview → confirm → V2 importer
- XLSX read-only preview → canonical JSON → V2 importer
- GB18030 CSV support retained
- `.xls` fail-closed with user-facing conversion instruction
- malformed file creates `FAILED` auditable document
- provider-neutral image recognition interface
- persistent recognition job + extracted field confidence
- low-confidence field correction before confirm
- unknown platform/page remains unconfirmed and cannot auto-import
- confirmed image sales enter V2 lineage as `MINI_OCR_CONFIRMED`
- confirmed daily screenshot platform fee is recorded only when the mapped daily template and user confirmation make day attribution explicit; generic fee stays `OTHER`, not guessed as commission
- duplicate detector does not infer identity from amount alone
- ambiguous second same-day cumulative channel report requires explicit replace choice
- no second independent daily-channel record is offered when current normalized semantics cannot safely represent it
- source expectation learning and `今天没有其他数据了` backend state
- interrupted recognition jobs are marked retryable `FAILED` after restart instead of remaining fake-success/in-progress forever

## 2. Confirm wall

Formal image flow is:

`raw image → upload_documents → extraction_jobs → extracted_fields → user correction/confirmation → MiniImportAdapter → import_batch/raw_import_row → normalized fact`

Before user confirmation:

- `daily_channel_sales`: unchanged
- `payments`: unchanged
- normalized operating facts: unchanged

Original evidence remains linked through `document_import_links` after import.

## 3. File safety

- `.csv`: UTF-8/UTF-8 BOM/GB18030
- `.xlsx`: `openpyxl` read-only + `data_only`; formulas/macros are not executed
- `.xls`: rejected with instruction to convert to XLSX/CSV
- malformed/empty/unrecognized inputs remain auditable failures
- file preview never writes official sales/payment/settlement rows

## 4. Duplicate/update safety

`DuplicateDetectionService` outputs:

- `NEW`
- `UPDATE`
- `POSSIBLE_DUPLICATE`
- `CONFLICTING_SCOPE`

Identity evidence may use store/channel/date/template/scope/reference/time-range/cumulative semantics. **Amount alone never proves UPDATE.**

For the current one-row-per-store/date/channel sales model, an ambiguous second daily report exposes only:

- `REPLACE_EXISTING`

It does not expose `TREAT_AS_SEPARATE`, because that would silently violate current normalized semantics.

R1 partial-correction fail-closed behavior still applies after a user chooses replacement.

## 5. Completeness V1

`COMPLETENESS_V1` learns expected sources from prior operating days:

- present on at least **5 of the last 7 operating days**, or
- present on at least **12 of the last 30 operating days**

Current received sources, expected sources and missing sources remain separate. A user-declared complete day is represented as `DECLARED_COMPLETE`; it does not rewrite missing history into invented data.

## 6. Automated verification

### Phase-2 focused suite

```bash
python -m pytest tests/test_ingestion_schema.py tests/test_manual_ingestion_api.py tests/test_file_upload_pipeline.py tests/test_recognition_service.py tests/test_image_confirm_api.py tests/test_duplicate_detection.py tests/test_completeness_service.py -q
```

Result:

- **31 passed**
- **0 failed**
- 2 existing FastAPI `on_event` deprecation warnings

### Full regression suite

```bash
python -m pytest -q
```

Result:

- **121 passed**
- **0 failed**
- 2 existing FastAPI `on_event` deprecation warnings

### Compile

```bash
python -m compileall -q .
```

Result: **PASS**

## 7. Actual FastAPI process smoke

Real Uvicorn process verified:

- Mini dev auth → 200
- store creation → 200
- manual whole-store sales → 200
- CSV upload preview → `NEEDS_CONFIRMATION`
- file confirm → `IMPORTED`
- daily data status → 200
- image upload with **no real RecognitionProvider configured** → accepted as processing, then becomes `FAILED / RECOGNITION_FAILED`

The last result is intentional fail-closed behavior: a missing OCR provider does not generate fake recognized data.

## 8. Deterministic fake-provider tests vs real acceptance

**PASS now:** deterministic `FakeRecognitionProvider` proves draft persistence, confidence display data, correction, confirm wall, template routing and lineage behavior.

**Not yet claimed:**

- accuracy on real Meituan/Taobao/JD/Douyin/WeChat/Alipay/POS screenshots
- real OCR/Vision provider reliability
- layout/version drift across platform apps
- WeChat device upload behavior

These are explicit Phase-5 acceptance items and must use real screenshots with human-reviewed expected fields.

## 9. Known limitations

1. Initial template registry intentionally contains no unverified UI-label alias maps; real aliases are added only with reviewed screenshot fixtures.
2. A generic confirmed `PLATFORM_FEE` from an adapted daily template is kept as `OTHER` rather than guessed to be commission/technical-service fee.
3. Current channel-day normalized sales table cannot represent two independently additive interval reports for the same channel/day; unsafe “separate” choice is therefore hidden.
4. Real recognition provider is not configured in source code; credentials/provider selection remain a deployment concern.
5. FastAPI lifecycle deprecation warnings remain legacy architecture warnings.

# Final Gate

**Mini V1 Phase 2 deterministic backend = PASS**  
**Real recognition acceptance = PENDING Phase 5**
