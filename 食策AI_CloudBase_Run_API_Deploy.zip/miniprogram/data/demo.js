module.exports = {
  date: "演示数据",
  sales: { amount: "8420.00", orders: 163, avg_order_value: "51.66" },
  profit: { status: "ESTIMATED_RANGE", profit_low: "820.00", profit_high: "1180.00", confidence_level: "MEDIUM" },
  data_status: { complete: false, missing_sources: ["POS"], as_of_time: "18:00" },
  top_issues: [
    { id: 1, title: "有一笔钱暂时没对上", message: "目前约 ¥386.00 暂时没对上，建议核对结算和到账记录。" },
    { id: 2, title: "客单价比平时低", message: "今天客单价低于参考范围，建议先看看低价订单是否变多。" }
  ],
  reconciliation: { status: "DIFFERENCE", difference: "386.00", user_message: "还有 ¥386.00 暂时没对上" }
};
