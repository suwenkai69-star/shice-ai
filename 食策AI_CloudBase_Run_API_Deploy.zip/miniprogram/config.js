const DEFAULTS = {
  apiBaseUrl: "",
  subscribeTemplateId: ""
};

function apiBaseUrl() {
  return wx.getStorageSync("shice_api_base_url") || DEFAULTS.apiBaseUrl;
}

function subscribeTemplateId() {
  return wx.getStorageSync("shice_subscribe_template_id") || DEFAULTS.subscribeTemplateId;
}

module.exports = { apiBaseUrl, subscribeTemplateId };
