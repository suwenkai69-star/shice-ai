const session = require("./utils/session");

App({
  globalData: { bootstrapped: false },
  onLaunch() {
    this.globalData.bootstrapped = Boolean(session.getToken());
  }
});
