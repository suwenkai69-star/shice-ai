const config = require("../config");

function token() { return wx.getStorageSync("shice_mini_token") || ""; }

function baseUrl() {
  const value = config.apiBaseUrl();
  if (!value) {
    const error = new Error("还没有配置食策AI服务地址");
    error.code = "CONFIG_MISSING";
    throw error;
  }
  return String(value).replace(/\/$/, "");
}

function normalizeResponse(resolve, reject, res) {
  let body = res.data;
  if (typeof body === "string") {
    try { body = JSON.parse(body); } catch (e) { body = { detail: body }; }
  }
  if (res.statusCode >= 200 && res.statusCode < 300) return resolve(body);
  const detail = body && body.detail;
  const message = typeof detail === "string" ? detail : (detail && detail.message) || "请求没有成功，请稍后重试";
  const error = new Error(message);
  error.statusCode = res.statusCode;
  error.detail = detail;
  if (res.statusCode === 401) {
    wx.removeStorageSync("shice_mini_token");
    error.code = "UNAUTHORIZED";
  }
  reject(error);
}

function request(options) {
  if (options.filePath) return uploadFile(options);
  return new Promise((resolve, reject) => {
    let url;
    try { url = baseUrl() + options.path; } catch (e) { reject(e); return; }
    const headers = Object.assign({}, options.header || {});
    if (!options.publicRequest && token()) headers.Authorization = "Bearer " + token();
    wx.request({
      url,
      method: options.method || "GET",
      data: options.data || {},
      header: headers,
      timeout: options.timeout || 12000,
      success: res => normalizeResponse(resolve, reject, res),
      fail: err => reject(new Error(err.errMsg || "网络连接失败，请检查网络后重试"))
    });
  });
}

function uploadFile(options) {
  return new Promise((resolve, reject) => {
    let url;
    try { url = baseUrl() + options.path; } catch (e) { reject(e); return; }
    const headers = Object.assign({}, options.header || {});
    if (token()) headers.Authorization = "Bearer " + token();
    wx.uploadFile({
      url,
      filePath: options.filePath,
      name: options.name || "file",
      formData: options.formData || {},
      header: headers,
      timeout: options.timeout || 30000,
      success: res => normalizeResponse(resolve, reject, res),
      fail: err => reject(new Error(err.errMsg || "上传失败，请重新试一次"))
    });
  });
}

module.exports = { request, uploadFile };
