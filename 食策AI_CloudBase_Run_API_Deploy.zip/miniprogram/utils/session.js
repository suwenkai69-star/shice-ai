const api = require("./api");
const TOKEN_KEY = "shice_mini_token";

function getToken() { return wx.getStorageSync(TOKEN_KEY) || ""; }
function setToken(value) { wx.setStorageSync(TOKEN_KEY, value); }
function clear() { wx.removeStorageSync(TOKEN_KEY); }

function login() {
  return new Promise((resolve, reject) => {
    wx.login({
      success: async result => {
        if (!result.code) { reject(new Error("微信登录没有拿到授权码，请重试")); return; }
        try {
          const payload = await api.request({ path: "/auth/wechat", method: "POST", data: { code: result.code }, publicRequest: true });
          setToken(payload.token);
          resolve(payload);
        } catch (e) { reject(e); }
      },
      fail: err => reject(new Error(err.errMsg || "微信登录失败，请重试"))
    });
  });
}

module.exports = { getToken, setToken, clear, login };
