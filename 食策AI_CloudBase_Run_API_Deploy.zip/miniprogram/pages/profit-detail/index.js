const api=require("../../utils/api");
const labels={FOOD:"原料",LABOR:"人工",RENT:"房租",UTILITY:"水电杂费",PLATFORM:"平台费用",MARKETING:"推广",PACKAGING:"包装",OTHER:"其他"};
Page({data:{date:"",profit:null,error:""},onLoad(q){this.setData({date:q.date||""});this.load();},async load(){try{const r=await api.request({path:"/profit/today",data:{business_date:this.data.date}});const p=r.profit;p.components=(p.components||[]).map(x=>Object.assign({label:labels[x.code]||x.code},x));this.setData({profit:p});}catch(e){this.setData({error:e.message});}},improve(){wx.navigateTo({url:"/pages/cost-profile/index"});}});
