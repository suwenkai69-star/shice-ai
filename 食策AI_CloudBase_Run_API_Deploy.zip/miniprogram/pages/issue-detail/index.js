const api=require("../../utils/api");
Page({data:{id:null,issue:null,error:""},onLoad(q){this.setData({id:q.id});this.load();},async load(){try{const r=await api.request({path:`/issues/${this.data.id}`});this.setData({issue:r.issue});}catch(e){this.setData({error:e.message});}},goActions(){wx.switchTab({url:"/pages/actions/index"});}});
