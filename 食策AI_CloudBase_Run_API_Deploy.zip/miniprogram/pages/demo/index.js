const demo = require("../../data/demo");
Page({
  data: { readOnly: true, demo },
  start(){ wx.redirectTo({url:"/pages/welcome/index"}); }
});
