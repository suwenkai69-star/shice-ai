const api = require("../../utils/api");
Page({
  data: {
    name: "", category: "", error: "",
    categories: [
      {code:"MILK_TEA",label:"🧋 奶茶饮品"},{code:"COFFEE",label:"☕ 咖啡"},{code:"FAST_FOOD_SNACK",label:"🍜 快餐小吃"},
      {code:"CHINESE_DINING",label:"🍚 中式正餐"},{code:"HOTPOT",label:"🔥 火锅"},{code:"BBQ",label:"🍢 烧烤"},
      {code:"BAKERY_DESSERT",label:"🥐 烘焙甜品"},{code:"BAR_LEISURE",label:"🍺 酒吧/休闲娱乐"},{code:"OTHER_FOOD",label:"🍴 其他餐饮"}
    ]
  },
  onName(e){ this.setData({name:e.detail.value}); },
  chooseCategory(e){ this.setData({category:e.currentTarget.dataset.code}); },
  async submit(){
    if(!this.data.name.trim()){ this.setData({error:"先填一下门店名称"}); return; }
    if(!this.data.category){ this.setData({error:"再选一下主营品类"}); return; }
    try{
      await api.request({path:"/store",method:"POST",data:{name:this.data.name.trim(),category_code:this.data.category}});
      wx.switchTab({url:"/pages/today/index"});
    }catch(e){ this.setData({error:e.message||"保存失败，请重试"}); }
  }
});
