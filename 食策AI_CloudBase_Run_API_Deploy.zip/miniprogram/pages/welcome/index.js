const session = require("../../utils/session");
Page({
  data: { busy: false, error: "" },
  async start() {
    if (this.data.busy) return;
    this.setData({ busy: true, error: "" });
    try {
      const result = await session.login();
      if (result.has_store) wx.switchTab({ url: "/pages/today/index" });
      else wx.navigateTo({ url: "/pages/onboarding/index" });
    } catch (e) { this.setData({ error: e.message || "暂时进不去，请重试" }); }
    finally { this.setData({ busy: false }); }
  },
  demo() { wx.navigateTo({ url: "/pages/demo/index" }); }
});
