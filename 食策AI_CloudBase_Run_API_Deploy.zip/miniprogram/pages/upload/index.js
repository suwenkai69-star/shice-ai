const api=require("../../utils/api");
Page({
  data:{busy:false,error:""},
  camera(){this.chooseImage(["camera"]);},
  gallery(){this.chooseImage(["album"]);},
  chooseImage(sourceType){wx.chooseMedia({count:1,mediaType:["image"],sourceType,success:r=>this.uploadImage(r.tempFiles[0].tempFilePath)});},
  async uploadImage(filePath){this.setData({busy:true,error:""});try{const r=await api.request({path:"/uploads/image",method:"POST",filePath,name:"file"});wx.navigateTo({url:`/pages/upload-confirm/index?id=${r.id}`});}catch(e){this.setData({error:e.message||"截图上传失败，请重试"});}finally{this.setData({busy:false});}},
  file(){wx.chooseMessageFile({count:1,type:"file",extension:["csv","xlsx"],success:r=>this.uploadFile(r.tempFiles[0].path)});},
  async uploadFile(filePath){this.setData({busy:true,error:""});try{const r=await api.request({path:"/uploads/file",method:"POST",filePath,name:"file"});wx.navigateTo({url:`/pages/upload-confirm/index?id=${r.id}`});}catch(e){this.setData({error:e.message||"文件没读明白，可以换截图或手动填写"});}finally{this.setData({busy:false});}},
  manual(){wx.navigateTo({url:"/pages/manual-entry/index"});}
});
