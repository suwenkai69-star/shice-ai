const api = require("../../utils/api");
function today(){ const d=new Date(); const p=n=>String(n).padStart(2,"0"); return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}`; }
Page({
  data:{state:"LOADING",date:"",sales:{},profit:{},dataStatus:null,issues:[],reconciliation:{user_message:"还缺平台结算/到账数据",status:"INSUFFICIENT_DATA"},pendingActions:0,verification:null,error:""},
  onShow(){ this.load(); },
  async load(){
    const date=today(); this.setData({state:"LOADING",date,error:""});
    try{
      const res=await api.request({path: "/today",data:{date}});
      const issues=(res.top_issues||[]).slice(0, 3);
      let state="READY_COMPLETE";
      if(!res.sales || !res.sales.amount) state="NO_DATA";
      else if(!res.data_status.complete) state="READY_INCOMPLETE";
      this.setData({state,sales:res.sales||{},profit:res.profit||{},dataStatus:res.data_status||null,issues,reconciliation:res.reconciliation||{},pendingActions:res.pending_actions||0,verification:res.yesterday_verification||null});
    }catch(e){ if(e.code==="UNAUTHORIZED") { wx.reLaunch({url:"/pages/welcome/index"}); return; } this.setData({state:"ERROR_RETRYABLE",error:e.message||"今天的数据暂时没加载出来"}); }
  },
  goUpload(){wx.switchTab({url:"/pages/upload/index"});},
  openProfit(){wx.navigateTo({url:`/pages/profit-detail/index?date=${this.data.date}`});},
  openIssue(e){wx.navigateTo({url:`/pages/issue-detail/index?id=${e.currentTarget.dataset.id}`});},
  openMoney(){wx.navigateTo({url:`/pages/reconciliation-detail/index?date=${this.data.date}`});},
  openTrends(){wx.navigateTo({url:`/pages/trends/index?date=${this.data.date}`});},
  openChat(){wx.navigateTo({url:`/pages/chat/index?date=${this.data.date}`});}
});
